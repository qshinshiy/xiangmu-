// 该文件用来存储localStorage 本地缓存的方法
/**
 * @author : Yingming
 * @date : 2023
 * @description : 用户信息配置文件
 */
/**
 * 操作用户token
 */
export function setToken(value) {
	uni.setStorageSync('token', value);
	// console.log('存储token成功');
}
/**
 * 操作用户userID
 */
export function setuserID(value) {
	uni.setStorageSync('userID', value);
	// console.log('存储userID成功');
}
/**
 * 获取缓存的token
 */
export function getToken() {
	let token = uni.getStorageSync('token');
	return token;
	// console.log('获取缓存的token成功');
}
/**
 * 获取缓存的userID
 */
export function getuserID() {
	let userID = uni.getStorageSync('userID');
	return userID;
	// console.log('获取缓存的userID成功');
}
/**
 * 移除用户userID=userID
 */
export function removeuserID() {
	uni.removeStorageSync('userID');
	// console.log('移除用户userID=userID成功');
}

/**
 * 移除用户token=token
 */
export function removeToken() {
	uni.removeStorageSync('token');
	// console.log('移除用户token=token成功');
}
/**
 * 操作用户信息
 * 缓存微信用户信息
 */
export function setUserInfo(value) {
	try {
		let newValue = JSON.stringify(value);
		uni.setStorageSync('user', newValue);
		// console.log('存储用户信息成功');
	} catch (e) {
		return;
	}
}
/**
 * 获取缓存的微信用户信息
 */
export function getUserInfo() {
	let user = uni.getStorageSync('user');
	// console.log('user', user)
	if (user) {
		return JSON.parse(user);
	}
}
/**
 * 移除缓存的用户信息
 */
export function removeUserInfo() {
	uni.removeStorageSync('user');
}

/**
 * 移除缓存的用户手机号
 */
export function removeUserPhone() {
	uni.removeStorageSync('user.phonenumber');
}

/**
 * 操作会员信息
 * 会员信息存储缓存
 */
export function setRememberInfo(value) {
	try {
		uni.setStorageSync('rememberInfo', value);
		// console.log('存储会员信息成功');
	} catch (e) {
		return;
	}
}

/**
 * 获取缓存的会员信息
 */
export function getRememberInfo() {
	let rememberInfo = uni.getStorageSync('rememberInfo');
	if (rememberInfo) {
		// console.log('会员信息获取成功：', rememberInfo)
		return rememberInfo;
	}
}
/**
 * 移除缓存的会员信息
 */
export function removeRememberInfo() {
	uni.removeStorageSync('rememberInfo');
	// console.log("清楚会员信息成功！")
}

/**
 * 缓存用户分享ID
 * 登录时传到后端
 */
export function setShareID(value) {
	try {
		uni.setStorageSync("shareid", value);
	} catch (e) {
		return;
	}
}
/**
 * 获取用户分享ID
 * 登录时传到后端
 */
export function getShareID() {
	let shareid = uni.getStorageSync("shareid")
	if (shareid) {
		return shareid;
	}
}