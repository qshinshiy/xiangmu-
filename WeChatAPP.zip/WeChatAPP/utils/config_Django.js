const baseUrl = "http://localhost:8000/"
const QRcode_encryption_key = "u679c"

export function get_encryption_key(){
	return QRcode_encryption_key;
}
export function get_url() {
  return baseUrl;
};
