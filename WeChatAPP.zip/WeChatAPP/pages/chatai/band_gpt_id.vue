<template>
    <view style="height: 100vh; background: #fff">
        <view class="img_a">
            <view class="t_b">
                云萌大模型平台
                <br />
                首次使用需绑定信息
            </view>
        </view>
        <view class="login_view" style="">
            <view class="t_login">
                <view class="cl">
                    <view class="t_a">
                        <text class="txt">账号</text>
                        <br />
                        <text class="txt_tip">
                            不清楚的可以试一下“学号@cloudcode.team”
                        </text>
                        <input
                            type="text"
                            placeholder="请输入大模型账号"
                            v-model="username"
                        />
                    </view>
                    <button @click="login">绑 定</button>
                </view>
                <view class="t_f">
                    <text>——————网工云萌工作室 ——————</text>
                </view>
            </view>
        </view>
    </view>
</template>

<script>
import { get_url, get_encryption_key } from "@/utils/config_Django.js";

import { getUserInfo, getToken, getuserID } from "@/utils/auth";

export default {
    data() {
        return {
            _url: {},
            user: {},
            token: {},
            getuserID: {},
            username: "",
        };
    },
    onLoad: function () {
        this._url = get_url() || {};
        this.user = getUserInfo() || {};
        this.token = getToken() || {};
        this.getuserID = getuserID() || {};
    },
    methods: {
        login() {
            uni.request({
                url: `${this._url}chat/band/`,
                method: "POST",
                data: {
                    "student_id": this.getuserID,
                    "student_token": this.token,
                    "username": this.username,
                },
                success: (res) => {
                    if (200 <= res.statusCode && res.statusCode <= 300) {
                        uni.showToast({
                            title: "绑定成功",
                            icon: "none",
                            duration: 2000,
                        });
                        setTimeout(() => {
                            uni.navigateTo({
                                url: "/pages/index/allindex",
                            });
                        }, 500);
                    } else {
                        uni.showToast({
                            title: res.data.error || res.data.message,
                            icon: "none",
                            duration: 2000,
                        });
                    }
                },
                fail: (err) => {
                    uni.showToast({
                        title: "绑定失败",
                        icon: "none",
                        duration: 2000,
                    });
                },
            });
        },
    },
};
</script>

<style>
.txt_tip {
    font-size: 25rpx;
    color: #999999;
    margin-top: 10rpx;
}
.txt {
    font-size: 32rpx;
    font-weight: bold;
    color: #333333;
}

.img_a {
    width: 100%;
    height: 450rpx;
    background-image: url(https://base.cloudcode.team/newbg/CloudCode1-2.png);
    background-size: 100%;
}

.reg {
    font-size: 28rpx;
    color: #fff;
    height: 90rpx;
    line-height: 90rpx;
    border-radius: 50rpx;
    font-weight: bold;
    background: #f5f6fa;
    color: #000000;
    text-align: center;
    margin-top: 30rpx;
}

.login_view {
    width: 100%;
    position: relative;
    margin-top: -120rpx;
    background-color: #ffffff;
    border-radius: 8% 8% 0% 0;
}

.t_login {
    width: 600rpx;
    margin: 0 auto;
    font-size: 28rpx;
    padding-top: 80rpx;
}

.t_login button {
    font-size: 28rpx;
    background: #2796f2;
    color: #fff;
    height: 90rpx;
    line-height: 90rpx;
    border-radius: 50rpx;
    font-weight: bold;
}

.t_login input {
    height: 90rpx;
    line-height: 90rpx;
    margin-bottom: 50rpx;
    border-bottom: 1px solid #e9e9e9;
    font-size: 28rpx;
}

.t_login .t_a {
    position: relative;
}

.t_b {
    text-align: left;
    font-size: 45rpx;
    color: #ffffff;
    padding: 130rpx 0 0 70rpx;
    font-weight: bold;
    line-height: 64rpx;
}

.t_login .t_c {
    position: absolute;
    right: 22rpx;
    top: 22rpx;
    background: #5677fc;
    color: #fff;
    font-size: 24rpx;
    border-radius: 50rpx;
    height: 50rpx;
    line-height: 50rpx;
    padding: 0 25rpx;
}

.t_login .t_d {
    text-align: center;
    color: #999;
    margin: 80rpx 0;
}

.t_login .t_e {
    text-align: center;
    width: 250rpx;
    margin: 80rpx auto 0;
}

.t_login .t_g {
    float: left;
    width: 50%;
}

.t_login .t_e image {
    width: 50rpx;
    height: 50rpx;
}

.t_login .t_f {
    text-align: center;
    margin: 150rpx 0 0 0;
    color: #666;
}

.t_login .t_f text {
    margin-left: 20rpx;
    color: #aaaaaa;
    font-size: 27rpx;
}

.t_login .uni-input-placeholder {
    color: #aeaeae;
}

.cl {
    zoom: 1;
}

.cl:after {
    clear: both;
    display: block;
    visibility: hidden;
    height: 0;
    content: "\20";
}
</style>
