<template>
  <view class="container">
    <view class="title">排行榜</view>
	<view>最高上榜数：{{ maxRank }}</view>
	<view>最低上榜数：{{ minRank }}</view>
	<view>当前时间：{{ currentTime }}</view>
    <table>
      <thead>
        <tr>
          <th>排名</th><th>头像</th><th>姓名</th>  <th>年级</th><th>AC题目数</th>  <th>部门/班级</th>
          
          
        
          
        
        </tr>
      </thead>
      <tbody>
        <tr v-for="(player, index) in players" :key="player.id" :class="{'highlight': index < 3}">
          <td>{{ index + 1 }}</td>
          <td><image :src="player.avatar" class="avatar" mode="aspectFill" @click="gotoUserDetails(player)" /></td>
          <td>{{ player.name }}</td>
          <td>{{ player.grade }}</td>
          <td>{{ player.acCount }}</td>
          <td>{{ player.department }}</td>
        </tr>
      </tbody>
    </table>

  </view>
</template>

<script>
export default {
  data() {
    return {
      players: [
		  { id: 1, username: 'PlayerA', score: 1},
		  { id: 2, username: 'PlayerB', score: 2 },
		  { id: 3, username: 'PlayerC', score: 3 },
		  { id: 4, username: 'PlayerD', score: 4 },
		  { id: 5, username: 'PlayerE', score: 5 },
		  { id: 6, username: 'PlayerF', score: 6 },
		  { id: 7, username: 'PlayerG', score: 7 },
		  { id: 8, username: 'PlayerH', score:8 },
		  { id: 9, username: 'PlayerI', score: 9 },
		  { id: 10, username: 'PlayerJ', score: 10},
	  ],
      maxRank: 0,
      minRank: 0,
      currentTime: ''
    };
  },
  onShow() {
    this.fetchRankingData();
    this.getCurrentTime();
  },
  methods: {
    fetchRankingData() {
      uni.request({
        url: 'https://oj.cloudcode.team/api/get-recent-seven-ac-rank',
        method: 'GET',
        success: (res) => {
          if (res.statusCode === 200) {
            const data = res.data;
            this.players = data.players.slice(0, 10); // 只展示前10名
            this.maxRank = data.maxRank;
            this.minRank = data.minRank;
          } else {
            uni.showToast({
              title: '排行数据加载失败',
              icon: 'none',
            });
          }
        },
        fail: () => {
          uni.showToast({
            title: '排行请求失败',
            icon: 'none',
          });
        },
      });
    },
    getCurrentTime() {
      const date = new Date();
      this.currentTime = date.toLocaleString();
    },
    gotoUserDetails(user) {
      uni.navigateTo({
        url: `/pages/user-details?id=${user.id}&name=${user.name}&grade=${user.grade}`,
      });
    }
  },
};
</script>

<style>
.container {
  padding: 20rpx;
}

.title {
  font-size: 32rpx;
  text-align: center;
  margin-bottom: 20rpx;
   padding-top: 20px;
}

table {
  width: 100%;
}

th, td {
  padding: 8rpx;
  text-align: left;
}

.highlight {
  font-weight: bold;
}

.avatar {
  width: 80rpx;
  height: 80rpx;
  border-radius: 50%;
  margin-right: 10rpx;
}
</style>
