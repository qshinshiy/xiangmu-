<!-- 
@author : Yingming
@date : 2023
@description : 本人志愿者详情
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<!-- 基本信息 -->
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">个人志愿参与记录</text>
							<text class="text-ABC text-blue">MyVOLJOINInFO</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.token != null">
						<view class="content">
							<text class="cuIcon-my text-blue"></text>
							<text class="text-lg">姓名</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.username}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.token != null">
						<view class='content'>
							<text class="cuIcon-favor text-blue"></text>
							<text class='text-lg'>学号</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.userid}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-for="(item,index) in actList" :key="index" @
						v-if="item.isJoin == 2">
						<view class="content">
							<text class="cuIcon-list text-blue"></text>
							<text class="text-lg">{{item.activityName}}</text>
						</view>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<view style="height: 50rpx;width: 1rpx;"></view>
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				user: {},
				token: {},
				actList: [],
			}
		},
		onLoad(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},
		onShow(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			this.actlist();
		},
		methods: {
			actlist: function() {
				var that = this;
				let datas = {
					userid: this.user.userid,
				}
				that.request("vol/activityList", datas, 'GET').then(res => {
					that.actList = res.data.list
					let list = that.actList.map((item) => {
						item.activityId = item.activityId + "";
						item.activityParStatus = item.activityParStatus + "";
						item.activityVolStatus = item.activityVolStatus + "";
						item.version = item.version + "";
						item.isJoin = item.isJoin + "";
						item.isDisplay = item.isDisplay + "";
						item.activityParNum = item.activityParNum + "";
						return item
					})
					that.actList = list
					console.log(this.actList)
				});
			},
		}
	}
</script>
<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.containera {
			margin: 0 auto;
			width: 750rpx;
		}

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					min-height: 100rpx;
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}

	}
</style>
