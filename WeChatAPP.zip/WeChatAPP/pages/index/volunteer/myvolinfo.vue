<!-- 
@author : Yingming
@date : 2023
@description : 本人志愿者信息
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<!-- 基本信息 -->
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">个人基础信息</text>
							<text class="text-ABC text-blue">MyInFO</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.token != null">
						<view class="content">
							<text class="cuIcon-my text-blue"></text>
							<text class="text-lg">志愿者姓名</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.username}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.token != null">
						<view class='content'>
							<text class="cuIcon-favor text-blue"></text>
							<text class='text-lg'>志愿者学号</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.userid}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.token != null">
						<view class='content'>
							<text class="cuIcon-read text-blue"></text>
							<text class='text-lg'>志愿者班级</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.className}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.token != null">
						<view class='content'>
							<text class="cuIcon-message text-blue"></text>
							<text class='text-lg'>志愿者联系方式</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.phonenumber}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.token != null">
						<view class='content'>
							<text class="cuIcon-countdown text-blue"></text>
							<text class='text-lg'>志愿者注册日期</text>
						</view>
						<!-- 这里需要请求一个接口，获取注册志愿者的时间，累计参与志愿活动次数，累计志愿时长 -->
						<view class="action">
							<view class="cu-tag round bg-yellow light">
								敬请期待
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.token != null">
						<view class='content'>
							<text class="cuIcon-info text-blue"></text>
							<text class='text-lg'>如信息有误，请联系网络工程系党支部</text>
						</view>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<view style="height: 50rpx;width: 1rpx;"></view>
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				user: {},
				token: {},
			}
		},
		onLoad(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},
		onShow(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},
		methods: {}
	}
</script>
<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.containera {
			margin: 0 auto;
			width: 750rpx;
		}

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					min-height: 100rpx;
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}

	}
</style>
