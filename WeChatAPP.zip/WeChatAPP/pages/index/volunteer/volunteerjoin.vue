<!-- 
@author : Yingming
@date : 2023
@description : 志愿活动报名
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<!-- 基本信息 -->
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">志愿报名信息</text>
							<text class="text-ABC text-blue">volunteerApplyInfo</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.username != null && user.username != ''">
						<view class="content">
							<text class="cuIcon-my text-blue"></text>
							<text class="text-lg">志愿者姓名</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.username}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.userid != null && user.userid != ''">
						<view class='content'>
							<text class="cuIcon-favor text-blue"></text>
							<text class='text-lg'>志愿者学号</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.userid}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.className != null && user.className != ''">
						<view class='content'>
							<text class="cuIcon-read text-blue"></text>
							<text class='text-lg'>志愿者班级</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.className}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.phonenumber != null && user.phonenumber != ''">
						<view class='content'>
							<text class="cuIcon-message text-blue"></text>
							<text class='text-lg'>志愿者联系方式</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.phonenumber}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;"
						v-if="item.activityName != null && item.activityName != ''">
						<view class='content'>
							<text class="cuIcon-newshot text-blue"></text>
							<text class='text-lg'>志愿活动名称</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{item.activityName}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;"
						v-if="item.activityTypeName != null && item.activityTypeName != ''">
						<view class='content'>
							<text class="cuIcon-ticket text-blue"></text>
							<text class='text-lg'>志愿活动类型</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{item.activityTypeName}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="item.isJoin == 1">
						<view class='content'>
							<text class="cuIcon-info text-orange"></text>
							<text class='text-lg'>当前状态</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-orange light">
								审核中
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="item.isJoin == 2">
						<view class='content'>
							<text class="cuIcon-info text-green"></text>
							<text class='text-lg'>当前状态</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								报名成功
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="item.isJoin == 3">
						<view class='content'>
							<text class="cuIcon-info text-red"></text>
							<text class='text-lg'>当前状态</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-red light">
								审核未通过
							</view>
						</view>
					</view>
					<view class="margin-top-sm" style="padding: 0;" v-if="item.isJoin == 4">
						<button class="bg-blue" @click="checkapply">确认报名</button>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<view class="center-box shadow" v-if="item.isJoin == 2 ">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">本人签到信息</text>
							<text class="text-ABC text-blue">MyCheckInfo</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-for="(item,index) in UserList" :key="index" @
						v-if="item.userid == user.userid">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>第{{item.num}}次签到</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-orange light" v-if="item.isSignIn == 1">
								未签到
							</view>
							<view class="cu-tag round bg-green light" v-if="item.isSignIn == 2 && item.isSignOut != 3">
								已签到
							</view>
							<view class="cu-tag round bg-orange light" v-if="item.isSignOut == 1">
								未签退
							</view>
							<view class="cu-tag round bg-green light" v-if="item.isSignOut == 2">
								已签退
							</view>
							<view class="cu-tag round bg-red light" v-if="item.isSignOut == 3">
								本条签到记录作废
							</view>
						</view>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<view style="height: 50rpx;width: 1rpx;"></view>
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import UQRCode from '@/node_modules/uqrcodejs/uqrcode.js';
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				UserList: [],
				patyInfo: {},
				user: {},
				item: {},
			}
		},
		onLoad(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			var item = JSON.parse(options.data); // 字符串转对象
			this.item = item;
		},
		onShow(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			this.showuser();
		},
		methods: {
			checkapply() {
				var that = this;
				var activitid = Number(this.item.activityId)
				let datas = {
					userid: this.user.userid,
					username: this.user.username,
					className: this.user.className,
					phoneNum: this.user.phonenumber,
					activityId: activitid, //long形
				}
				that.request("vol/join", datas, 'POST').then(res => {
					if (res.code == 200) {
						uni.showToast({
							title: '报名成功',
							icon: 'success',
							duration: 1000,
						});
						setTimeout(function() {
							uni.redirectTo({
								url: '/pages/index/volunteer/volunteerlist',
							});
						}, 1000);
					} else {
						uni.showToast({
							title: '出错啦，请重试',
							icon: 'error',
							duration: 1000,
						});
					}
				});
			},
			showuser() {
				var that = this;
				var activityId = Number(this.item.activityId)
				let datas = {
					activityid: activityId,
				}
				that.request("wxattendace/getrole", datas, 'GET').then(res => {
					that.UserList = res.data;
					let list = that.UserList.map((item) => {
						item.isSignIn = item.isSignIn + "";
						item.isSignOut = item.isSignOut + "";
						item.activityId = item.activityId + "";
						item.id = item.id + "";
						item.num = item.num + "";
						return item
					})
					that.UserList = list;
				});
			},
		}
	}
</script>
<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.containera {
			margin: 0 auto;
			width: 750rpx;
		}

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					min-height: 100rpx;
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}

	}
</style>
