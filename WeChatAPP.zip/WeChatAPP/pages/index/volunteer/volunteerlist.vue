<!-- 
@author : Yingming
@date : 2023
@description : 志愿活动列表
-->
<template>
	<view>
		<view class="cu-timeline">
			<!-- 志愿者预告 -->
			<view class="cu-time">
				<text class='cuIcon-rank text-white text-lg bg-blue round padding-xs'></text>
				<text class='text-xl margin-left'>志愿活动预告</text>
			</view>
			<view class="cu-item text-blue" v-if="item.activityVolStatus == 0" v-for="(item,index) in actList"
				:key="index" @>
				<view class="content">
					<view class="cu-capsule radius">
						<view class="cu-tag bg-green">{{item.activityName}}</view>
					</view>
					<view class="margin-top-sm">
						志愿者需求：{{item.activityVolNum}}</view>
					<view class="margin-top-sm" v-if="item.volStartEnrollTime != null">
						志愿报名开始时间：{{item.volStartEnrollTime}}</view>
				</view>
			</view>
			<!-- 正在报名 -->
			<view class="cu-time">
				<text class='cuIcon-rank text-white text-lg bg-green round padding-xs'></text>
				<text class='text-xl margin-left'>志愿活动报名中</text>
			</view>
			<view class="cu-item text-green" v-if="item.activityVolStatus == 1" v-for="(item,index) in actList"
				:key="index" @>
				<view class="content">
					<view class="cu-capsule radius">
						<view class="cu-tag bg-green">{{item.activityName}}</view>
					</view>
					<view class="margin-top" v-if="item.activityBriefly != null">
						关联活动简介：{{item.activityBriefly}}</view>
					<view class="margin-top-sm">
						志愿者需求/成功报名：{{item.activityVolNum}} / {{item.activityHaveVolNum}}
					</view>
					<view class="margin-top-sm" v-if="item.activityStarttime != null">
						关联活动开始时间：{{item.activityStarttime}}
					</view>
					<view class="margin-top-sm" v-if="item.activityEndtime != null">关联活动结束时间：{{item.activityEndtime}}
					</view>
					<view class="margin-top-sm" v-if="item.volStartEnrollTime != null">
						志愿报名开始时间：{{item.volStartEnrollTime}}</view>
					<view class="margin-top-sm" v-if="item.volEndEnrollTime != null ">
						志愿报名结束时间：{{item.volEndEnrollTime}}</view>
					<view class="margin-top-sm" v-if="item.activityOrganizer != null">主办单位：{{item.activityOrganizer}}
					</view>
					<view class="margin-top-sm" v-if="item.isJoin == 1"><button
							@click="gotoapplyone(item)">查看志愿信息(审核中)</button></view>
					<view class="margin-top-sm" v-if="item.isJoin == 2"><button
							@click="gotoapplyone(item)">查看志愿信息</button></view>
					<view class="margin-top-sm" v-if="item.isJoin == 3"><button
							style="background-color: #ffaa00; color: #ffffff;" type="warn"
							disabled="true">审核未通过</button></view>
					<view class="margin-top-sm"
						v-if="item.isJoin == 4 && (item.activityVolNum - item.activityHaveVolNum) > 0 "><button
							@click="gotoapplyone(item)">前往志愿报名</button></view>
					<view class="margin-top-sm"
						v-if="item.isJoin == 4 && item.activityHaveVolNum == item.activityVolNum"><button
							style="background-color: #b6b6b6; color: #ffffff;" type="warn"
							disabled="true">报名人数已满</button></view>
					<view class="margin-top-sm"
						v-if="item.isJoin == 4 && (item.activityVolNum - item.activityHaveVolNum) < 0 "><button
							style="background-color: #b6b6b6; color: #ffffff;" type="warn"
							disabled="true">报名人数已满</button></view>
				</view>
			</view>
			<!-- 志愿活动进行中 -->
			<view class="cu-time">
				<text class='cuIcon-icloading text-white text-lg bg-orange round padding-xs'></text>
				<text class='text-xl margin-left'>志愿活动进行中</text>
			</view>
			<view class="cu-item text-orange" v-if="item.activityVolStatus == 2 || item.activityVolStatus == 3"
				v-for="(item,index) in actList" :key="index" @>
				<view class="content">
					<view class="cu-capsule radius">
						<view class="cu-tag bg-orange">{{item.activityName}}</view>
					</view>
					<view class="margin-top" v-if="item.activityBriefly != null">
						关联活动简介：{{item.activityBriefly}}</view>
					<view class="margin-top-sm">
						志愿者数量：{{item.activityHaveVolNum}}
					</view>
					<view class="margin-top-sm" v-if="item.activityStarttime != null">
						关联活动开始时间：{{item.activityStarttime}}
					</view>
					<view class="margin-top-sm" v-if="item.activityEndtime != null">关联活动结束时间：{{item.activityEndtime}}
					</view>
					<view class="margin-top-sm" v-if="item.activityOrganizer != null">主办单位：{{item.activityOrganizer}}
					</view>
					<view class="margin-top-sm" v-if="item.isJoin == 1">
						<button@click="gotoapplyone(item)">查看志愿信息(审核中)</button>
					</view>
					<view class="margin-top-sm" v-if="item.isJoin == 2">
						<button@click="gotoapplyone(item)">查看志愿信息</button>
					</view>
					<view class="margin-top-sm" v-if="item.isJoin == 3">{{user.username}} 同志，很遗憾，您并未通过此次审核。</view>
					<view class="margin-top-sm" v-if="item.isJoin == 4">{{user.username}} 同志，您并未报名本次志愿活动。</view>
				</view>
			</view>
			<!-- 比赛已结束 -->
			<view class="cu-time">
				<text class='cuIcon-roundcheck text-white text-lg bg-red round padding-xs'></text>
				<text class='text-xl margin-left'>志愿活动已结束</text>
			</view>
			<view class="cu-item text-red" v-if="item.activityVolStatus == 4" v-for="(item,index) in actList"
				:key="index" @>
				<view class="content">
					<view class="cu-capsule radius">
						<view class="cu-tag bg-red">{{item.activityName}}</view>
					</view>
					<view class="margin-top" v-if="item.activityBriefly != null">
						关联活动简介：{{item.activityBriefly}}</view>
					<view class="margin-top-sm" v-if="item.activityOrganizer != null">主办单位：{{item.activityOrganizer}}
					</view>
					<view class="margin-top-sm" v-if="item.isJoin == 2">
						{{item.activityName}} 志愿活动感谢 {{user.username}} 同志的付出！本次志愿活动共计 {{item.activityHaveVolNum}}
						人参与，因为有你们的付出，网络工程系将会更加优秀！
					</view>
					<view class="margin-top-sm" v-if="item.isJoin != 2">
						{{item.activityName}} 志愿活动感谢 {{item.activityHaveVolNum}} 人付出，为了共同创建更优秀的网络工程系，期待下次
						{{user.username}} 同志的参与！
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				user: {},
				token: {},
				actList: []
			};
		},
		onShow() {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			this.actlist();
		},
		methods: {
			actlist: function() {
				var that = this;
				let datas = {
					userid: this.user.userid,
				}
				that.request("vol/activityList", datas, 'GET').then(res => {
					that.actList = res.data.list
					let list = that.actList.map((item) => {
						item.activityId = item.activityId + "";
						item.activityParStatus = item.activityParStatus + "";
						item.activityVolStatus = item.activityVolStatus + "";
						item.version = item.version + "";
						item.isJoin = item.isJoin + "";
						item.isDisplay = item.isDisplay + "";
						item.activityParNum = item.activityParNum + "";
						return item
					})
					that.actList = list
				});
			},
			gotoapplyone(item) {
				var items = JSON.stringify(item);
				uni.redirectTo({
					url: '/pages/index/volunteer/volunteerjoin?data=' + items,
				});
			},
		}
	};
</script>

<style lang="scss" scoped>
	/* #ifndef H5 */
	page {
		height: 100%;
		background-color: #f2f2f2;
	}

	/* #endif */
</style>

<style lang="scss" scoped>
	.cu-timeline .cu-time {
		width: 100%;
		text-align: left;
		padding: 20rpx 0 20rpx 37rpx;
		font-size: 26rpx;
		color: #888;
		display: block;
	}

	.btn2 {
		background-color: #ff5500;
		color: #ffffff;
	}


	.text-red,
	.line-red,
	.lines-red {
		color: #FF3434;
	}

	.cu-timeline button {
		font-size: 30rpx;
		background: #55aaff;
		color: #fff;
		top: 20rpx;
		height: 70rpx;
		line-height: 70rpx;
		border-radius: 50rpx;
		box-shadow: 0 5px 7px 0 rgba(85, 170, 255, 0.2);
	}

	.margin-avatar {
		margin-left: -15rpx;
	}

	.margin-avatar-bottom {
		margin-bottom: 150rpx;
	}

	.line-blue-tuniao::after {
		border-color: #0070ff !important;
		color: #0070ff;
	}

	.resume {
		padding-top: 10rpx;
		border-radius: 6rpx;
		display: block;
		color: #666;
		line-height: 1.6;
	}

	.resume+.resume {
		margin-top: 20rpx;
	}

	.resume2 {
		padding-top: 10rpx;
		border-radius: 6rpx;
		display: block;
		color: #666;
		line-height: 1.6;
	}

	.edit {
		position: fixed;
		width: 100rpx;
		height: 100rpx;
		bottom: 250rpx;
		right: 30rpx;
		z-index: 1;
		opacity: 0.8;
		border: 1px solid #189eff;
		border-radius: 100rpx;
		box-shadow: 0rpx 0rpx 6rpx rgba(24, 158, 255, 1);
		padding: 20rpx;
	}

	.love {
		position: fixed;
		width: 100rpx;
		height: 100rpx;
		bottom: 550rpx;
		right: 30rpx;
		z-index: 1024;
		opacity: 0.8;
		border: 1px solid #189eff;
		border-radius: 100rpx;
		box-shadow: 0rpx 0rpx 6rpx rgba(24, 158, 255, 1);
		padding: 20rpx;
	}

	.bg-img-cont {
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 350rpx;
	}

	.share-png {
		width: 100rpx;
		height: 100rpx;
		margin: 0 auto;
	}

	.share-wechat {
		width: 35rpx;
		height: 35rpx;
		margin: 0 10rpx -4rpx 0;
		opacity: 0.5;
	}

	.button-no::after {
		border: none;
	}

	.title-pyq {
		background-image: -webkit-linear-gradient(0deg, #1b6cff, #1ca5ff);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
		opacity: 0.5;
	}

	.edit-fixed {
		position: fixed;
		width: 100%;
		bottom: 0;
		z-index: 1024;
		box-shadow: 0 1rpx 6rpx rgba(0, 0, 0, 0.1);
	}

	.button-no {
		border: none;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0);
	}

	.centre {
		text-align: center;
		margin: 200rpx auto;
		font-size: 32rpx;

		image {
			width: 300rpx;
			border-radius: 50%;
			margin: 0 auto;
		}

		.tips {
			font-size: 24rpx;
			color: #999999;
			margin-top: 20rpx;
		}

		.btn {
			margin: 80rpx auto;
			width: 200rpx;
			border-radius: 32rpx;
			line-height: 64rpx;
			color: #ffffff;
			font-size: 26rpx;
			background: linear-gradient(270deg, #1cbbb4 0%, #0081ff 100%);
		}
	}

	.wrap {
		display: flex;
		flex-direction: column;
		height: calc(100vh - var(--window-top));
		width: 100%;
	}

	.swiper-box {
		flex: 1;
	}

	.swiper-item {
		height: 100%;
	}
</style>
