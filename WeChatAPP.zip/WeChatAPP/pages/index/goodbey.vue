<!-- 
@author : Yingming
@date : 2023
@description : 终于必要毕业啦，其实大学生活有快乐，也有不快乐，但是也算是完成了人生的一个阶段吧，下一个阶段又要开始了，不知道又有什么不一样的精彩事情发生呢，期待一下吧~
-->
<template>
	<view class="components-bggrad">
		<swiper class="swiper-container" :autoplay="3000" v-if="user.userid != null && user.userid != ''">
			<swiper-item v-for="(image, index) in images" :key="index">
				<img :src="image.src" alt="" class="swiper-image" />
			</swiper-item>
			<div class="swiper-pagination"></div>
		</swiper>
		<div class="text-container" v-if="user.userid != null && user.userid != ''">
			<p>网络工程系祝</p>
			<p>{{ texts[currentIndex] }}</p>
			<p>未来可期</p>
		</div>
		<div class="boarding-pass">
			<div class="header">
				<img class="logo" src="https://base.cloudcode.team/wechat/image/Logo-SCS.png" alt="Logo">
				<div class="boarding-pass-title">网络工程系车票</div>
				<img class="barcode" src="https://base.cloudcode.team/wechat/image/CCLogo.png" alt="Barcode">
			</div>
			<div class="content">
				<div class="row">
					<div class="label">车票编号</div>
					<div class="value">{{ user.userid }}</div>
				</div>
				<div class="row">
					<div class="label">搭乘车次</div>
					<div class="value">G{{ classnum }}</div>
				</div>
				<div class="row">
					<div class="label">乘车人</div>
					<div class="value">{{ user.username }}</div>
				</div>
				<div class="row">
					<div class="label">出发地</div>
					<div class="value">20{{ onetwo }}.09入学</div>
				</div>
				<div class="row">
					<div class="label">目的地</div>
					<div class="value">20{{ onetwo12 }}.06毕业</div>
				</div>
				<div class="row">
					<div class="label">所需时间</div>
					<div class="value">4年整</div>
				</div>
				<div class="row">
					<div class="label">座位</div>
					<div class="value">头等舱</div>
				</div>
			</div>
			<div class="footer">
				<div class="qr-code">
					<canvas class="qr-code-image" id="qrcode" canvas-id="qrcode"
						style="width: 40px; height: 40px;"></canvas>
				</div>
				<div class="text">
					<p>{{zhufu[currentIndexzhufu] }}</p>
				</div>
			</div>
		</div>
	</view>
</template>

<script>
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	import UQRCode from '@/node_modules/uqrcodejs/uqrcode.js';
	export default {
		data() {
			return {
				user: {},
				classnum: "",
				onetwo: "",
				onetwo12: "",
				Custom: this.Custom,
				playlist: [{
						title: 'Music 1',
						src: 'https://base.cloudcode.team/music/light.mp3'
					},
					{
						title: 'Music 2',
						src: 'https://base.cloudcode.team/music/seegoodbey.mp3'
					},
					{
						title: 'Music 3',
						src: 'https://base.cloudcode.team/music/wind.mp3'
					},
					{
						title: 'Music 4',
						src: 'https://base.cloudcode.team/music/flower.mp3'
					},
					{
						title: 'Music 5',
						src: 'https://base.cloudcode.team/music/fenghh.mp3'
					}
				],
				currentMusicIndex: 0,
				images: [{
						src: "https://base.cloudcode.team/music/image/005.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/012.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/013.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/018.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/007.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/008.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/001.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/014.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/003.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/004.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/006.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/002.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/009.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/010.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/015.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/016.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/017.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/023.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/020.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/021.jpg",
					},
					{
						src: "https://base.cloudcode.team/music/image/022.jpg",
					},
				],
				texts: [
					"网络工程19201-王宇",
					"网络工程19201-王子林",
					"网络工程19201-张继远",
					"网络工程19201-肖锋",
					"网络工程19201-杨俊龙",
					"网络工程19201-敬清川",
					"网络工程19201-雷德红",
					"网络工程19201-杨莉",
					"网络工程19201-王鑫",
					"网络工程19201-杨碧万",
					"网络工程19201-胡杰",
					"网络工程19201-毛荟萃",
					"网络工程19201-王曾可",
					"网络工程19201-张千辉",
					"网络工程19201-冯洋",
					"网络工程19201-王光源",
					"网络工程19201-帅国强",
					"网络工程19201-于滋润",
					"网络工程19201-龚治伟",
					"网络工程19201-田鑫",
					"网络工程19201-陶维俊",
					"网络工程19201-李尊信",
					"网络工程19201-肖山雄",
					"网络工程19201-杨潍墐",
					"网络工程19201-王加军",
					"网络工程19201-杨鸿翔",
					"网络工程19201-张家豪",
					"网络工程19201-廖鑫",
					"网络工程19201-田俊朗",
					"网络工程19201-吴沐霖",
					"网络工程19201-孙晨帅",
					"网络工程19201-余卓凡",
					"网络工程19202-李应涛",
					"网络工程19202-周施宇",
					"网络工程19202-徐彬洋",
					"网络工程19202-麦丰超",
					"网络工程19202-夏美玉",
					"网络工程19202-李想",
					"网络工程19202-姚顺贵",
					"网络工程19202-姜智豪",
					"网络工程19202-王选祥",
					"网络工程19202-张瑛铭",
					"网络工程19202-王宇恒",
					"网络工程19202-张春梅",
					"网络工程19202-刘菁菁",
					"网络工程19202-张宇博",
					"网络工程19202-兰天航",
					"网络工程19202-杨咏涵",
					"网络工程19202-刁攀登",
					"网络工程19202-钟桂兰",
					"网络工程19202-罗丹",
					"网络工程19202-游志腾",
					"网络工程19202-谭天祥",
					"网络工程19202-蒋鹏",
					"网络工程19202-罗岷江",
					"网络工程19202-杨宇",
					"网络工程19202-周俊杰",
					"网络工程19202-文亮",
					"网络工程19202-黄浩聪",
					"网络工程19202-张明江",
					"网络工程19202-沈俊",
					"网络工程19202-陆杰",
					"网络工程19202-曹佳莉",
					"网络工程19203-于欣",
					"网络工程19203-何长林",
					"网络工程19203-庞蘅萌",
					"网络工程19203-许书华",
					"网络工程19203-李尚霖",
					"网络工程19203-杨睿勋",
					"网络工程19203-钟元常",
					"网络工程19203-李坤",
					"网络工程19203-门杰",
					"网络工程19203-杨望",
					"网络工程19203-孙福林",
					"网络工程19203-李林",
					"网络工程19203-陈佳豪",
					"网络工程19203-蒋诗语",
					"网络工程19203-白雨胶",
					"网络工程19203-夏竣峰",
					"网络工程19203-吴竞之",
					"网络工程19203-赵静文",
					"网络工程19203-蒋小可",
					"网络工程19203-肖梦琳",
					"网络工程19203-黄云",
					"网络工程19203-赵九州",
					"网络工程19203-岳大鹏",
					"网络工程19203-张兴玖",
					"网络工程19203-赵崇淋",
					"网络工程19203-李毅",
					"网络工程19203-邓薇然",
					"网络工程19203-王鹏",
					"网络工程19203-陈善杰",
					"网络工程19203-王海燕",
					"网络工程19203-陈婕妤",
					"网络工程19204-谭松",
					"网络工程19204-张绍峰",
					"网络工程19204-李婷婷",
					"网络工程19204-刘康林",
					"网络工程19204-张耀文",
					"网络工程19204-杨博文",
					"网络工程19204-涂田田",
					"网络工程19204-程天力",
					"网络工程19204-孙德斌",
					"网络工程19204-甘道明",
					"网络工程19204-王曾真",
					"网络工程19204-朱宇",
					"网络工程19204-蒋紫龙",
					"网络工程19204-罗果",
					"网络工程19204-戴汶霖",
					"网络工程19204-陈荣竹",
					"网络工程19204-黄光静",
					"网络工程19204-杜鑫明",
					"网络工程19204-蒲星雨",
					"网络工程19204-汤成芮",
					"网络工程19204-饶红林",
					"网络工程19204-谭坤",
					"网络工程19204-郑爽",
					"网络工程19204-何宇驰",
					"网络工程19204-王继奥",
					"网络工程19204-赵浚良",
					"网络工程19204-廖思轲",
					"网络工程19204-邓成",
					"网络工程19204-李佳勋",
					"网络工程19204-梁洪",
					"网络工程19204-白博维",
					"网络工程19201-鲁汶",
				],
				zhufu: [
					"来自19级：前程似锦，一路生花；钱包鼓鼓，桃花朵朵",
					"来自19级：带上梦想，飞向远方，勇敢一点！",
					"来自21级：祝各位学长学姐们工作顺利，万事如意，赚大钱！",
					"来自21级：愿你们都有一往直前的勇气去面对未来的风风雨雨",
					"来自21级：少掉头发",
					"来自21级：所求皆如愿，所行皆坦途，前程似锦毕业快乐",
					"来自20级：“悟已往之不谏，知来者之可追”，新的开始，新的起点，愿祝各位师兄师姐在理想的道路上，热烈且精彩",
					"来自21级：何日功成名遂了，还乡，醉笑陪公三万场",
					"来自19级：你总说毕业遥遥无期，转眼就各奔东西。",
					"来自19级：山水一程，三生有幸，就此别过，莫问前程，山高水长，江湖莫忘 。",
					"来自19级：前途似海，来日方长。我们以梦为马，不负韶华。",
					"来自21级：从此一别，隔世经年，山长水阔。唯愿君，平安喜乐，不知流年。",
					"来自21级：愿你们未来前程似锦，冬去春来，前无近忧，后无远虑。",
					"来自19级：春去极晚，夏来极迟，祝我们毕业快乐。",
					"来自19级：愿你逢山开路，遇水搭桥。愿你坚持努力，遇见幸运。",
					"来自20级：毕业在兵荒马乱中如期而至，青春在跌跌撞撞中戛然而止。",
					"来自20级：愿少年，乘风破浪，他日毋忘破浪功。",
					"来自20级：我本有心，勿用言语。山高水长，望君珍重。",
					"来自22级：如果相遇是离别的开始，那么离别也是为了下一次相遇而做准备。",
					"来自22级：一定都要站在你们所热爱的世界里闪闪发光。",
					"来自22级：山野皆有雾灯，漂泊亦能归舟。所遇皆良善，所行化坦途。",
					"来自22级：愿你经历世事而不失少年意趣，仍能保持坚定与热爱，依然能够为世间那些真情而心动。",
					"来自22级：“真正的离别没有长亭古道，也没有劝君更进一杯酒。只是在某一个和往常一样的清晨，有人留在了昨天” 。“请君看取东流水，方识人间别意长。”愿祝各位19级的师兄师姐，前程似锦，未来可期，归来仍是少年！",
					],
				currentIndex: 0,
				currentIndexzhufu: 0,
				timer: null,
				timerzhufu: null,
			}
		},
		mounted() {
			this.startTimer();
			this.startTimerzhufu();
		},
		beforeDestroy() {
			this.stopTimer();
			this.stopTimerzhufu();
		},
		onUnload() {
			// 停止当前正在播放的音乐
			this.audioCtx.stop();
			// 释放音频上下文对象
			this.audioCtx.destroy();
		},
		onLoad() {
			this.user = getUserInfo() || {};
			// 随机选择一首音乐进行播放
			this.currentMusicIndex = Math.floor(Math.random() * this.playlist.length);
			this.playMusic();
			this.text = this.user.userid;
			let str = this.user.className;
			let lastFive = str.slice(-5);
			this.classnum = lastFive;
			let myString = this.user.userid;;
			let firstTwoDigits = myString.substr(0, 2); // 提取前两个数字
			this.onetwo = firstTwoDigits;
			let newNumber = parseInt(firstTwoDigits) + 4; // 将数字解析为整数并加4
			this.onetwo12 = newNumber;
			//下面为二维码生成
			var qr = new UQRCode();
			// 设置二维码内容
			qr.data = this.text;
			// 设置二维码大小，必须与canvas设置的宽高一致
			qr.size = 40;
			// 调用制作二维码方法
			qr.make();
			// 获取canvas上下文
			var canvasContext = uni.createCanvasContext('qrcode', this); // 如果是组件，this必须传入
			// 设置uQRCode实例的canvas上下文
			qr.canvasContext = canvasContext;
			// 调用绘制方法将二维码图案绘制到canvas上
			qr.drawCanvas();
		},
		methods: {
			playMusic() {
				// 创建音频上下文对象
				this.audioCtx = uni.createInnerAudioContext();
				// 设置音频资源地址
				this.audioCtx.src = this.playlist[this.currentMusicIndex].src;
				//控制音量大小
				this.audioCtx.volume = 0.2;
				// 监听音乐播放完成事件
				this.audioCtx.onEnded(() => {
					// 切换到下一首音乐进行播放
					this.currentMusicIndex = (this.currentMusicIndex + 1) % this.playlist.length;
					this.audioCtx.src = this.playlist[this.currentMusicIndex].src;
					this.audioCtx.play();
				});
				// 播放音乐
				this.audioCtx.play();
			},
			startTimer() {
				this.stopTimer();
				this.timer = setInterval(() => {
					this.currentIndex = Math.floor(Math.random() * this.texts.length);
				}, 3000);
			},
			stopTimer() {
				clearInterval(this.timer);
				this.timer = null;
			},
			startTimerzhufu() {
				this.stopTimerzhufu();
				this.timerzhufu = setInterval(() => {
					this.currentIndexzhufu = Math.floor(Math.random() * this.zhufu.length);
				}, 2000);
			},
			stopTimerzhufu() {
				clearInterval(this.timerzhufu);
				this.timerzhufu = null;
			},
		},
	}
</script>

<style scoped>
	.components-bggrad {
		margin: 0;
		width: 100%;
		height: 100vh;
		color: #fff;
		background: linear-gradient(45deg, #00ff7f, #00F5D4, #01BEFF, #9A5CE5, #F15BB5);
		background-size: 600% 600%;
		animation: gradientBG 15s ease infinite;
	}

	@keyframes gradientBG {
		0% {
			background-position: 0% 50%;
		}

		50% {
			background-position: 100% 50%;
		}

		100% {
			background-position: 0% 50%;
		}
	}

	.container {
		width: 100%;
		position: absolute;
		text-align: center;
	}

	.swiper-container {
		height: 450rpx;
		width: 100%;
	}

	.swiper-image {
		width: 100%;
		height: 100%;
		object-fit: cover;
	}

	.image-container {
		height: 450rpx;
		width: 100%;
		position: relative;
	}

	.image {
		width: 100%;
		height: 100%;
		object-fit: cover;
	}

	.text-container {
		width: 100%;
		padding: 20rpx;
		box-sizing: border-box;
	}

	.text-container p {
		margin: 0;
		font-size: 40rpx;
		line-height: 50rpx;
		text-align: center;
	}

	/* 车票开始 */
	.boarding-pass {
		width: 90%;
		max-width: 750px;
		margin: 0 auto;
		padding: 5vw;
		font-family: Arial, Helvetica, sans-serif;
		background-color: #1aadec;
		box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
	}

	.header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 5vw;
	}

	.logo {
		height: 12vw;
		width: 12vw;
	}

	.boarding-pass-title {
		font-size: 5vw;
		font-weight: bold;
	}

	.barcode {
		height: 12vw;
		width: 12vw;
	}

	.content {
		margin-top: 5vw;
	}

	.row {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-top: 3vw;
	}

	.label {
		font-size: 4vw;
		font-weight: bold;
	}

	.value {
		font-size: 4vw;
	}

	.footer {
		display: flex;
		align-items: center;
		margin-top: 6vw;
	}

	.qr-code {
		height: 44px;
		width: 44px;
		border: 1px solid #707070;
		margin-right: 5vw;
		padding: 1px;
		box-sizing: border-box;
	}

	.qr-code-image {
		height: 100%;
		width: 100%;
	}

	.text {
		font-size: 3vw;
		color: #707070;
	}
</style>
