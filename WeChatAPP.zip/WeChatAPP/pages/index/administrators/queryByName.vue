<!-- 
@author : Zhouhao、Yunmeng、Yingming
@date : 2023
@description : 用户信息查询，管理员、教师可进行查询
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<!--用户查询-->
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">用户查询</text>
							<text class="text-ABC text-blue">UserQuery</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class="action" >
							<input type="number" name="phone" placeholder="请输入学号" maxlength="11" v-model="inputData" />
						</view>
					</view>
					<view class="cha">
						<button class="bg-blue" @click="query()">点击查询</button>
						<view style="height: 20rpx;width: 1rpx;"></view>
					</view>
				</view>
			</view>
		</view>
		<view style="height: 40rpx;width: 1rpx;"></view>
		<!--用户信息-->
		<view class="center-box1 shadow">
			<view class="cu-list menu" v-for="(item,index) in userList" :key="index" @>
				<view class="cu-bar bg-white margin-top-xs u-border-bottom">
					<view class="action sub-title">
						<text class="text-xl text-bold text-blue text-shadow">用户信息</text>
						<text class="text-ABC text-blue">information</text>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.userid != null">
					<view class='content'>
						<text class="cuIcon-favor text-blue"></text>
						<text class='text-lg'>学号</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.userid}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.username != null">
					<view class="content">
						<text class="cuIcon-my text-blue"></text>
						<text class="text-lg">姓名</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.username}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.idNum != null">
					<view class='content'>
						<text class="cuIcon-copy text-blue"></text>
						<text class='text-lg'>身份证号</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.idNum}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.birthday != null">
					<view class='content'>
						<text class="cuIcon-time text-blue"></text>
						<text class='text-lg'>出生日期</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.birthday}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.sos1Phone != null">
					<view class='content'>
						<text class="cuIcon-phone text-blue"></text>
						<text class='text-lg'>紧急联系人1电话</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.sos1Phone}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.sos2Phone != null">
					<view class='content'>
						<text class="cuIcon-phone text-blue"></text>
						<text class='text-lg'>紧急联系人2电话</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.sos2Phone}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.classIdentity != null">
					<view class='content'>
						<text class="cuIcon-message text-blue"></text>
						<text class='text-lg'>班委身份</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.classIdentity}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.clubIdentity != null">
					<view class='content'>
						<text class="cuIcon-friend text-blue"></text>
						<text class='text-lg'>所属社团</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.clubIdentity}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.clubIdentityRole != null">
					<view class='content'>
						<text class="cuIcon-ticket text-blue"></text>
						<text class='text-lg'>社团身份</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.clubIdentityRole}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.studentUnion != null">
					<view class='content'>
						<text class="cuIcon-newshot text-blue"></text>
						<text class='text-lg'>学生会</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.studentUnion}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.studentUnionRole != null">
					<view class='content'>
						<text class="cuIcon-ticket text-blue"></text>
						<text class='text-lg'>学生会身份</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.studentUnionRole}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.dormitory != null">
					<view class='content'>
						<text class="cuIcon-text text-blue"></text>
						<text class='text-lg'>宿舍</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.dormitory}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.address != null">
					<view class='content'>
						<text class="cuIcon-home text-blue"></text>
						<text class='text-lg'>家庭地址</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.address}}
						</view>
					</view>
				</view>
				<view class="cu-item" style="padding: 0;" v-if="item.remark != null">
					<view class='content'>
						<text class="cuIcon-tag text-blue"></text>
						<text class='text-lg'>备注</text>
					</view>
					<view class="action">
						<view class="cu-tag round bg-blue light">
							{{item.remark}}
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				inputData: '',
				user: {},
				token: {},
				userList: []
			};
		},
		onShow() {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},
		methods: {
			query() {
				this.userList = [];
				var that = this;
				let datas = {
					userid: this.inputData,
				}
				if (!/^[1,2][0-9]{10}$/.test(this.inputData)) {
					uni.showToast({
						title: '您的输入有误！',
						icon: 'error',
						duration: 2000
					});
				} else {
					console.log(this.inputData)
					if (this.inputData != "") {
						that.request("wxuserdatasheet", datas, 'GET').then(res => {
							if (res.data != '') {
								that.userList = res.data
							} else {
								uni.showToast({
									title: '查无此人',
									icon: 'error',
									duration: 2000
								});
							}
						});
					}
				}
			}
		}
	};
</script>

<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.containera {
			margin: 0 auto;
			width: 750rpx;
		}

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					min-height: 100rpx;
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.cha {
			text-align: right;
			justify-content: center;
			align-items: center;

		}

		.cl {
			zoom: 1;
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}

		.center-box1 {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
			top: 130rpx
		}

	}

	// 列表
	.rankList_box {
		width: 750rpx;
		min-height: 200rpx;
		margin-top: 130rpx;
	}

	.rankItem:last-child {
		border: none;
	}

	.rankItem {
		width: 700rpx;
		height: 140rpx;
		margin: 0px auto;
		border-bottom: 1px solid #e9e9e9;
	}

	.rankIndex {
		width: 60rpx;
		height: 140rpx;
		line-height: 140rpx;
		text-align: center;
		color: #CCCCCC;
		font-size: 40rpx;
		float: left;
	}

	.HeardBox {
		width: 100rpx;
		height: 100rpx;
		margin: 20rpx;
		border-radius: 100%;
		overflow: hidden;
		float: left;
		margin-right: 25rpx;
		margin-left: 10rpx !important;
	}

	.HeardBox image {
		width: 100%;
		height: 100%;
	}

	.NameBox {
		width: 400rpx;
		height: 140rpx;
		float: left;
		padding-top: 10rpx;
		box-sizing: border-box;
	}

	.NameBox view {
		height: 50rpx;
		line-height: 70rpx;
	}

	.userName {
		min-width: 90rpx;
		font-size: 30rpx;
		float: left;
		margin-right: 20rpx;
	}

	.download_box {
		width: 80rpx;
		height: 140rpx;
		float: right;

	}

	.download_box image {
		width: 45rpx;
		margin: 50rpx auto;
		display: block;
	}

	.t-login .t-a {
		position: relative;
	}

	.t-login .t-a image {
		width: 40rpx;
		height: 40rpx;
		position: absolute;
		left: 40rpx;
		top: 28rpx;
		margin-right: 20rpx;
	}

	.t-login .t-a .line {
		width: 2rpx;
		height: 40rpx;
		background-color: #dedede;
		position: absolute;
		top: 28rpx;
		left: 98rpx;
	}
</style>
