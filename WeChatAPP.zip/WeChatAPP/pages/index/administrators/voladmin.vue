<!-- 
@author : Yingming
@date : 2023
@description : 志愿活动签到功能
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<!-- 暂无签到信息 -->
			<view class="center-box shadow" v-if="item.activityVolStatus == 3">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">扫码签到/签退</text>
							<text class="text-ABC text-blue">SCANCODE</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;"
						v-if="resultData.rest2 != item.activityId && resultData.rest2 !=null">
						<view class='content'>
							<text class="cu-tag round bg-pink light">Error</text>
						</view>
						<view class="action">
							<text class='text-black'>非本次志愿活动</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="type == 1">
						<view class='content'>
							<text class="cu-tag round bg-blue light">签到</text>
							<text class='text-black'> {{resultData.rest8}}</text>
						</view>
						<view class="action">
							<text class='text-black'>{{resultData.rest4}}</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="type == 8">
						<view class='content'>
							<text class="cu-tag round bg-yellow light">签退</text>
							<text class='text-black'> {{resultData.rest8}}</text>
						</view>
						<view class="action">
							<text class='text-black'>{{resultData.rest4}}</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="type == 2">
						<view class='content'>
							<text class="cu-tag round bg-pink light">Error801</text>
						</view>
						<view class="action">
							<text class='text-black'>请签到后再签退</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="type == 3">
						<view class='content'>
							<text class="cu-tag round bg-pink light">Error802</text>
						</view>
						<view class="action">
							<text class='text-black'>当前用户已签到，请核实</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="type == 4">
						<view class='content'>
							<text class="cu-tag round bg-pink light">Error803</text>
						</view>
						<view class="action">
							<text class='text-black'>签到签退间隔时间少于20分钟</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="type == 5">
						<view class='content'>
							<text class="cu-tag round bg-pink light">Error804</text>
						</view>
						<view class="action">
							<text class='text-black'>亮码时间与服务器时间超过10秒</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="type == 6">
						<view class='content'>
							<text class="cu-tag round bg-pink light">Error805</text>
						</view>
						<view class="action">
							<text class='text-black'>当前不在签到地点</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="type == 7">
						<view class='content'>
							<text class="cu-tag round bg-red light">警告</text>
						</view>
						<view class="action">
							<text class='text-black'>系统错误，请重试，多次错误请联系管理员</text>
						</view>
					</view>
					<view class="margin-top-sm" style="padding: 0;">
						<button class="bg-blue" @click="openScannerSignIn">扫描志愿者签到码</button>
					</view>
					<view class="margin-top-sm" style="padding: 0;">
						<button class="bg-yellow" @click="openScannerSignOut">扫描志愿者签退码</button>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<!-- 签到信息 -->
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">签到/签退信息</text>
							<text class="text-ABC text-blue">CheckInfo</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-for="(item,index) in UserList" :key="index" @>
						<view class='content'>
							<text class="cuIcon-my text-blue"></text>
							<text class='text-black'>{{item.username}}</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-orange light">
								第{{item.num}}次签到
							</view>
							<view class="cu-tag round bg-orange light" v-if="item.isSignIn == 1">
								未签到
							</view>
							<view class="cu-tag round bg-green light" v-if="item.isSignIn == 2 && item.isSignOut != 3">
								已签到
							</view>
							<view class="cu-tag round bg-orange light" v-if="item.isSignOut == 1">
								未签退
							</view>
							<view class="cu-tag round bg-green light" v-if="item.isSignOut == 2">
								已签退
							</view>
							<view class="cu-tag round bg-red light" v-if="item.isSignOut == 3">
								本条签到记录作废
							</view>
						</view>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<view style="height: 50rpx;width: 1rpx;"></view>
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				UserList: [],
				token: {},
				user: {},
				item: {},
				qrResult: '',
				type: '0',
				resultData: {},
			}
		},

		onLoad(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			var item = JSON.parse(options.data); // 字符串转对象
			this.item = item;
		},
		onShow(options) {
			this.showuser();
		},
		methods: {
			openScannerSignIn() {
				this.type = 0
				uni.scanCode({
					success: res => {
						this.qrResult = res.result;
						let resultList = this.qrResult.split(',');
						for (let i = 0; i < resultList.length; i++) {
							this.resultData['rest' + (i + 1)] = resultList[i];
						}
						if (this.resultData.rest2 == this.item.activityId) {
							var that = this;
							var activityId = Number(this.resultData.rest2)
							let datas = {
								activityId: activityId,
								activityName: this.resultData.rest3,
								isSignIn: 2,
								isSignOut: 1,
								userid: this.resultData.rest1,
								username: this.resultData.rest8,
								signInLatitude: this.resultData.rest5,
								signInLocation: this.resultData.rest7,
								signInLongitude: this.resultData.rest6,
								signInManagerId: this.user.userid,
								signInManagerName: this.user.username,
								signInTime: this.resultData.rest4,
							}
							that.request("wxattendace/signin", datas, 'POST').then(res => {
								if (res.code == 200) {
									uni.showToast({
										title: '签到成功',
										icon: 'success',
										duration: 1000,
									});
									this.type = 1
								}
								if (res.code == 801) {
									this.type = 2
								}
								if (res.code == 802) {
									this.type = 3
								}
								if (res.code == 803) {
									this.type = 4
								}
								if (res.code == 804) {
									this.type = 5
								}
								if (res.code == 805) {
									this.type = 6
								}
								if (this.type == 0) {
									this.type = 7
								}
							});
						}
					},
					fail: () => {
						console.log('扫码失败');
					}
				});
			},
			openScannerSignOut() {
				this.type = 0
				uni.scanCode({
					success: res => {
						this.qrResult = res.result;
						let resultList = this.qrResult.split(',');
						for (let i = 0; i < resultList.length; i++) {
							this.resultData['rest' + (i + 1)] = resultList[i];
						}
						if (this.resultData.rest2 == this.item.activityId) {
							var that = this;
							var activityId = Number(this.resultData.rest2)
							let datas = {
								activityId: activityId,
								activityName: this.resultData.rest3,
								isSignOut: 2,
								userid: this.resultData.rest1,
								username: this.resultData.rest8,
								signOutLatitude: this.resultData.rest5,
								signOutLocation: this.resultData.rest7,
								signOutLongitude: this.resultData.rest6,
								signOutManagerId: this.user.userid,
								signOutManagerName: this.user.username,
								signOutTime: this.resultData.rest4,
							}
							that.request("wxattendace/signout", datas, 'POST').then(res => {
								if (res.code == 200) {
									uni.showToast({
										title: '签退成功',
										icon: 'success',
										duration: 1000,
									});
									this.type = 8
								}
								if (res.code == 801) {
									this.type = 2
								}
								if (res.code == 802) {
									this.type = 3
								}
								if (res.code == 803) {
									this.type = 4
								}
								if (res.code == 804) {
									this.type = 5
								}
								if (res.code == 805) {
									this.type = 6
								}
								if (this.type == 0) {
									this.type = 7
								}
							});
						}
					},
					fail: () => {
						console.log('扫码失败');
					}
				});
			},
			showuser() {
				var that = this;
				var activityId = Number(this.item.activityId)
				let datas = {
					activityid: activityId,
				}
				that.request("wxattendace/getrole", datas, 'GET').then(res => {
					that.UserList = res.data;
					let list = that.UserList.map((item) => {
						item.isSignIn = item.isSignIn + "";
						item.isSignOut = item.isSignOut + "";
						item.activityId = item.activityId + "";
						item.id = item.id + "";
						item.num = item.num + "";
						return item
					})
					that.UserList = list;
				});
			},
		},
	}
</script>
<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.containera {
			margin: 0 auto;
			width: 750rpx;
		}

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					min-height: 100rpx;
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}

	}
</style>
