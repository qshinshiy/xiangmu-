<!-- 
@author : Yingming
@date : 2023
@description : 实验室OJ数据查询，结合标签进行查询，反馈7天数据
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<!--用户查询-->
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">网络工程实验室成员WCT数据</text>
							<text class="text-ABC text-blue">SCSTEAMWCTDATAS</text>
						</view>
					</view>
					<view class="center-box shadow">
						<view class="cu-list menu">
							<view class="cu-item" style="padding: 0;" v-for="(item,index) in OJList" :key="index" @
								v-if='item.userid != 19310220211 && item.userid != 19310220121 && item.userid !=20310220108 && item.userid !=21016021901'>
								<view class="content">
									<text class="cuIcon-list text-blue"></text>
									<text class="text-lg"
										v-if='item.judgeCnt == "null"'>{{item.username}} 截止7天前共完成0题</text>
									<text class="text-lg"
										v-if='item.judgeCnt != "null"'>{{item.username}} 截止7天前共完成{{item.judgeCnt}}题</text>
								</view>
							</view>
							<view style="height: 20rpx;width: 1rpx;"></view>
						</view>
					</view>
				</view>
				<view style="height: 20rpx;width: 1rpx;"></view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				OJList: [],
			}
		},
		onShow() {
			this.OJlist();
		},
		methods: {
			OJlist: function() {
				var that = this;
				that.request("oj/ojdata", 'GET').then(res => {
					that.OJList = res.data
					let list = that.OJList.map((item) => {
						item.judgeCnt = item.judgeCnt + "";
						return item
					})
					that.OJList = list
				});
			},
		},
	}
</script>


<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.containera {
			margin: 0 auto;
			width: 750rpx;
		}

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					min-height: 100rpx;
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.cha {
			text-align: right;
			justify-content: center;
			align-items: center;

		}

		.cl {
			zoom: 1;
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}

		.center-box1 {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
			top: 130rpx
		}

	}

	// 列表
	.rankList_box {
		width: 750rpx;
		min-height: 200rpx;
		margin-top: 130rpx;
	}

	.rankItem:last-child {
		border: none;
	}

	.rankItem {
		width: 700rpx;
		height: 140rpx;
		margin: 0px auto;
		border-bottom: 1px solid #e9e9e9;
	}

	.rankIndex {
		width: 60rpx;
		height: 140rpx;
		line-height: 140rpx;
		text-align: center;
		color: #CCCCCC;
		font-size: 40rpx;
		float: left;
	}

	.HeardBox {
		width: 100rpx;
		height: 100rpx;
		margin: 20rpx;
		border-radius: 100%;
		overflow: hidden;
		float: left;
		margin-right: 25rpx;
		margin-left: 10rpx !important;
	}

	.HeardBox image {
		width: 100%;
		height: 100%;
	}

	.NameBox {
		width: 400rpx;
		height: 140rpx;
		float: left;
		padding-top: 10rpx;
		box-sizing: border-box;
	}

	.NameBox view {
		height: 50rpx;
		line-height: 70rpx;
	}

	.userName {
		min-width: 90rpx;
		font-size: 30rpx;
		float: left;
		margin-right: 20rpx;
	}

	.download_box {
		width: 80rpx;
		height: 140rpx;
		float: right;

	}

	.download_box image {
		width: 45rpx;
		margin: 50rpx auto;
		display: block;
	}

	.t-login .t-a {
		position: relative;
	}

	.t-login .t-a image {
		width: 40rpx;
		height: 40rpx;
		position: absolute;
		left: 40rpx;
		top: 28rpx;
		margin-right: 20rpx;
	}

	.t-login .t-a .line {
		width: 2rpx;
		height: 40rpx;
		background-color: #dedede;
		position: absolute;
		top: 28rpx;
		left: 98rpx;
	}
</style>
