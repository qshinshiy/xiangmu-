<!-- 
@author : Yingming
@date : 2023
@description : 选择面试组织
-->
<template>
	<view class="components-home" style="height:100vh;background: #f0f0f0;">
		<view class="img-a">
			<view class="t-b">
				面试官您好，请选择面试组织
			</view>
		</view>
		<view class="login-view">
			<view class="flex" @click="enroll1()">
				<view class="flex-sub bg-white padding-sm margin-sm radius shadow-warp" style="line-height: 150rpx;">
					<image class="fl margin-right-sm" src="https://base.cloudcode.team/wechat/icon/logo.png"
						mode="widthFix" style="width: 160rpx;margin-top: 5rpx;"></image>
					<view class="text-shadow text-bold">云萌工作室</view>
				</view>
			</view>
			<view class="flex" @click="enroll2()">
				<view class="flex-sub bg-white padding-sm margin-sm radius shadow-warp" style="line-height: 150rpx;">
					<image class="fl margin-right-sm" src="https://base.cloudcode.team/wechat/image/SCSLAB.png"
						mode="widthFix" style="width: 180rpx;margin-top: 43rpx;"></image>
					<view class="text-shadow text-bold">网络工程实验室</view>
				</view>
			</view>
			<view class="flex" @click="enroll3()">
				<view class="flex-sub bg-white padding-sm margin-sm radius shadow-warp" style="line-height: 150rpx;">
					<image class="fl margin-right-sm" src="https://base.cloudcode.team/wechat/image/iCAN.png"
						mode="widthFix" style="width: 180rpx;margin-top: 47rpx;"></image>
					<view class="text-shadow text-bold">iCAN创新社</view>
				</view>
			</view>
			<!-- <view class="flex" @click="enroll4()">
				<view class="flex-sub bg-white padding-sm margin-sm radius shadow-warp" style="line-height: 150rpx;">
					<image class="fl margin-right-sm" src="https://base.cloudcode.team/wechat/image/Logo-SCS.png"
						mode="widthFix" style="width: 150rpx;margin-top: 5rpx;"></image>
					<view class="text-shadow text-bold">网络工程新媒体</view>
				</view>
			</view> -->
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import {
		getUserInfo,
		getToken
	} from '@/utils/auth';
	export default {
		data() {
			return {
				user: {},
				token: {},
				data1: '云萌工作室',
				data2: '网络工程实验室',
				data3: 'iCAN创新社',
				data4: '网络工程新媒体',
			}
		},
		onLoad(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},
		onShow(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},
		methods: {
			enroll1() {
				var items = JSON.stringify(this.data1);
				console.log(items)
				uni.redirectTo({
					url: '/pages/index/enroll/enrolladmin?data=' + items,
				});
			},
			enroll2() {
				// var that = this;

				var items = JSON.stringify(this.data2);
				console.log(items)
				uni.redirectTo({
					url: '/pages/index/enroll/enrolladmin?data=' + items,
				});
			},
			enroll3() {
				var items = JSON.stringify(this.data3);
				console.log(items)
				uni.redirectTo({
					url: '/pages/index/enroll/enrolladmin?data=' + items,
				});
			},
			enroll4() {
				// var that = this;
				var items = JSON.stringify(this.data4);
				console.log(items)
				uni.redirectTo({
					url: '/pages/index/enroll/enrolladmin?data=' + items,
				});
			},
			// enroll4() {
			// 	var items = JSON.stringify(this.data4);
			// 	console.log(items)
			// 	uni.redirectTo({
			// 		url: '/pages/index/enroll/enrolladmin?data=' + items,
			// 	});
			// },
		}
	}
</script>

<style lang="scss" scoped>
	.swiper-item {
		height: 100%;
	}

	.img-a {
		width: 100%;
		height: 450rpx;
		background-image: url(https://base.cloudcode.team/newbg/CloudCode2-3.png);
		background-size: 100%;
	}

	.t-b {
		text-align: left;
		font-size: 45rpx;
		color: #ffffff;
		padding: 130rpx 0 0 70rpx;
		font-weight: bold;
		line-height: 64rpx;
	}

	.login-view {
		width: 100%;
		position: relative;
		margin-top: -120rpx;
		background-color: #f0f0f0;
		border-radius: 8% 8% 0% 0;
	}

	.mainBox {
		width: 750rpx;
		height: 300rpx;
		padding: 0 5%;
		margin-bottom: 10rpx;

		.mainBtn {
			width: 45%;
		}
	}

	.radius {
		border-radius: 50rpx !important;
	}
</style>