<!-- 
@author : Yingming
@date : 2023
@description : 签到
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<!-- 暂无邀请信息 -->
			<view class="center-box shadow" v-if="resultData.rest1 == null">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">面试者信息</text>
							<text class="text-ABC text-blue">JOINTEAM</text>
						</view>
					</view>
					<view class="margin-top-sm" style="padding: 0;">
						<button class="bg-blue" @click="openScanner">扫描面试者二维码</button>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<!-- 受邀信息 -->
			<view class="center-box shadow" v-if="resultData.rest1 != null">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">面试者信息</text>
							<text class="text-ABC text-blue">InvitedInfo</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-info text-blue"></text>
							<text class='text-lg'>面试者姓名</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{resultData.rest2}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-info text-blue"></text>
							<text class='text-lg'>面试者班级</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{resultData.rest4}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-info text-blue"></text>
							<text class='text-lg'>面试者学号</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{resultData.rest1}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-info text-blue"></text>
							<text class='text-lg'>面试者联系电话</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{resultData.rest3}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class="content">
							<text class="cuIcon-my text-blue"></text>
							<text class="text-lg">面试官</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-orange light">
								{{user.username}}
							</view>
						</view>
					</view>

					<view class="content">
						<form @submit="formSubmit">
							<view style="height:20rpx"></view>
							<select-lay :zindex="1411" :value="tval1" name="name" placeholder="请评分" :options="datalist1"
								@selectitem="selectitem1">
							</select-lay>
							<view style="height:20rpx"></view>
						</form>
					</view>
					<view style="height: 280rpx;width: 1rpx;"></view>


					<view class="margin-top-sm" style="padding: 0;">
						<button class="bg-blue" @click="sure">提交成绩</button>
					</view>
					<view style="height: 5rpx;width: 1rpx;"></view>
					<view class="margin-top-sm" style="padding: 0;">
						<button class="bg-green" @click="openScanner">重新扫描</button>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<view style="height: 50rpx;width: 1rpx;"></view>
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				datalist1: [],
				tval1: "",
				score: "",
				token: {},
				user: {},
				item: {},
				qrResult: '',
				type: '',
				resultData: {},
			}
		},
		onReady() {
			this.datalist1 = [{
					label: "0",
					value: "value1"
				},
				{
					label: "1",
					value: "value2"
				},
				{
					label: "2",
					value: "value3"
				},
				{
					label: "3",
					value: "value4"
				},
				{
					label: "4",
					value: "value5"
				},
				{
					label: "5",
					value: "value6"
				},
				{
					label: "6",
					value: "value7"
				},
				{
					label: "7",
					value: "value8"
				},
				{
					label: "8",
					value: "value9"
				},
				{
					label: "9",
					value: "value10"
				},
				{
					label: "10",
					value: "value11"
				},
				{
					label: "11",
					value: "value12"
				},
				{
					label: "12",
					value: "value13"
				},
				{
					label: "13",
					value: "value14"
				},
				{
					label: "14",
					value: "value15"
				},
				{
					label: "15",
					value: "value16"
				},
				{
					label: "16",
					value: "value17"
				},
				{
					label: "17",
					value: "value18"
				},
				{
					label: "18",
					value: "value19"
				},
				{
					label: "19",
					value: "value20"
				},
				{
					label: "20",
					value: "value21"
				},
				{
					label: "21",
					value: "value22"
				},
				{
					label: "22",
					value: "value23"
				},
				{
					label: "23",
					value: "value24"
				},
				{
					label: "24",
					value: "value25"
				},
				{
					label: "25",
					value: "value26"
				},
				{
					label: "26",
					value: "value27"
				},
				{
					label: "27",
					value: "value28"
				},
				{
					label: "28",
					value: "value29"
				},
				{
					label: "29",
					value: "value30"
				},
				{
					label: "30",
					value: "value31"
				},
				{
					label: "31",
					value: "value32"
				},
				{
					label: "32",
					value: "value33"
				},
				{
					label: "33",
					value: "value34"
				},
				{
					label: "34",
					value: "value35"
				},
				{
					label: "35",
					value: "value36"
				},
				{
					label: "36",
					value: "value37"
				},
				{
					label: "37",
					value: "value38"
				},
				{
					label: "38",
					value: "value39"
				},
				{
					label: "39",
					value: "value40"
				},
				{
					label: "40",
					value: "value41"
				},
				{
					label: "41",
					value: "value42"
				},
				{
					label: "42",
					value: "value43"
				},
				{
					label: "43",
					value: "value44"
				},
				{
					label: "44",
					value: "value45"
				},
				{
					label: "45",
					value: "value46"
				},
				{
					label: "46",
					value: "value47"
				},
				{
					label: "47",
					value: "value48"
				},
				{
					label: "48",
					value: "value49"
				},
				{
					label: "49",
					value: "value50"
				},
				{
					label: "50",
					value: "value51"
				},
				{
					label: "51",
					value: "value52"
				},
				{
					label: "52",
					value: "value53"
				},
				{
					label: "53",
					value: "value54"
				},
				{
					label: "54",
					value: "value55"
				},
				{
					label: "55",
					value: "value56"
				},
				{
					label: "56",
					value: "value57"
				},
				{
					label: "57",
					value: "value58"
				},
				{
					label: "58",
					value: "value59"
				},
				{
					label: "59",
					value: "value60"
				},
				{
					label: "60",
					value: "value61"
				},
				{
					label: "61",
					value: "value62"
				},
				{
					label: "62",
					value: "value63"
				},
				{
					label: "63",
					value: "value64"
				},
				{
					label: "64",
					value: "value65"
				},
				{
					label: "65",
					value: "value66"
				},
				{
					label: "66",
					value: "value67"
				},
				{
					label: "67",
					value: "value68"
				},
				{
					label: "68",
					value: "value69"
				},
				{
					label: "69",
					value: "value70"
				},
				{
					label: "70",
					value: "value71"
				},
				{
					label: "71",
					value: "value72"
				},
				{
					label: "72",
					value: "value73"
				},
				{
					label: "73",
					value: "value74"
				},
				{
					label: "74",
					value: "value75"
				},
				{
					label: "75",
					value: "value76"
				},
				{
					label: "76",
					value: "value77"
				},
				{
					label: "77",
					value: "value78"
				},
				{
					label: "78",
					value: "value79"
				},
				{
					label: "79",
					value: "value80"
				},
				{
					label: "80",
					value: "value81"
				},
				{
					label: "81",
					value: "value82"
				},
				{
					label: "82",
					value: "value83"
				},
				{
					label: "83",
					value: "value84"
				},
				{
					label: "84",
					value: "value85"
				},
				{
					label: "85",
					value: "value86"
				},
				{
					label: "86",
					value: "value87"
				},
				{
					label: "87",
					value: "value88"
				},
				{
					label: "88",
					value: "value89"
				},
				{
					label: "89",
					value: "value90"
				},
				{
					label: "90",
					value: "value91"
				},
				{
					label: "91",
					value: "value92"
				},
				{
					label: "92",
					value: "value93"
				},
				{
					label: "93",
					value: "value94"
				},
				{
					label: "94",
					value: "value95"
				},
				{
					label: "95",
					value: "value96"
				},
				{
					label: "96",
					value: "value97"
				},
				{
					label: "97",
					value: "value98"
				},
				{
					label: "98",
					value: "value99"
				},
				{
					label: "99",
					value: "value100"
				},
				{
					label: "100",
					value: "value101"
				},
			];
		},
		onLoad(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			var item = JSON.parse(options.data); // 字符串转对象
			this.item = item;
			this.type = item;
			console.log(this.type)
			
		},
		methods: {
			selectitem1(index, item) {
				console.log(item)
				if (index >= 0) {
					this.tval1 = item.value;
					this.score = item.label;
					console.log(this.score)
				} else {
					this.tval1 = ""
					this.score = item.label;
					console.log(this.score)
				}
			},
			openScanner() {
				uni.scanCode({
					success: res => {
						this.qrResult = res.result;
						let resultList = this.qrResult.split(',');
						for (let i = 0; i < resultList.length; i++) {
							this.resultData['rest' + (i + 1)] = resultList[i];
						}
					},
					fail: () => {
						console.log('扫码失败');
					}
				});
			},
			sure() {
				if (this.score != "") {
					var that = this;
					let datas = {
						score: this.score,
						userid: this.resultData.rest1,
						username: this.resultData.rest2,
						className: this.resultData.rest4,
						phonenum: this.resultData.rest3,
						examiner: this.user.userid,
						examinerAdmission: this.type,
					}
					console.log(datas);
					that.request("enroll/update", datas, 'POST').then(res => {
						console.log(res.code)
						if (res.code == 200) {
							uni.showToast({
								title: '评分成功',
								icon: 'success',
								duration: 1000,						
							});
							this.resultData = ""
						}
					})
					
				} else {
					console.log("请填写分数")
					uni.showToast({
						title: '请填写分数！',
						icon: 'error',
						duration: 2000
					});
				}
			}
		},
	}
</script>
<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.containera {
			margin: 0 auto;
			width: 750rpx;
		}

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					// padding: 0 30rpx;
					min-height: 100rpx;
					// /* background-color: #ffffff; */
					// /* justify-content: space-between; */
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}

		.form {
			width: 100%;
			padding: 40rpx 30rpx;
			box-sizing: border-box;

			.item {
				width: 100%;
				padding: 20rpx 0;

				.select {
					width: 100%;
					border: 1px solid #dadbde;
					padding-top: 6px;
					padding-bottom: 6px;
					padding-left: 9px;
					padding-right: 9px;
					border-radius: 4px;
					font-size: 15px;
					box-sizing: border-box;
					color: #CCCCCC;
					line-height: 26px;

					&.selected {
						color: black;
					}
				}
			}
		}

	}
</style>