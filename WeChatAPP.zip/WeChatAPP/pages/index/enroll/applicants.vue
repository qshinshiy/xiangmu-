<!-- 
@author : Yingming
@date : 2023
@description : 实验室工作室社团申请
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<!-- 基本信息 -->
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">网工组织申请者信息</text>
							<text class="text-ABC text-blue">JOINSCSTEAM</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.token != null">
						<view class="content">
							<text class="cuIcon-my text-blue"></text>
							<text class="text-lg">申请者姓名</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.username}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.token != null">
						<view class='content'>
							<text class="cuIcon-favor text-blue"></text>
							<text class='text-lg'>申请者学号</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.userid}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.token != null">
						<view class='content'>
							<text class="cuIcon-read text-blue"></text>
							<text class='text-lg'>申请者班级</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.className}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.token != null">
						<view class='content'>
							<text class="cuIcon-message text-blue"></text>
							<text class='text-lg'>申请者联系方式</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.phonenumber}}
							</view>
						</view>
					</view>
					
					<view class="content">
						<form @submit="formSubmit">
							<view style="height:20rpx"></view>
							<view class="item">意向第1志愿：</view>
							<select-lay :zindex="1411" :value="tval1" name="name" placeholder="请选择意向组织"
								:options="datalist1" @selectitem="selectitem1">
							</select-lay>
							<view style="height:20rpx"></view>
							<view class="item">意向第2志愿：</view>
							<select-lay :zindex="1311" :value="tval2" name="name" placeholder="请选择意向组织"
								:options="datalist2" @selectitem="selectitem2">
							</select-lay>
							<view style="height:20rpx"></view>
							<view class="item">意向第3志愿：</view>
							<select-lay :zindex="1211" :value="tval3" name="name" placeholder="请选择意向组织"
								:options="datalist3" @selectitem="selectitem3">
							</select-lay>
							<view style="height:20rpx"></view>
							<view class="item">数学成绩：</view>
							<select-lay :zindex="1111" :value="tval5" name="name" placeholder="数学成绩(不影响最终结果)"
								:options="datalist5" @selectitem="selectitem5">
							</select-lay>
							<view style="height:20rpx"></view>
							<view class="item">调剂意向：</view>
							<select-lay :zindex="1101" :value="tval4" name="name" placeholder="是否服从调剂"
								:options="datalist4" @selectitem="selectitem4">
							</select-lay>
							<view style="height:20rpx"></view>
							<view class="item">网工新媒体部门(不于以上组织冲突)：</view>
							<select-lay :zindex="1100" :value="tval6" name="name" placeholder="是否报名网工新媒体部门"
								:options="datalist6" @selectitem="selectitem6">
							</select-lay>
							<view style="height:20rpx"></view>
						</form>
					</view>
					
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-info text-green"></text>
							<text class='text-ls'>网工新媒体部门为单独招生方向，不于科技组织相互冲突，您在选择了报名网工新媒体的情况下，有可能会收到多个面试邀请，请注意！</text>
						</view>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-info text-red"></text>
							<text class='text-ls'>申请者提交志愿后，系统将会自动审批，面试及录取请关注公众号和小程序。步骤为：提交申请->系统审核->等待面试->录取结果(不同组织的面试地点和时间、录取时间均不一致，请耐心等待)</text>
						</view>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
					<view class="margin-top-sm" style="padding: 0;">
						<button class="bg-blue" @click="checkapply">确认报名志愿信息</button>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<view style="height: 50rpx;width: 1rpx;"></view>
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				datalist1: [],
				tval1: "",
				clubtype1: "",
				datalist2: [],
				tval2: "",
				clubtype2: "",
				datalist3: [],
				tval3: "",
				clubtype3: "",
				datalist4: [],
				tval4: "",
				transfers: "",
				datalist5: [],
				tval5: "",
				mathscore: "",
				datalist6: [],
				tval6: "",
				new_media: "",
				user: {},
				token: {},
			}
		},
		onLoad(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},
		onShow(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},



		onReady() {
			this.datalist1 = [{
					label: "网络工程实验室",
					value: "value1"
				},
				{
					label: "云萌工作室",
					value: "value2"
				},
				{
					label: "iCAN创新社",
					value: "value3"
				}
			];
			this.datalist2 = [{
					label: "网络工程实验室",
					value: "2value1"
				},
				{
					label: "云萌工作室",
					value: "2value2"
				},
				{
					label: "iCAN创新社",
					value: "2value3"
				}
			];
			this.datalist3 = [{
					label: "网络工程实验室",
					value: "3value1"
				},
				{
					label: "云萌工作室",
					value: "3value2"
				},
				{
					label: "iCAN创新社",
					value: "3value3"
				}
			];
			this.datalist4 = [{
					label: "是",
					value: "4value1"
				},
				{
					label: "否",
					value: "4value2"
				}
			];
			this.datalist5 = [{
					label: "150-120(包含120)",
					value: "5value1"
				},
				{
					label: "120-90(包含90)",
					value: "5value2"
				},
				{
					label: "90以下",
					value: "5value3"
				}
			];
			this.datalist6 = [{
					label: "是",
					value: "6value1"
				},
				{
					label: "否",
					value: "6value2"
				}
			];
		},



		methods: {
			checkapply() {
				if(this.clubtype1 && this.clubtype2  && this.clubtype3  && this.transfers  && this.mathscore  && this.new_media != ""){
					var that = this;
					let datas = {
						userid: this.user.userid,
						username: this.user.username,
						className: this.user.className,
						phonenum: this.user.phonenumber,
						clubtype1: this.clubtype1,
						clubtype2: this.clubtype2,
						clubtype3: this.clubtype3,
						transfers: this.transfers,
						mathscore: this.mathscore,
						newMedia: this.new_media,
					}
					console.log(datas)
					that.request("enroll/join", datas, 'POST').then(res => {
						console.log(res.code)
						if (res.code == 200) {
							uni.showToast({
								title: '报名成功',
								icon: 'success',
								duration: 1000,
							});
							setTimeout(function() {
								uni.switchTab({
									url: '/pages/index/index',
								});
							}, 1000);
						} else {
							uni.showToast({
								title: '出错啦，请重试',
								icon: 'error',
								duration: 1000,
							});
						}
					});
				}
				else{
				console.log("学生报名信息不完整")
				uni.showToast({
					title: '请填写完整！',
					icon: 'error',
					duration: 2000
				});
				}
			},
			selectitem1(index, item) {
				console.log(item)
				if (index >= 0) {
					this.tval1 = item.value;
					this.clubtype1 = item.label;
					console.log(this.clubtype1)
				} else {
					this.tval1 = ""
					this.clubtype1 = item.label;
					console.log(this.clubtype1)
				}
			},
			selectitem2(index, item) {
				console.log(item)
				if (index >= 0) {
					this.tval2 = item.value;
					this.clubtype2 = item.label;
					console.log(this.clubtype2)
				} else {
					this.tval2 = ""
					this.clubtype2 = item.label;
					console.log(this.clubtype2)
				}
			},
			selectitem3(index, item) {
				console.log(item)
				if (index >= 0) {
					this.tval3 = item.value;
					this.clubtype3 = item.label;
					console.log(this.clubtype3)
				} else {
					this.tval3 = ""
					this.clubtype3 = item.label;
					console.log(this.clubtype3)
				}
			},
			selectitem4(index, item) {
				console.log(item)
				if (index >= 0) {
					this.tval4 = item.value;
					this.transfers = item.label;
					console.log(this.transfers)
				} else {
					this.tval4 = ""
					this.transfers = item.label;
					console.log(this.transfers)
				}
			},
			selectitem5(index, item) {
				console.log(item)
				if (index >= 0) {
					this.tval5 = item.value;
					this.mathscore = item.label;
					console.log(this.mathscore)
				} else {
					this.tval5 = ""
					this.mathscore = item.label;
					console.log(this.mathscore)
				}
			},
			selectitem6(index, item) {
				console.log(item)
				if (index >= 0) {
					this.tval6 = item.value;
					this.new_media = item.label;
					console.log(this.new_media)
				} else {
					this.tval6 = ""
					this.new_media = item.label;
					console.log(this.new_media)
				}
			}
		},
	}
</script>
<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.containera {
			margin: 0 auto;
			width: 750rpx;
		}

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					min-height: 100rpx;
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}

		.form {
			width: 100%;
			padding: 40rpx 30rpx;
			box-sizing: border-box;

			.item {
				width: 100%;
				padding: 20rpx 0;

				.select {
					width: 100%;
					border: 1px solid #dadbde;
					padding-top: 6px;
					padding-bottom: 6px;
					padding-left: 9px;
					padding-right: 9px;
					border-radius: 4px;
					font-size: 15px;
					box-sizing: border-box;
					color: #CCCCCC;
					line-height: 26px;

					&.selected {
						color: black;
					}
				}
			}
		}

	}
</style>