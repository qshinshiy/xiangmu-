<!-- 
@author : Yingming
@date : 2023
@description : 首页
-->
<template>
    <view class="components-home">
        <!-- 云萌弹窗说明 -->
        <view
            class="cu-modal"
            @tap="hideModal"
            :class="modalName == 'Modal' ? 'show' : ''"
            style="z-index: 99999"
        >
            <view class="cu-dialog" style="padding: 300rpx 0 70rpx">
                <view class="modal_bg">
                    <view class="title-header">
                        <view class="title-text"> 云 · 萌 · 工 · 作 · 室 </view>
                    </view>
                </view>
                <view class="modal_main">
                    <view class="padding-lr margin-top-xs">
                        <view class="text-grey text-smdf">
                            <text
                                class="cuIcon-title text-blue margin-right-xs"
                            ></text>
                            <text class="text-orange">云萌工作室heiheihehei</text
                            ><text
                                >是成都东软学院计算机与软件学院<text
                                    class="text-orange"
                                    >网络工程系</text
                                >的科技工作室，工作室主要负责<text
                                    class="text-orange"
                                    >网络工程系</text
                                >系列系统开发、开展各种活动的技术性保障以及平台运维保障等相关工作</text
                            >
                        </view>
                        <view class="text-grey text-smdf margin-top-sm">
                            <text
                                class="cuIcon-title text-blue margin-right-xs"
                            ></text>
                            <text
                                >我们所追随的光，是<text class="text-orange"
                                    >五星红旗</text
                                >的五角星所闪烁的光！笃定信仰，不负众望</text
                            >
                        </view>
                        <view class="text-grey text-smdf margin-top-sm">
                            <text
                                class="cuIcon-title text-blue margin-right-xs"
                            ></text>
                            <text
                                >欢迎加入<text class="text-orange"
                                    >网络工程系云萌工作室</text
                                >和<text class="text-orange"
                                    >网络工程实验室</text
                                >，我们在这里等你！‍</text
                            >
                        </view>
                        <view class="text-grey text-smdf margin-top-sm">
                            <text
                                class="cuIcon-title text-blue margin-right-xs"
                            ></text>
                            <text
                                >本系统由<text class="text-orange"
                                    >云萌工作室2019级李尊信、张瑛铭，2020级陈浩然，2022级刘果峰、郑康乐、唐睿阳、熊杰、阿卜杜萨拉木、方文丹</text
                                >开发，版权所有，禁止破解系统相关内容，违者必究其法律责任。本系统感谢RuoYi以及前端铺子的支持！</text
                            >
                        </view>
                    </view>
                </view>
            </view>
        </view>
        <view class="bgImg">
            <view class="bannerBox">
                <swiper
                    style="height: 680rpx"
                    class="swiper"
                    @change="cardSwiper"
                    circular="true"
                    indicator-dots="true"
                    autoplay="true"
                    interval="4000"
                    duration="600"
                >
                    <swiper-item
                        class="swiper-list"
                        v-for="(item, index) in bannerList"
                        :key="index"
                    >
                        <view class="swiper-item uni-bg-red">
                            <image
                                class="swiper-img radius shadow-warp"
                                :src="item.imageUrl"
                                mode="widthFix"
                            ></image>
                        </view>
                    </swiper-item>
                </swiper>
                <view class="indication">
                    <block v-for="(item, index) in bannerList" :key="index">
                        <view
                            class="spot"
                            :class="cardCur == index ? 'active' : ''"
                        ></view>
                    </block>
                </view>
            </view>
            <view
                @click="showModal"
                class="left_box shadow-warp"
                style="padding: 20rpx 20rpx 20rpx 10rpx"
            >
                <view
                    class="cu-avatar lgs round margin-right-sm margin-left-xs fl"
                    style="
                        background-image: url(https://base.cloudcode.team/wechat/image/BLogo.png);
                    "
                ></view>
                <view class="text-bold fl margin-top-xs text-shadow"
                    >云萌工作室</view
                >
                <viwe class="text-grey text-sm margin-top-xs fl text-shadow"
                    >若了解详情，请点击↑</viwe
                >
            </view>
            <view class="right_box shadow-warp" @click="goALL">
                <button class="content cu-btn" style="display: contents">
                    <view
                        class="text-xxl"
                        style="height: 64rpx; margin-top: 12rpx"
                    >
                        <image
                            src="https://base.cloudcode.team/wechat/icon/allapp.png"
                            mode="widthFix"
                            style="width: 65rpx"
                        >
                        </image>
                    </view>
                    <view
                        class="text-shadow text-black text-bold"
                        style="font-size: 26rpx; margin-top: 14rpx"
                        >全部功能
                    </view>
                </button>
            </view>
        </view>
        <view class="mainBox flex justify-between">
            <view
                @click="goACT"
                class="mainBtn shadow-warp radius bg-white padding-sm margin-xs radius text-center"
            >
                <view style="text-align: center">
                    <image
                        src="https://base.cloudcode.team/wechat/icon/activity.png"
                        mode="widthFix"
                        style="width: 125rpx; border-radius: 20rpx"
                    ></image>
                </view>
                <view
                    class="text-bold text-black text-lg margin-top-sm text-shadow"
                    >网工活动报名</view
                >
                <view class="margin-top-sm text-gray text-sm text-shadow"
                    ><text class="text-orange margin-right-xs text-bold"
                        >愿你走出半生</text
                    ></view
                >
            </view>
            <view
                @click="goVolunteer"
                class="mainBtn shadow-warp radius bg-white padding-sm margin-xs radius text-center"
            >
                <view style="text-align: center">
                    <image
                        src="https://base.cloudcode.team/wechat/icon/volact.png"
                        mode="widthFix"
                        style="width: 125rpx"
                    >
                    </image>
                </view>
                <view
                    class="text-bold text-black text-lg margin-top-sm text-shadow"
                    >志愿活动报名</view
                >
                <view class="margin-top-sm text-gray text-sm text-shadow"
                    ><text class="text-orange margin-right-xs text-bold"
                        >归来仍是少年</text
                    ></view
                >
            </view>
        </view>
        <view class="padding">
            <view class="flex">
                <view
                    @click="goParty"
                    class="flex-sub bg-white padding-sm margin-sm radius shadow-warp"
                    style="line-height: 80rpx"
                >
                    <image
                        class="fl margin-right-sm"
                        src="https://base.cloudcode.team/wechat/icon/party.png"
                        mode="widthFix"
                        style="width: 55rpx; margin-top: 15rpx"
                    ></image>
                    <view class="text-shadow text-bold">政治面貌</view>
                </view>
                <view
                    @click="goOJ"
                    class="flex-sub bg-white padding-sm margin-sm radius shadow-warp"
                    style="line-height: 80rpx"
                >
                    <image
                        class="fl margin-right-sm"
                        src="https://base.cloudcode.team/wechat/icon/ojlist.png"
                        mode="widthFix"
                        style="width: 68rpx; margin-top: 8rpx"
                    ></image>
                    <view class="text-shadow text-bold">我的WCT数据</view>
                </view>
                <!-- <view @click="goBasicSCS" class="flex-sub bg-white padding-sm margin-sm radius shadow-warp"
					style="line-height: 80rpx;">
					<image class="fl margin-right-sm" src="https://base.cloudcode.team/wechat/icon/ojlist.png"
						mode="widthFix" style="width: 68rpx;margin-top: 8rpx;"></image>
					<view class="text-shadow text-bold">网工组织报名</view>
				</view> -->
            </view>
        </view>
    </view>
</template>

<script>
import request from "@/utils/request.js";
import {
    getConfig,
    setUserInfo,
    getUserInfo,
    setToken,
    getToken,
    getuserID,
    removeuserID,
    removeUserInfo,
    removeToken,
} from "@/utils/auth";
export default {
    data() {
        return {
            user: {},
            token: {},
            getuserID: {},
            cardCur: 0,
            bannerList: [
                {
                    imageUrl:
                        "https://base.cloudcode.team/wechat/image/2023-7-1-com.png",
                },
                {
                    imageUrl:
                        "https://base.cloudcode.team/wechat/image/2023-5-com.jpg",
                },
            ],
            modalName: null, //云萌弹窗
        };
    },
    onLoad: function (data) {
        this.user = getUserInfo() || {};
        this.token = getToken() || {};
        this.getuserID = getuserID() || {};
        this.Safe();
    },
    onShow: function (data) {
        this.user = getUserInfo() || {};
        this.token = getToken() || {};
        this.getuserID = getuserID() || {};
        this.Safe();
        this.makephone();
        console.log(this.user);
    },
    methods: {
        makephone: function () {
            if (
                this.user.userid == this.user.phonenumber &&
                this.user.userid != null
            ) {
                uni.navigateTo({
                    url: "/pages/me/band/rephone",
                });
            }
        },
        Safe: function () {
            var that = this;
            let datas = {
                userid: this.user.userid,
            };
            if (this.user.userid != null) {
                that.request("test", datas, "GET").then((res) => {
                    if (res.code == 401) {
                        removeUserInfo();
                        removeToken();
                        removeuserID();
                        uni.showToast({
                            title: "Token已过期，请重新登录",
                            icon: "none",
                            duration: 3000,
                        });
                    } else {
                        console.log("小程序身份验证通过~");
                    }
                });
            } else {
                console.log("还未登录");
            }
        },
        showModal() {
            this.modalName = "Modal";
        },
        hideModal() {
            this.modalName = null;
        },
        cardSwiper(e) {
            this.cardCur = e.detail.current;
        },
        goGoodBye() {
            if (this.user.token == null) {
                uni.showToast({
                    title: "请登录后使用，正在前往登录页面",
                    icon: "none",
                    duration: 2000,
                });
                setTimeout(function () {
                    uni.switchTab({
                        url: "/pages/me/me",
                    });
                }, 1000);
            } else {
                uni.navigateTo({
                    url: "/pages/index/goodbey",
                });
            }
        },
        goParty() {
            if (this.user.isParty == 1) {
                uni.navigateTo({
                    url: "/pages/index/party/party",
                });
            } else {
                uni.navigateTo({
                    url: "/pages/index/party/liucheng",
                });
            }
        },
        goVolunteer() {
            if (this.user.token == null) {
                uni.showToast({
                    title: "请登录后使用，正在前往登录页面",
                    icon: "none",
                    duration: 2000,
                });
                setTimeout(function () {
                    uni.switchTab({
                        url: "/pages/me/me",
                    });
                }, 1000);
            } else {
                var that = this;
                let datas = {
                    userid: this.user.userid,
                };
                console.log(datas);
                that.request("vol/activityList", datas, "GET").then((res) => {
                    if (res.data.isVol == 0) {
                        uni.navigateTo({
                            url: "/pages/index/volunteer/volunteerapply",
                        });
                    }
                    if (res.data.isVol == 1) {
                        uni.navigateTo({
                            url: "/pages/index/volunteer/volunteerlist",
                        });
                    }
                });
            }
        },
        goACT() {
            if (this.user.token == null) {
                uni.showToast({
                    title: "请登录后使用，正在前往登录页面",
                    icon: "none",
                    duration: 2000,
                });
                setTimeout(function () {
                    uni.switchTab({
                        url: "/pages/me/me",
                    });
                }, 1000);
            } else {
                uni.navigateTo({
                    url: "/pages/index/activitie/activitielist",
                });
            }
        },
        goALL() {
            if (this.user.token == null) {
                uni.showToast({
                    title: "请登录后使用，正在前往登录页面",
                    icon: "none",
                    duration: 2000,
                });
                setTimeout(function () {
                    uni.switchTab({
                        url: "/pages/me/me",
                    });
                }, 1000);
            } else {
                uni.navigateTo({
                    url: "/pages/index/allindex",
                });
            }
        },
        goOJ() {
            if (this.user.token == null) {
                uni.showToast({
                    title: "请登录后使用，正在前往登录页面",
                    icon: "none",
                    duration: 2000,
                });
                setTimeout(function () {
                    uni.switchTab({
                        url: "/pages/me/me",
                    });
                }, 1000);
            } else {
                uni.navigateTo({
                    url: "/pages/index/OJ",
                });
            }
        },
        goBasicSCS() {
            if (this.user.token == null) {
                uni.showToast({
                    title: "请登录后使用，正在前往登录页面",
                    icon: "none",
                    duration: 2000,
                });
                setTimeout(function () {
                    uni.switchTab({
                        url: "/pages/me/me",
                    });
                }, 1000);
            } else {
                var that = this;
                let datas = {
                    userid: this.user.userid,
                };
                console.log(datas);
                that.request("enroll/" + this.user.userid, "GET").then(
                    (res) => {
                        console.log(res.data);
                        if (res.data == null) {
                            uni.navigateTo({
                                url: "/pages/index/enroll/applicants",
                            });
                        } else {
                            uni.navigateTo({
                                url: "/pages/index/enroll/applicationinfo",
                            });
                        }
                    }
                );
            }
        },
    },
};
</script>

<style lang="scss" scoped>
.swiper-item {
    height: 100%;
}

/* 轮播指示点 start*/
.indication {
    z-index: 9999;
    width: 100%;
    height: 36rpx;
    position: absolute;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
}

.spot {
    background-color: #ffffff;
    opacity: 0.6;
    width: 10rpx;
    height: 10rpx;
    border-radius: 20rpx;
    top: -130rpx;
    margin: 0 8rpx !important;
    position: relative;
}

.spot.active {
    opacity: 1;
    width: 30rpx;
    background-color: #0081ff;
}

.bgImg {
    position: relative;
    margin-bottom: 100rpx;

    .left_box {
        position: absolute;
        height: 130rpx;
        width: 60%;
        background: #ffffff;
        bottom: -55rpx;
        left: 5%;
        border-radius: 15rpx;
    }

    .right_box {
        text-align: center;
        position: absolute;
        height: 130rpx;
        width: 25%;
        background: #ffffff;
        bottom: -55rpx;
        right: 5%;
        border-radius: 15rpx;
    }
}

.mainBox {
    width: 750rpx;
    height: 300rpx;
    padding: 0 5%;
    margin-bottom: 10rpx;

    .mainBtn {
        width: 45%;
    }
}

.radius {
    border-radius: 18rpx !important;
}

// 弹窗
.cu-dialog {
    background: #ffffff;
    overflow: visible;
}

.modal_bg {
    width: 100%;
    height: 400rpx;
    position: absolute;
    top: -100rpx;
    background-image: url(https://base.cloudcode.team/wechat/image/modal_bg.png);
    background-size: 100%;
    background-repeat: no-repeat;
}

.modal_main {
    text-align: left;
    background-color: #ffffff;
}

.title-header {
    position: absolute;
    bottom: 0;
    width: 100%;
    display: flex;
    height: 120rpx;
    font-size: 40rpx;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    background-image: url(https://base.cloudcode.team/wechat/image/wccswF.png);
    background-size: cover;
}

.title-text {
    background-image: -webkit-linear-gradient(0deg, #ff8a34, #fbbd12);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
</style>
