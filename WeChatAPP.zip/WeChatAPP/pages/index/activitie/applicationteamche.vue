<!-- 
@author : Yingming
@date : 2023
@description : 团队赛报名方式选择
-->
<template>
	<view class="components-home" style="height:100vh;background: #f0f0f0;">
		<view class="img-a">
			<view class="t-b">
				欢迎报名 {{item.activityName}}
			</view>
		</view>
		<view class="login-view">
			<view class="flex" @click="jointeam(item)">
				<view class="flex-sub bg-white padding-sm margin-sm radius shadow-warp" style="line-height: 150rpx;">
					<image class="fl margin-right-sm" src="https://base.cloudcode.team/wechat/smallpng/join.png"
						mode="widthFix" style="width: 145rpx;margin-top: 5rpx;"></image>
					<view class="text-shadow text-bold">加入团队</view>
				</view>
			</view>
			<view class="flex" @click="creatteam(item)">
				<view class="flex-sub bg-white padding-sm margin-sm radius shadow-warp" style="line-height: 150rpx;">
					<image class="fl margin-right-sm" src="https://base.cloudcode.team/wechat/smallpng/creat.png"
						mode="widthFix" style="width: 145rpx;margin-top: 5rpx;"></image>
					<view class="text-shadow text-bold">创建团队</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import {
		getUserInfo,
		getToken
	} from '@/utils/auth';
	export default {
		data() {
			return {
				user: {},
				token: {},
				item: {}
			}
		},
		onLoad(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			var item = JSON.parse(options.data); // 字符串转对象
			this.item = item;
		},
		onShow(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},
		methods: {
			jointeam(item) {
				var items = JSON.stringify(item);
				uni.redirectTo({
					url: '/pages/index/activitie/applicationteamjoin?data=' + items,
				});
			},
			creatteam(item) {
				var items = JSON.stringify(item);
				uni.redirectTo({
					url: '/pages/index/activitie/applicationteamcre?data=' + items,
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.swiper-item {
		height: 100%;
	}

	.img-a {
		width: 100%;
		height: 450rpx;
		background-image: url(https://base.cloudcode.team/newbg/CloudCode1-2.png);
		background-size: 100%;
	}

	.t-b {
		text-align: left;
		font-size: 45rpx;
		color: #ffffff;
		padding: 130rpx 0 0 70rpx;
		font-weight: bold;
		line-height: 64rpx;
	}

	.login-view {
		width: 100%;
		position: relative;
		margin-top: -120rpx;
		background-color: #f0f0f0;
		border-radius: 8% 8% 0% 0;
	}

	.mainBox {
		width: 750rpx;
		height: 300rpx;
		padding: 0 5%;
		margin-bottom: 10rpx;

		.mainBtn {
			width: 45%;
		}
	}

	.radius {
		border-radius: 50rpx !important;
	}
</style>
