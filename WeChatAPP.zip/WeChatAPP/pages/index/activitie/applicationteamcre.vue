<!-- 
@author : Yingming
@date : 2023
@description : 团赛赛创建团队 
-->
<template>
	<view style="height:100vh;background: #fff;">
		<view class="img-a">
			<view class="t-b">
				创建团队
				<br />
				创建后无法自行更改或者删除
				<br />
				如需修改请联系工作人员
			</view>
		</view>
		<view class="login-view" style="">
			<view class="t-login">
				<form class="cl">
					<view class="t-a" v-if="item.activityName != null && item.activityName != ''">
						<text class="txt">活动名称：{{item.activityName}}</text>
					</view>
					<view style="height: 10rpx;width: 1rpx;"></view>
					<view class="t-a" v-if="item.activityTypeName != null && item.activityTypeName != ''">
						<text class="txt">活动类型：{{item.activityTypeName}}</text>
					</view>
					<view style="height: 10rpx;width: 1rpx;"></view>
					<view class="t-a" v-if="user.username != null && user.username != ''">
						<text class="txt">队长姓名：{{user.username}}</text>
					</view>
					<view style="height: 10rpx;width: 1rpx;"></view>
					<view class="t-a" v-if="user.userid != null && user.userid != ''">
						<text class="txt">队长学号：{{user.userid}}</text>
					</view>
					<view style="height: 10rpx;width: 1rpx;"></view>
					<view class="t-a" v-if="user.phonenumber != null && user.phonenumber != ''">
						<text class="txt">队长手机号：{{user.phonenumber}}</text>
					</view>
					<view style="height: 10rpx;width: 1rpx;"></view>
					<view class="t-a" v-if="user.className != null && user.className != ''">
						<text class="txt">队长班级：{{user.className}}</text>
					</view>
					<view style="height: 10rpx;width: 1rpx;"></view>
					<view class="t-a">
						<view class="txt">团队名称：{{inputValue}}</view>
					</view>
					<view style="height: 10rpx;width: 1rpx;"></view>
					<view class="t-a">
						<input class="uni-input" type="text" v-model="inputValue" placeholder="请输入团队名称" />
					</view>
					<button @tap="creat">创建团队</button>
				</form>
				<view class="t-f"><text>—————— 网工云萌工作室 ——————</text></view>
			</view>
		</view>
	</view>
</template>
<script>
	import {
		getUserInfo,
		getToken
	} from '@/utils/auth';
	export default {
		data() {
			return {
				user: {},
				token: {},
				item: {},
				inputValue: '',
			};
		},
		onLoad(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			var item = JSON.parse(options.data); // 字符串转对象
			this.item = item;
		},
		methods: {
			onKeyInput: function(event) {
				this.inputValue = event.target.value
			},
			creat() {
				var that = this;
				var activitid = Number(this.item.activityId)
				let datas = {
					userid: this.user.userid,
					userId: this.user.userid,
					username: this.user.username,
					className: this.user.className,
					phonenum: this.user.phonenumber,
					teamName: this.inputValue,
					activityName: this.item.activityName, //long形
					activityId: activitid, //long形
				}
				if (this.inputValue.trim() === '') {
					uni.showToast({
						title: '请输入团队名称',
						icon: 'error',
						duration: 1000,
					});
				} else {
					that.request("team", datas, 'POST').then(res => {
						if (res.code == 200) {
							uni.showToast({
								title: '报名成功',
								icon: 'success',
								duration: 1000,
							});
							setTimeout(function() {
								uni.redirectTo({
									url: '/pages/index/activitie/activitielist',
								});
							}, 1000);
						} else {
							uni.showToast({
								title: '出错啦，请重试',
								icon: 'error',
								duration: 1000,
							});
							setTimeout(function() {
								uni.redirectTo({
									url: '/pages/index/activitie/activitielist',
								});
							}, 1000);
						}
					});
				}
			}
		}
	};
</script>
<style>
	.txt {
		font-size: 32rpx;
		font-weight: bold;
		color: #333333;
	}

	.img-a {
		width: 100%;
		height: 450rpx;
		background-image: url(https://base.cloudcode.team/newbg/CloudCode1-2.png);
		background-size: 100%;
	}

	.reg {
		font-size: 28rpx;
		color: #fff;
		height: 90rpx;
		line-height: 90rpx;
		border-radius: 50rpx;
		font-weight: bold;
		background: #f5f6fa;
		color: #000000;
		text-align: center;
		margin-top: 30rpx;
	}

	.login-view {
		width: 100%;
		position: relative;
		margin-top: -120rpx;
		background-color: #ffffff;
		border-radius: 8% 8% 0% 0;
	}

	.t-login {
		width: 600rpx;
		margin: 0 auto;
		font-size: 28rpx;
		padding-top: 80rpx;
	}

	.t-login button {
		font-size: 28rpx;
		background: #2796f2;
		color: #fff;
		height: 90rpx;
		line-height: 90rpx;
		border-radius: 50rpx;
		font-weight: bold;
	}

	.t-login input {
		height: 90rpx;
		line-height: 90rpx;
		margin-bottom: 50rpx;
		border-bottom: 1px solid #e9e9e9;
		font-size: 28rpx;
	}

	.t-login .t-a {
		position: relative;
	}

	.t-b {
		text-align: left;
		font-size: 45rpx;
		color: #ffffff;
		padding: 130rpx 0 0 70rpx;
		font-weight: bold;
		line-height: 64rpx;
	}

	.t-login .t-c {
		position: absolute;
		right: 22rpx;
		top: 22rpx;
		background: #5677fc;
		color: #fff;
		font-size: 24rpx;
		border-radius: 50rpx;
		height: 50rpx;
		line-height: 50rpx;
		padding: 0 25rpx;
	}

	.t-login .t-d {
		text-align: center;
		color: #999;
		margin: 80rpx 0;
	}

	.t-login .t-e {
		text-align: center;
		width: 250rpx;
		margin: 80rpx auto 0;
	}

	.t-login .t-g {
		float: left;
		width: 50%;
	}

	.t-login .t-e image {
		width: 50rpx;
		height: 50rpx;
	}

	.t-login .t-f {
		text-align: center;
		margin: 150rpx 0 0 0;
		color: #666;
	}

	.t-login .t-f text {
		margin-left: 20rpx;
		color: #aaaaaa;
		font-size: 27rpx;
	}

	.t-login .uni-input-placeholder {
		color: #aeaeae;
	}

	.cl {
		zoom: 1;
	}

	.cl:after {
		clear: both;
		display: block;
		visibility: hidden;
		height: 0;
		content: '\20';
	}
</style>
