<!-- 
@author : Yingming
@date : 2023
@description : 团队赛团队信息
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<!-- 基本信息 -->
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">团队信息</text>
							<text class="text-ABC text-blue">TEAMINFO</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-newshot text-blue"></text>
							<text class='text-lg'>活动名称</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{item.activityName}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-ticket text-blue"></text>
							<text class='text-lg'>活动类型</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{item.activityTypeName}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class="content">
							<text class="cuIcon-my text-blue"></text>
							<text class="text-lg">团队名称</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{teamName}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="items.type == 0" v-for="(items,index) in teamlist"
						:key="index" @>
						<view class='content'>
							<text class="cuIcon-favor text-blue"></text>
							<text class='text-lg'>队长姓名</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{items.userName}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="items.type == 2" v-for="(items,index) in teamlist"
						:key="index" @>
						<view class='content'>
							<text class="cuIcon-favor text-blue"></text>
							<text class='text-lg'>队员姓名</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{items.userName}}
							</view>
						</view>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">扫码邀请队员</text>
							<text class="text-ABC text-blue">Invitemem</text>
						</view>
					</view>
					<!-- 团队成员已满 -->
					<view class="cu-item" style="padding: 0" v-if="num == item.activityParNum ">
						<view class='content'>
							<text class="cuIcon-info text-red"></text>
							<text class='text-lg'>注意</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-red light">
								团队成员已满，当前不可邀请
							</view>
						</view>
					</view>
					<!-- 签到二维码 -->
					<view class="cu-item" style="padding: 0; height:270px" v-if="num != item.activityParNum ">
						<view class="containera" style="padding: 0; width: 250px; height: 250px;">
							<canvas id="qrcode" canvas-id="qrcode" style="width: 250px; height: 250px;"></canvas>
						</view>
					</view>

				</view>
			</view>
			<view style="height: 50rpx;width: 1rpx;"></view>
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import UQRCode from '@/node_modules/uqrcodejs/uqrcode.js';
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				user: {},
				token: '',
				item: {},
				items: {},
				teamName: '',
				teamlist: [],
				num: ''
			}
		},
		onLoad(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			var item = JSON.parse(options.data); // 字符串转对象
			this.item = item;
		},
		onShow(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			this.teaminfo();
		},
		methods: {
			teaminfo() {
				var that = this;
				var activitid = Number(this.item.activityId)
				let datas = {
					userid: this.user.userid,
					activityId: activitid,
				}
				that.request("teamInfo", datas, 'GET').then(res => {
					that.teamName = res.data.teamName
					that.teamlist = res.data.activityParticipators
					let list = that.teamlist.map((items) => {
						items.userid = items.userid + "";
						items.phonenum = items.phonenum + "";
						items.className = items.className + "";
						items.type = items.type + "";
						items.teamId = items.teamId + "";
						return items
					})
					var num = res.data.activityParticipators.length
					that.num = num + "";
					that.teamlist = list
					var newtoken = this.token.substring(0, 20);
					// 二维码生成参数
					this.text = this.item.activityId.concat(",").concat(this.item.activityName).concat(",").concat(
						res.data.teamId).concat(",").concat(res.data.teamName).concat(",").concat(newtoken);
					// 以下为二维码生成
					var qr = new UQRCode();
					// 设置二维码内容
					qr.data = this.text;
					// 设置二维码大小，必须与canvas设置的宽高一致
					qr.size = 250;
					// 调用制作二维码方法
					qr.make();
					// 获取canvas上下文
					var canvasContext = uni.createCanvasContext('qrcode', this); // 如果是组件，this必须传入
					// 设置uQRCode实例的canvas上下文
					qr.canvasContext = canvasContext;
					// 调用绘制方法将二维码图案绘制到canvas上
					qr.drawCanvas();
				});
			}
		}
	}
</script>
<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.containera {
			margin: 0 auto;
			width: 750rpx;
		}

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					min-height: 100rpx;
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}

	}
</style>
