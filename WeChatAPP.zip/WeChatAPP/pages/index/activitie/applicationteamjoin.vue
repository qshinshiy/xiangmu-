<!-- 
@author : Yingming
@date : 2023
@description : 团队赛加入团队
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<!-- 暂无邀请信息 -->
			<view class="center-box shadow" v-if="resultData.rest1 != item.activityId || resultData.rest1 == null">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">加入团队</text>
							<text class="text-ABC text-blue">JOINTEAM</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;"
						v-if="resultData.rest1 != item.activityId && resultData.rest1 !=null">
						<view class='content'>
							<text class='text-lg'>当前二维码非法，或不属于本活动二维码，请核对校验后再次扫描，若多次扫描无效，请联系活动管理员</text>
						</view>
					</view>
					<view class="margin-top-sm" style="padding: 0;">
						<button class="bg-blue" @click="openScanner">扫码加入团队</button>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<!-- 受邀信息 -->
			<view class="center-box shadow" v-if="resultData.rest1 == item.activityId && resultData.rest1 != null">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">受邀信息</text>
							<text class="text-ABC text-blue">InvitedInfo</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-info text-blue"></text>
							<text class='text-lg'>活动名称</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{resultData.rest2}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-info text-blue"></text>
							<text class='text-lg'>团队名称</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{resultData.rest4}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class="content">
							<text class="cuIcon-my text-blue"></text>
							<text class="text-lg">参赛姓名</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.username}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-favor text-blue"></text>
							<text class='text-lg'>参赛学号</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.userid}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-read text-blue"></text>
							<text class='text-lg'>联系方式</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.phonenumber}}
							</view>
						</view>
					</view>
					<view class="margin-top-sm" style="padding: 0;">
						<button class="bg-blue" @click="sure">确认加入</button>
					</view>
					<view style="height: 5rpx;width: 1rpx;"></view>
					<view class="margin-top-sm" style="padding: 0;">
						<button class="bg-red" @click="refuse">拒绝加入</button>
					</view>
					<view class="margin-top-sm" style="padding: 0;">
						<button class="bg-green" @click="openScanner">重新扫描</button>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<view style="height: 50rpx;width: 1rpx;"></view>
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				token: {},
				user: {},
				item: {},
				qrResult: '',
				type: '2',
				resultData: {},
			}
		},
		onLoad(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			var item = JSON.parse(options.data); // 字符串转对象
			this.item = item;
		},
		methods: {
			openScanner() {
				uni.scanCode({
					success: res => {
						this.qrResult = res.result;
						let resultList = this.qrResult.split(',');
						for (let i = 0; i < resultList.length; i++) {
							this.resultData['rest' + (i + 1)] = resultList[i];
						}
					},
					fail: () => {
						console.log('扫码失败');
					}
				});
			},
			sure() {
				var that = this;
				var teamactivitid = Number(this.resultData.rest1)
				var teamteamid = Number(this.resultData.rest3)
				var teamtype = Number(this.type)
				let datas = {
					userid: this.user.userid,
					className: this.user.className,
					activityTypeId: teamactivitid,
					teamId: teamteamid,
					type: teamtype,
					phonenum: this.user.phonenumber,
				}
				that.request("join", datas, 'POST').then(res => {
					var code = res.code + "";
					if (res.code == 200) {
						uni.showToast({
							title: '报名成功',
							icon: 'success',
							duration: 1000,
						});
						setTimeout(function() {
							uni.redirectTo({
								url: '/pages/index/activitie/activitielist',
							});
						}, 1000);
					}
					if (res.code == 806) {
						uni.showToast({
							title: '该团队已满员！',
							icon: 'error',
							duration: 2000,
						});
					}
					if (res.code == 807) {
						uni.showToast({
							title: '您已加入队伍',
							icon: 'error',
							duration: 2000,
						});
					}
					if (res.code == 808) {
						uni.showToast({
							title: '该团队不存在',
							icon: 'error',
							duration: 2000,
						});
					}
					if (res.code != 806 && res.code != 807 && res.code != 808 && res.code != 200) {
						uni.showToast({
							title: '出错啦，请重试',
							icon: 'error',
							duration: 2000,
						});
					}
				});
			},
			refuse() {
				this.resultData.rest1 = null;
				uni.redirectTo({
					url: '/pages/index/activitie/activitielist',
				});
			}
		},
	}
</script>
<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.containera {
			margin: 0 auto;
			width: 750rpx;
		}

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					// padding: 0 30rpx;
					min-height: 100rpx;
					// /* background-color: #ffffff; */
					// /* justify-content: space-between; */
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}

	}
</style>
