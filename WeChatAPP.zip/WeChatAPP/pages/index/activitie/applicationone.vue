<!-- 
@author : Yingming
@date : 2023
@description : 个人赛报名
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<!-- 基本信息 -->
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">报名信息</text>
							<text class="text-ABC text-blue">ApplyInfo</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.username != null && user.username != ''">
						<view class="content">
							<text class="cuIcon-my text-blue"></text>
							<text class="text-lg">姓名</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.username}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.userid != null && user.userid != ''">
						<view class='content'>
							<text class="cuIcon-favor text-blue"></text>
							<text class='text-lg'>学号</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.userid}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.className != null && user.className != ''">
						<view class='content'>
							<text class="cuIcon-read text-blue"></text>
							<text class='text-lg'>班级</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.className}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.phonenumber != null && user.phonenumber != ''">
						<view class='content'>
							<text class="cuIcon-message text-blue"></text>
							<text class='text-lg'>联系方式</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.phonenumber}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;"
						v-if="item.activityName != null && item.activityName != ''">
						<view class='content'>
							<text class="cuIcon-newshot text-blue"></text>
							<text class='text-lg'>活动名称</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{item.activityName}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;"
						v-if="item.activityTypeName != null && item.activityTypeName != ''">
						<view class='content'>
							<text class="cuIcon-ticket text-blue"></text>
							<text class='text-lg'>活动类型</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{item.activityTypeName}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;">
						<view class='content'>
							<text class="cuIcon-form text-blue"></text>
							<text class='text-lg'>参赛类型</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								个人赛
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="item.isJoin == 1">
						<view class='content'>
							<text class="cuIcon-info text-blue"></text>
							<text class='text-lg'>当前状态</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								报名成功
							</view>
						</view>
					</view>
					<view class="margin-top-sm" style="padding: 0;" v-if="item.isJoin == 0">
						<button class="bg-blue" @click="checkapply">确认报名</button>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<view style="height: 50rpx;width: 1rpx;"></view>
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import UQRCode from '@/node_modules/uqrcodejs/uqrcode.js';
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				patyInfo: {},
				user: {},
				item: {},
			}
		},

		onLoad(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			var item = JSON.parse(options.data); // 字符串转对象
			this.item = item;
		},
		onShow(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},
		methods: {
			checkapply() {
				var that = this;
				var activitid = Number(this.item.activityId)
				let datas = {
					userid: this.user.userid,
					userId: this.user.userid,
					userName: this.user.username,
					className: this.user.className,
					phoneNum: this.user.phonenumber,
					activityId: activitid, //long形
				}
				that.request("personal/join", datas, 'POST').then(res => {
					if (res.code == 200) {
						uni.showToast({
							title: '报名成功',
							icon: 'success',
							duration: 1000,
						});
						setTimeout(function() {
							uni.redirectTo({
								url: '/pages/index/activitie/activitielist',
							});
						}, 1000);
					} else {
						uni.showToast({
							title: '出错啦，请重试',
							icon: 'error',
							duration: 1000,
						});
						setTimeout(function() {
							uni.redirectTo({
								url: '/pages/index/activitie/activitielist',
							});
						}, 1000);
					}
				});
			}
		}
	}
</script>
<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.containera {
			margin: 0 auto;
			width: 750rpx;
		}

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					// padding: 0 30rpx;
					min-height: 100rpx;
					// /* background-color: #ffffff; */
					// /* justify-content: space-between; */
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}

	}
</style>
