<!-- 
@author : Yingming
@date : 2023
@description : 活动列表 
-->
<template>
	<view>
		<view class="cu-timeline">
			<!-- 活动预告 -->
			<view class="cu-time">
				<text class='cuIcon-rank text-white text-lg bg-purple round padding-xs'></text>
				<text class='text-xl margin-left'>活动预告</text>
			</view>
			<view class="cu-item text-blue" v-if="item.activityParStatus == 0" v-for="(item,index) in actList"
				:key="index" @>
				<view class="content">
					<view class="cu-capsule radius">
						<view class="cu-tag bg-blue">{{item.activityName}}</view>
					</view>
					<view class="margin-top-sm" v-if="item.activityStartEnrollTime != null">
						报名开始时间：{{item.activityStartEnrollTime}}</view>
				</view>
			</view>
			<!-- 正在报名 -->
			<view class="cu-time">
				<text class='cuIcon-rank text-white text-lg bg-purple round padding-xs'></text>
				<text class='text-xl margin-left'>报名中</text>
			</view>
			<view class="cu-item text-blue" v-if="item.activityParStatus == 1" v-for="(item,index) in actList"
				:key="index" @>
				<view class="content">
					<view class="cu-capsule radius">
						<view class="cu-tag bg-blue" v-if="item.activityType == 1">{{item.activityName}}</view>
						<view class="cu-tag bg-yellow" v-if="item.activityType ==2">{{item.activityName}}</view>
						<view class="cu-tag bg-green" v-if="item.activityType == 3">{{item.activityName}}</view>
						<view class="cu-tag bg-pink" v-if="item.activityType == 4">{{item.activityName}}</view>
					</view>
					<view style="height: 1rpx;width: 1rpx;"></view>
					<view class="cu-capsule radius">
						<view class="cu-tag line-blue" v-if="item.activityType == 1">{{item.activityTypeName}}</view>
						<view class="cu-tag line-blue" v-if="item.activityType == 1 && item.activityTeam == 'true' ">团队
						</view>
						<view class="cu-tag line-blue" v-if="item.activityType == 1 && item.activityTeam == 'false' ">个人
						</view>
						<view class="cu-tag line-yellow" v-if="item.activityType == 2">{{item.activityTypeName}}</view>
						<view class="cu-tag line-yellow" v-if="item.activityType == 2 && item.activityTeam == 'true' ">
							团队</view>
						<view class="cu-tag line-yellow" v-if="item.activityType == 2 && item.activityTeam == 'false' ">
							个人</view>
						<view class="cu-tag line-green" v-if="item.activityType == 3">{{item.activityTypeName}}</view>
						<view class="cu-tag line-green" v-if="item.activityTeam == 'false' && item.activityType == 3">个人
						</view>
						<view class="cu-tag line-green" v-if="item.activityTeam == 'true' && item.activityType == 3">团队
						</view>
						<view class="cu-tag line-pink" v-if="item.activityType == 4">{{item.activityTypeName}}</view>
						<view class="cu-tag line-pink" v-if="item.activityType == 4 && item.activityTeam == 'true' ">团队
						</view>
						<view class="cu-tag line-pink" v-if="item.activityType == 4 && item.activityTeam == 'false' ">个人
						</view>
					</view>
					<view class="margin-top" v-if="item.activityBriefly != null">
						活动简介：{{item.activityBriefly}}</view>
					<view class="margin-top-sm" v-if="item.activityStarttime != null">活动开始时间：{{item.activityStarttime}}
					</view>
					<view class="margin-top-sm" v-if="item.activityEndtime != null">活动结束时间：{{item.activityEndtime}}
					</view>
					<view class="margin-top-sm" v-if="item.activityStartEnrollTime != null">
						报名开始时间：{{item.activityStartEnrollTime}}</view>
					<view class="margin-top-sm" v-if="item.activityEndEnrollTime != null ">
						报名结束时间：{{item.activityEndEnrollTime}}</view>
					<view class="margin-top-sm" v-if="item.activityOrganizer != null">主办单位：{{item.activityOrganizer}}
					</view>
					<view class="margin-top-sm" v-if="item.activityUndertake != null">承办单位：{{item.activityUndertake}}
					</view>
					<view class="margin-top-sm" v-if="item.activityAssisted != null">协办单位：{{item.activityAssisted}}
					</view>
					<view class="margin-top-sm" v-if="item.activitySponsor != null">赞助单位：{{item.activitySponsor}}</view>
					<view class="margin-top-sm" v-if="item.activityTeam == 'false' && item.isJoin == 0"><button
							@click="gotoapplyone(item)">前往报名</button></view>
					<view class="margin-top-sm" v-if="item.activityTeam == 'false' && item.isJoin == 1"><button
							@click="gotoapplyone(item)">查看报名信息</button></view>
					<view class="margin-top-sm" v-if="item.activityTeam == 'true' && item.isJoin == 0"><button
							@click="gotoapplyteam(item)">前往报名</button></view>
					<view class="margin-top-sm" v-if="item.activityTeam == 'true' && item.isJoin == 1"><button
							@click="gotoapplyteam(item)">查看团队信息</button></view>
				</view>
			</view>
			<!-- 比赛进行中 -->
			<view class="cu-time">
				<text class='cuIcon-icloading text-white text-lg bg-purple round padding-xs'></text>
				<text class='text-xl margin-left'>进行中</text>
			</view>
			<view class="cu-item text-blue" v-if="item.activityParStatus == 2 || item.activityParStatus == 3"
				v-for="(item,index) in actList" :key="index" @>
				<view class="content">
					<view class="cu-capsule radius">
						<view class="cu-tag bg-blue" v-if="item.activityType == 1">{{item.activityName}}</view>
						<view class="cu-tag bg-yellow" v-if="item.activityType ==2">{{item.activityName}}</view>
						<view class="cu-tag bg-green" v-if="item.activityType == 3">{{item.activityName}}</view>
						<view class="cu-tag bg-pink" v-if="item.activityType == 4">{{item.activityName}}</view>
					</view>
					<view style="height: 1rpx;width: 1rpx;"></view>
					<view class="cu-capsule radius">
						<view class="cu-tag line-blue" v-if="item.activityType == 1">{{item.activityTypeName}}</view>
						<view class="cu-tag line-blue" v-if="item.activityType == 1 && item.activityTeam == 'true' ">团队
						</view>
						<view class="cu-tag line-blue" v-if="item.activityType == 1 && item.activityTeam == 'false' ">个人
						</view>
						<view class="cu-tag line-yellow" v-if="item.activityType == 2">{{item.activityTypeName}}</view>
						<view class="cu-tag line-yellow" v-if="item.activityType == 2 && item.activityTeam == 'true' ">
							团队</view>
						<view class="cu-tag line-yellow" v-if="item.activityType == 2 && item.activityTeam == 'false' ">
							个人</view>
						<view class="cu-tag line-green" v-if="item.activityType == 3">{{item.activityTypeName}}</view>
						<view class="cu-tag line-green" v-if="item.activityTeam == 'false' && item.activityType == 3">个人
						</view>
						<view class="cu-tag line-green" v-if="item.activityTeam == 'true' && item.activityType == 3">团队
						</view>
						<view class="cu-tag line-pink" v-if="item.activityType == 4">{{item.activityTypeName}}</view>
						<view class="cu-tag line-pink" v-if="item.activityType == 4 && item.activityTeam == 'true' ">团队
						</view>
						<view class="cu-tag line-pink" v-if="item.activityType == 4 && item.activityTeam == 'false' ">个人
						</view>
					</view>
					<view class="margin-top" v-if="item.activityBriefly != null">
						活动简介：{{item.activityBriefly}}</view>
					<view class="margin-top-sm" v-if="item.activityStarttime != null">活动开始时间：{{item.activityStarttime}}
					</view>
					<view class="margin-top-sm" v-if="item.activityEndtime != null">活动结束时间：{{item.activityEndtime}}
					</view>
					<view class="margin-top-sm" v-if="item.activityOrganizer != null">主办单位：{{item.activityOrganizer}}
					</view>
					<view class="margin-top-sm" v-if="item.activityUndertake != null">承办单位：{{item.activityUndertake}}
					</view>
					<view class="margin-top-sm" v-if="item.activityAssisted != null">协办单位：{{item.activityAssisted}}
					</view>
					<view class="margin-top-sm" v-if="item.activitySponsor != null">赞助单位：{{item.activitySponsor}}</view>
					<view class="margin-top-sm" v-if="item.activityTeam == 'false' && item.isJoin == 1"><button
							@click="gotoapplyone(item)">查看报名信息</button></view>
					<view class="margin-top-sm" v-if="item.activityTeam == 'true' && item.isJoin == 1"><button
							@click="gotoapplyteam(item)">查看团队信息</button></view>
				</view>
			</view>
			<!-- 比赛已结束 -->
			<view class="cu-time">
				<text class='cuIcon-roundcheck text-white text-lg bg-purple round padding-xs'></text>
				<text class='text-xl margin-left'>已结束</text>
			</view>
			<view class="cu-item text-blue" v-if="item.activityParStatus == 4" v-for="(item,index) in actList"
				:key="index" @>
				<view class="content">
					<view class="cu-capsule radius">
						<view class="cu-tag bg-red">{{item.activityName}}</view>
						<view class="cu-tag line-red">{{item.activityTypeName}}</view>
						<view class="cu-tag line-red" v-if="item.activityTeam == 'true' ">团队</view>
						<view class="cu-tag line-red" v-if="item.activityTeam == 'false' ">个人</view>
					</view>
					<view class="margin-top" v-if="item.activityBriefly != null">活动简介：{{item.activityBriefly}}</view>
					<view class="margin-top-sm" v-if="item.activityOrganizer != null">主办单位：{{item.activityOrganizer}}
					</view>
					<view class="margin-top-sm" v-if="item.activityUndertake != null">承办单位：{{item.activityUndertake}}
					</view>
					<view class="margin-top-sm" v-if="item.activityAssisted != null">协办单位：{{item.activityAssisted}}
					</view>
					<view class="margin-top-sm" v-if="item.activitySponsor != null">赞助单位：{{item.activitySponsor}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				actList: []
			};
		},
		onShow() {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			this.actlist();
		},
		methods: {
			actlist: function() {
				var that = this;
				let datas = {
					userid: this.user.userid,
				}
				that.request("activityList", datas, 'GET').then(res => {
					that.actList = res.rows
					let list = that.actList.map((item) => {
						item.activityId = item.activityId + "";
						item.activityParStatus = item.activityParStatus + "";
						item.activityVolStatus = item.activityVolStatus + "";
						item.activityTeam = item.activityTeam + "";
						item.version = item.version + "";
						item.isJoin = item.isJoin + "";
						item.isDisplay = item.isDisplay + "";
						return item
					})
					that.actList = list
				});
			},
			gotoapplyone(item) {
				var items = JSON.stringify(item);
				uni.redirectTo({
					url: '/pages/index/activitie/applicationone?data=' + items,
				});
			},
			gotoapplyteam(item) {
				var that = this;
				var items = JSON.stringify(item);
				if (item.isJoin == 0) {
					uni.navigateTo({
						url: '/pages/index/activitie/applicationteamche?data=' + items,
					});
				}
				if (item.isJoin == 1) {
					uni.navigateTo({
						url: '/pages/index/activitie/applicationteaminfo?data=' + items,
					});
				}
			},
		}
	};
</script>

<style lang="scss" scoped>
	/* #ifndef H5 */
	page {
		height: 100%;
		background-color: #f2f2f2;
	}

	/* #endif */
</style>

<style lang="scss" scoped>
	.cu-timeline .cu-time {
		width: 100%;
		text-align: left;
		padding: 20rpx 0 20rpx 37rpx;
		font-size: 26rpx;
		color: #888;
		display: block;
	}

	.text-red,
	.line-red,
	.lines-red {
		color: #FF3434;
	}

	.cu-timeline button {
		font-size: 30rpx;
		background: #55aaff;
		color: #fff;
		top: 20rpx;
		height: 70rpx;
		line-height: 70rpx;
		border-radius: 50rpx;
		box-shadow: 0 5px 7px 0 rgba(85, 170, 255, 0.2);
	}

	.margin-avatar {
		margin-left: -15rpx;
	}

	.margin-avatar-bottom {
		margin-bottom: 150rpx;
	}

	.line-blue-tuniao::after {
		border-color: #0070ff !important;
		color: #0070ff;
	}

	.resume {
		padding-top: 10rpx;
		border-radius: 6rpx;
		display: block;
		color: #666;
		line-height: 1.6;
	}

	.resume+.resume {
		margin-top: 20rpx;
	}

	.resume2 {
		padding-top: 10rpx;
		border-radius: 6rpx;
		display: block;
		color: #666;
		line-height: 1.6;
	}

	.edit {
		position: fixed;
		width: 100rpx;
		height: 100rpx;
		bottom: 250rpx;
		right: 30rpx;
		z-index: 1;
		opacity: 0.8;
		border: 1px solid #189eff;
		border-radius: 100rpx;
		box-shadow: 0rpx 0rpx 6rpx rgba(24, 158, 255, 1);
		padding: 20rpx;
	}

	.love {
		position: fixed;
		width: 100rpx;
		height: 100rpx;
		bottom: 550rpx;
		right: 30rpx;
		z-index: 1024;
		opacity: 0.8;
		border: 1px solid #189eff;
		border-radius: 100rpx;
		box-shadow: 0rpx 0rpx 6rpx rgba(24, 158, 255, 1);
		padding: 20rpx;
	}

	.bg-img-cont {
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 350rpx;
	}

	.share-png {
		width: 100rpx;
		height: 100rpx;
		margin: 0 auto;
	}

	.share-wechat {
		width: 35rpx;
		height: 35rpx;
		margin: 0 10rpx -4rpx 0;
		opacity: 0.5;
	}

	.button-no::after {
		border: none;
	}

	.title-pyq {
		background-image: -webkit-linear-gradient(0deg, #1b6cff, #1ca5ff);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
		opacity: 0.5;
	}

	.edit-fixed {
		position: fixed;
		width: 100%;
		bottom: 0;
		z-index: 1024;
		box-shadow: 0 1rpx 6rpx rgba(0, 0, 0, 0.1);
	}

	.button-no {
		border: none;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0);
	}

	.centre {
		text-align: center;
		margin: 200rpx auto;
		font-size: 32rpx;

		image {
			width: 300rpx;
			border-radius: 50%;
			margin: 0 auto;
		}

		.tips {
			font-size: 24rpx;
			color: #999999;
			margin-top: 20rpx;
		}

		.btn {
			margin: 80rpx auto;
			width: 200rpx;
			border-radius: 32rpx;
			line-height: 64rpx;
			color: #ffffff;
			font-size: 26rpx;
			background: linear-gradient(270deg, #1cbbb4 0%, #0081ff 100%);
		}
	}

	.wrap {
		display: flex;
		flex-direction: column;
		height: calc(100vh - var(--window-top));
		width: 100%;
	}

	.swiper-box {
		flex: 1;
	}

	.swiper-item {
		height: 100%;
	}
</style>
