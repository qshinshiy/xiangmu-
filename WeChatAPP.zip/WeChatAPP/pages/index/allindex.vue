<!-- 
@author : Yingming
@date : 2023
@description : 全部功能列表
-->
<template>
    <view>
        <o-grid col="4" gutter square radius title="信息系统" size="sm">
            <o-grid-item
                text="个人信息"
                icon="icon-account"
                @click="gomMYinfo"
            />
            <o-grid-item
                text="教师查询"
                icon="icon-Customermanagement-fill"
                @click="goBasic"
                v-if="roleDate == 1 || roleDate == 2 || roleDate == 3"
            />
        </o-grid>
        <o-grid col="4" gutter square radius title="网工生活" size="sm">
            <o-grid-item text="活动报名" icon="icon-flag" @click="goACT" />
            <o-grid-item
                text="活动参与记录"
                icon="icon-rankinglist"
                @click="gomyact"
            />
            <!-- <o-grid-item text="网工毕业季" icon="icon-video" @click="goGoodBye" /> -->
        </o-grid>
        <o-grid col="4" gutter square radius title="党务相关" size="sm">
            <o-grid-item
                text="志愿者活动"
                icon="icon-operation"
                @click="goVolunteer"
            />
            <o-grid-item
                text="我的志愿信息"
                icon="icon-bussiness-man-fill"
                @click="goVolinfo"
            />
            <o-grid-item
                text="志愿参与记录"
                icon="icon-nav-list"
                @click="gomyvol"
            />
            <o-grid-item
                text="政治面貌"
                icon="icon-collection"
                @click="goParty"
            />
            <o-grid-item
                text="志愿者签到"
                icon="icon-robot"
                @click="volcodemanage"
                v-if="roleDate == 1 || roleDate == 2 || roleDate == 4"
            />
        </o-grid>
        <o-grid col="4" gutter square radius title="教学平台" size="sm">
            <o-grid-item text="WCT排行" icon="icon-topsales" @click="goOJPH" />
            <o-grid-item
                text="WCT密码重置"
                icon="icon-unlock"
                @click="goOJRESET"
            />
            <o-grid-item
                text="我的WCT数据"
                icon="icon-guanliyuan"
                @click="goOJ"
            />
        </o-grid>
        <o-grid
            col="4"
            gutter
            square
            radius
            title="网工实验室&云萌工作室"
            size="sm"
        >
            <o-grid-item
                text="WCT数据查询"
                icon="icon-rightalignment"
                @click="goOJList"
                v-if="
                    user.gender == 15 ||
                    user.gender == 1 ||
                    user.gender == 2 ||
                    user.gender == 10 ||
                    user.gender == 11 ||
                    user.gender == 12 ||
                    user.gender == 13 ||
                    user.gender == 14
                "
            />
            <o-grid-item
                text="加入组织"
                icon="icon-trust"
                @click="goBasicSCS"
            />
            <o-grid-item
                text="预约选座"
                icon="icon-confirm"
                @click="goSeatSys"
                User
                v-if="[1, 2, 10, 11, 12, 13, 14, 15].includes(user.gender)"
            />

            <!-- <o-grid-item text="考勤打卡" icon="icon-map" @click="goBasic" v-if="user.gender == 1 || user.gender == 2 || user.gender == 10 || user.gender == 11 || user.gender == 12 || user.gender == 13"/> -->
            <!-- <o-grid-item text="请假申请" icon="icon-aviation" @click="goBasic" v-if="user.gender == 1 || user.gender == 2 || user.gender == 10 || user.gender == 11 || user.gender == 12 || user.gender == 13"/> -->
            <!-- <o-grid-item text="面试管理" icon="icon-xiakuangxian" @click="goExaminer" /> -->
        </o-grid>
        <o-grid col="4" gutter square radius title="云萌大模型" size="sm">
            <o-grid-item
                text="对话次数重置"
                icon="icon-confirm"
                @click="reset_calls()"
                User
                v-if="[1, 2, 10, 11, 12, 13, 14, 15].includes(user.gender)"
            />
        </o-grid>

        <view style="height: 40rpx; width: 1rpx"></view>
    </view>
</template>

<script>
import { get_url, get_encryption_key } from "@/utils/config_Django.js";
import request from "@/utils/request.js";
import { getUserInfo, getToken } from "@/utils/auth";
export default {
    data() {
        return {
            user: {},
            token: {},
            roleDate: {},
            _url: {},
        };
    },
    onShow: function (data) {
        this._url = get_url() || {};
        this.user = getUserInfo() || {};
        this.token = getToken() || {};
        this.admin();
    },
    methods: {
        go_show_selfinfo() {
            uni.navigateTo({
                url: "pages/chatai/self_info",
            });
        },
        reset_calls() {
            uni.request({
                url: `${this._url}chat/reset_calls/`,
                method: "POST",
                data: {
                    "student_id": this.user.userid,
                    "student_token": this.token,
                },
                success: (res) => {
                    if (200 <= res.statusCode && res.statusCode <= 300) {
                        uni.showToast({
                            title: "重置成功",
                            icon: "none",
                            duration: 2000,
                        });
                    } else if (res.statusCode == 406) {
                        uni.showToast({
                            title: "还未绑定，正在跳转绑定",
                            icon: "none",
                            duration: 2000,
                        });
                        setTimeout(() => {
                            uni.navigateTo({
                                url: "/pages/chatai/band_gpt_id",
                            });
                        }, 500);
                    } else {
                        uni.showToast({
                            title: res.data.message,
                            icon: "none",
                            duration: 2000,
                        });
                    }
                },
                fail: (err) => {
                    uni.showToast({
                        title: "重置失败",
                        icon: "none",
                        duration: 2000,
                    });
                },
            });
        },

        volcodemanage() {
            uni.navigateTo({
                url: "/pages/index/administrators/volcodemanage",
            });
        },
        admin() {
            var that = this;
            let datas = {
                userid: this.user.userid,
            };
            that.request("wxrole", datas, "GET").then((res) => {
                that.roleDate = res.data.roleDate;
            });
        },
        gomMYinfo() {
            uni.navigateTo({
                url: "/pages/me/myinfo",
            });
        },
        goSeatSys() {
            uni.navigateTo({
                url: "/pages/seat_selection_sys/seat_selection_sys",
            });
        },
        goGoodBye() {
            uni.showToast({
                title: "还没有到毕业季哦~",
                icon: "none",
                duration: 2000,
            });
            // uni.navigateTo({
            // 	url: '/pages/index/goodbey'
            // });
        },
        gomyact() {
            uni.navigateTo({
                url: "/pages/index/activitie/myactivitie",
            });
        },
        gomyvol() {
            uni.navigateTo({
                url: "/pages/index/volunteer/myvolunteer",
            });
        },
        goOJRESET() {
            uni.navigateTo({
                url: "/pages/index/ojreset",
            });
        },
        goOJList() {
            uni.navigateTo({
                url: "/pages/index/scslab/queryoj",
            });
        },
        goOJ() {
            uni.navigateTo({
                url: "/pages/index/OJ",
            });
        },
        goOJPH() {
            uni.switchTab({
                url: "/pages/rank/rank",
            });
        },
        goParty() {
            if (this.user.isParty == 1) {
                uni.navigateTo({
                    url: "/pages/index/party/party",
                });
            } else {
                uni.navigateTo({
                    url: "/pages/index/party/liucheng",
                });
            }
        },
        goACT() {
            uni.navigateTo({
                url: "/pages/index/activitie/activitielist",
            });
        },
        goBasic() {
            uni.showToast({
                title: "即将上线，敬请期待！",
                icon: "none",
                duration: 2000,
            });
        },
        goExaminer() {
            uni.navigateTo({
                url: "/pages/index/enroll/enrolladminlist",
            });
        },
        goBasicSCS() {
            // if (this.user.token == null) {
            // 	uni.showToast({
            // 		title: '请登录后使用，正在前往登录页面',
            // 		icon: 'none',
            // 		duration: 2000
            // 	})
            // 	setTimeout(function() {
            // 		uni.switchTab({
            // 			url: '/pages/me/me'
            // 		});
            // 	}, 1000);
            // } else {
            // 	var that = this;
            // 	let datas = {
            // 		userid: this.user.userid,
            // 	}
            // 	console.log(datas)
            // 	that.request("enroll/" + this.user.userid, 'GET').then(res => {
            // 		console.log(res.data)
            // 		if (res.data == null) {
            // 			uni.navigateTo({
            // 				url: '/pages/index/enroll/applicants'
            // 			});
            // 		}
            // 		else{
            // 			uni.navigateTo({
            // 				url: '/pages/index/enroll/applicationinfo'
            // 			});
            // 		}
            // 	});
            // }
            uni.showToast({
                title: "当前暂无招生需求",
                icon: "none",
                duration: 2000,
            });
        },
        goVolunteer() {
            var that = this;
            let datas = {
                userid: this.user.userid,
            };
            that.request("vol/activityList", datas, "GET").then((res) => {
                if (res.data.isVol == 0) {
                    uni.navigateTo({
                        url: "/pages/index/volunteer/volunteerapply",
                    });
                }
                if (res.data.isVol == 1) {
                    uni.navigateTo({
                        url: "/pages/index/volunteer/volunteerlist",
                    });
                }
            });
        },
        goVolinfo() {
            var that = this;
            let datas = {
                userid: this.user.userid,
            };
            that.request("vol/activityList", datas, "GET").then((res) => {
                if (res.data.isVol == 0) {
                    uni.navigateTo({
                        url: "/pages/index/volunteer/volunteerapply",
                    });
                }
                if (res.data.isVol == 1) {
                    uni.navigateTo({
                        url: "/pages/index/volunteer/myvolinfo",
                    });
                }
            });
        },
    },
};
</script>
