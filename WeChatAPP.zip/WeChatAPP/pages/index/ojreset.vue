<!-- 
@author : Yingming
@date : 2023
@description : 重置密码
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">重置WCT密码</text>
							<text class="text-ABC text-blue">RESETWCTCODE</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="password !=''">
						<view class="action" >
							<text class="cuIcon-command text-purple"> 新WCT密码为：{{password}}，请登录后立即修改</text>
						</view>
					</view>
					<view class="margin-top-sm" style="padding: 0;">
						<button style="background-color: #aa55ff; color: #ffffff;" v-if="password =='' || password == null " @click="gotoreset">重置本人WCT密码</button>
					</view>
					<view style="height: 20rpx;width: 1rpx;"></view>
				</view>
			</view>
			<view style="height: 50rpx;width: 1rpx;"></view>
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				token: {},
				user: {},
				password:'',
			}
		},
		onShow(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},
		methods: {
			gotoreset(){
				var that = this;
				let datas = {
					userid: this.user.userid,
					course: null,
					password: null,
					realname: null,
					school: null,
					uuid: null
				}
				that.request("oj/reset", datas, 'POST').then(res => {
					that.password = res.data.password
				});
			},
		},
	}
</script>
<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.containera {
			margin: 0 auto;
			width: 750rpx;
		}

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					min-height: 100rpx;
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}

	}
</style>
