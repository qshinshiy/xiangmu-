<!-- 
@author : Yingming
@date : 2023
@description : 对接微信程序界面（入党流程）
-->
<template>
	<view>
		<web-view src="https://mp.weixin.qq.com/s/xgBp5j4kAudhgzqqYHpDPw"></web-view>
	</view>
</template>

<script>
</script>

<style>
</style>
