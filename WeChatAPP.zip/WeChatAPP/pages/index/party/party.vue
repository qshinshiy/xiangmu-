<!-- 
@author : Yingming
@date : 2023
@description : 党员信息材料
-->
<template>
	<view class="container">
		<view class="bg-top bg-blue">
			<!-- 基本信息 -->
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">基本信息</text>
							<text class="text-ABC text-blue">UserInfo</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.username != null && user.username != ''">
						<view class="content">
							<text class="cuIcon-my text-blue"></text>
							<text class="text-lg">姓名</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.username}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.className != null && user.className != ''">
						<view class='content'>
							<text class="cuIcon-read text-blue"></text>
							<text class='text-lg'>班级</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.className}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="user.userid != null && user.userid != ''">
						<view class='content'>
							<text class="cuIcon-favor text-blue"></text>
							<text class='text-lg'>学号</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{user.userid}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;"
						v-if="patyInfo.partyNum != null && patyInfo.partyNum != ''">
						<view class='content'>
							<text class="cuIcon-info text-blue"></text>
							<text class='text-lg'>档案编号</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{patyInfo.partyNum}}
							</view>
						</view>
					</view>
				</view>
			</view>
			<!-- 入党流程列表 -->
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">时间节点</text>
							<text class="text-ABC text-blue">TimeInfo</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;"
						v-if="patyInfo.submitRequisitionTime != null && patyInfo.submitRequisitionTime != ''">
						<view class='content'>
							<text class="cuIcon-time text-blue"></text>
							<text class='text-black'>递交入党申请书时间</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{patyInfo.submitRequisitionTime}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;"
						v-if="patyInfo.sureActivistsTime != null && patyInfo.sureActivistsTime != ''">
						<view class='content'>
							<text class="cuIcon-time text-blue"></text>
							<text class='text-black'>确定积极分子时间</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{patyInfo.sureActivistsTime}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;"
						v-if="patyInfo.surePrePartyTime != null && patyInfo.surePrePartyTime != ''">
						<view class='content'>
							<text class="cuIcon-time text-blue"></text>
							<text class='text-black'>确定预备党员时间</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{patyInfo.surePrePartyTime}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;"
						v-if="patyInfo.surePartyTime != null && patyInfo.surePartyTime != ''">
						<view class='content'>
							<text class="cuIcon-time text-blue"></text>
							<text class='text-black'>确定正式党员时间</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-blue light">
								{{patyInfo.surePartyTime}}
							</view>
						</view>
					</view>
				</view>
			</view>
			<!-- 党员材料清单 -->
			<view class="center-box shadow">
				<view class="cu-list menu">
					<view class="cu-bar bg-white margin-top-xs u-border-bottom">
						<view class="action sub-title">
							<text class="text-xl text-bold text-blue text-shadow">材料清单</text>
							<text class="text-ABC text-blue">INFOLIST</text>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.partyRequisitionNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>入党申请书</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.partyRequisitionNum + "份"}}
							</view>
							<view v-if="patyInfo.partyRequisitionOther != null && patyInfo.partyRequisitionOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.partyRequisitionOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.submitTalkNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>入党申请谈话记录表</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.submitTalkNum + "份"}}
							</view>
							<view v-if="patyInfo.submitTalkOther != null && patyInfo.submitTalkOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.submitTalkOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.excellentNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>团组织推优表</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.excellentNum + "份"}}
							</view>
							<view v-if="patyInfo.excellentOther != null && patyInfo.excellentOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.excellentOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.activistsAssessNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>党校结业证复印件</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.activistsAssessNum + "份"}}
							</view>
							<view v-if="patyInfo.activistsAssessOther != null && patyInfo.activistsAssessOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.activistsAssessOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.activistsReportNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>积极分子思想汇报</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.activistsReportNum + "份"}}
							</view>
							<view v-if="patyInfo.activistsReportOther != null && patyInfo.activistsReportOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.activistsReportOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.devManAnnoNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>发展对象公示材料</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.devManAnnoNum + "份"}}
							</view>
							<view v-if="patyInfo.devManAnnoOther != null && patyInfo.devManAnnoOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.devManAnnoOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.devManReportNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>发展对象思想汇报</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.devManReportNum + "份"}}
							</view>
							<view v-if="patyInfo.devManReportOther != null && patyInfo.devManReportOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.devManReportOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.devManRetrainingNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>发展对象集中培训表</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.devManRetrainingNum + "份"}}
							</view>
							<view v-if="patyInfo.devManRetrainingOther != null && patyInfo.devManRetrainingOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.devManRetrainingOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.politicalReviewNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>政审材料</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.politicalReviewNum + "份"}}
							</view>
							<view v-if="patyInfo.politicalReviewOther != null && patyInfo.politicalReviewOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.politicalReviewOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.personalAutobiographyNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>个人自传</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.personalAutobiographyNum + "份"}}
							</view>
							<view
								v-if="patyInfo.personalAutobiographyOther != null && patyInfo.personalAutobiographyOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.personalAutobiographyOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.activistsToPrePartyNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>培养考察登记表</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.activistsToPrePartyNum + "份"}}
							</view>
							<view
								v-if="patyInfo.activistsToPrePartyOther != null && patyInfo.activistsToPrePartyOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.activistsToPrePartyOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.prePartyAnnoNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>预备党员公示表</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.prePartyAnnoNum + "份"}}
							</view>
							<view v-if="patyInfo.prePartyAnnoOther != null && patyInfo.prePartyAnnoOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.prePartyAnnoOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.prePartyReportNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>预备党员思想汇报</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.prePartyReportNum + "份"}}
							</view>
							<view v-if="patyInfo.prePartyReportOther != null && patyInfo.prePartyReportOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.prePartyReportOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.partyBookNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>入党志愿书</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.partyBookNum + "份"}}
							</view>
							<view v-if="patyInfo.partyBookOther != null && patyInfo.partyBookOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.partyBookOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.preToFormalNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>转正申请书</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.preToFormalNum + "份"}}
							</view>
							<view v-if="patyInfo.preToFormalOther != null && patyInfo.preToFormalOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.preToFormalOther}}
							</view>
						</view>
					</view>

					<view class="cu-item" style="padding: 0;" v-if="patyInfo.preToFormalTalkNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>转正谈话记录表</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.preToFormalTalkNum + "份"}}
							</view>
							<view v-if="patyInfo.preToFormalTalkOther != null && patyInfo.preToFormalTalkOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.preToFormalTalkOther}}
							</view>
						</view>
					</view>
					<view class="cu-item" style="padding: 0;" v-if="patyInfo.partyAnnoNum!=null">
						<view class='content'>
							<text class="cuIcon-list text-blue"></text>
							<text class='text-black'>正式党员公示表</text>
						</view>
						<view class="action">
							<view class="cu-tag round bg-green light">
								{{patyInfo.partyAnnoNum + "份"}}
							</view>
							<view v-if="patyInfo.partyAnnoOther != null && patyInfo.partyAnnoOther != ''"
								class="cu-tag round bg-red light">
								{{patyInfo.partyAnnoOther}}
							</view>
						</view>
					</view>
				</view>
			</view>
			<view style="height: 50rpx;width: 1rpx;"></view>
		</view>
	</view>
</template>

<script>
	import request from '@/utils/request.js';
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
	export default {
		data() {
			return {
				patyInfo: {},
				user: {},
			}
		},
		onShow() {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			let userid = this.user.userid
			let that = this
			this.request("party", userid, 'POST').then(patyInfo => {
				that.patyInfo = patyInfo.data
			})
		},
		onLoad() {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			let userid = this.user.userid
			let that = this
			this.request("party", userid, 'POST').then(patyInfo => {
				that.patyInfo = patyInfo.data
			})
		},
	}
</script>
<style lang="scss" scoped>
	.container {
		width: 750rpx;
		color: #333333;

		.bg-top {
			margin-top: -1rpx;
			width: 750rpx;
			height: 220rpx;
			padding-top: 50rpx;
			border-radius: 0 0 20% 20%;

			.top-box {
				width: 700rpx;
				background-color: #FFFFFF;
				margin: 0 auto;
				border-radius: 20rpx;
				padding: 20rpx 30rpx 0rpx;
				position: relative;

				.qh-pic {
					position: absolute;
					right: 64rpx;
					top: -50rpx;
					border-radius: 12rpx;
				}

				.qh-title {
					width: 100%;
					height: 60rpx;
					line-height: 65rpx;
					padding-right: 190rpx;
				}

				.bxBox {
					position: relative;
					display: flex;
					min-height: 100rpx;
					align-items: center;
					font-size: 30rpx;
					line-height: 1.6em;
					flex: 1;

					.bxImg {
						display: inline-block;
						margin-right: 10rpx;
						width: 1.6em;
						text-align: center;
					}
				}

			}
		}

		.center-box {
			color: #333333;
			width: 700rpx;
			background-color: #FFFFFF;
			margin: 0 auto;
			border-radius: 20rpx;
			padding: 0rpx 30rpx 0rpx;
			position: relative;
			margin-top: 20rpx;
		}
	}
</style>
