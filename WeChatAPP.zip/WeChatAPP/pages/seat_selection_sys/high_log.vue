<template>
	<view>
		<view v-for="record in records.slice().reverse()" :key="record.record_id" class="record-item">
			<text>
				操作: <text style="color:red">{{ record.information }}</text>\n
				操作时间: <text style="color:#061dff">{{ record.operation_time }}</text>\n
				操作人: <text style="color:#007066">{{ record.user_name }}</text>\n
				id: <text style="color:red"> {{ record.user_id }}</text>\n\n\n
			</text>
		</view>
	</view>
</template>
<script>
	import {
		get_url
	} from '@/utils/config_Django.js'

	export default {
		data() {
			return {
				records: [],
			};
		},
		onLoad() {
			this._url = get_url() || {};
		},
		mounted() {
			this.fetchRecords();
		},
		methods: {
			fetchRecords() {
				uni.request({
					url: `${this._url}seat/get_all_records/`,
					method: "POST",
					success: (res) => {
						console.log(res.data)
						this.records = res.data.records
					},
					fail: (err) => {
						console.error('Failed to fetch records:', err);
					},
				});
			},
		},
	};
</script>

<style>
	.record-item {
		margin-bottom: 20px;
		padding: 10px;
		border: 1px solid #ccc;
		border-radius: 5px;
		background-color: #f8f8f8;
	}
	.record-item:first-child{
		margin-top: 10px;
	}
</style>