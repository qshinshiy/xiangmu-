<template>
	<view class="activity-form">
		<view style="padding:0 0 0 20px;" class="form-group">
			<text>活动备注：</text>
			<input type="text" id="activityNote" v-model="activityNote" />
		</view>

		<view class="form-group">

			<picker mode="date" class="date_select" @change="update_dateselect">
				<view class="picker">
					<text>活动日期：</text>
					<text style="color:blue;">{{ selectes_date }}({{weekday}})</text>
				</view>
			</picker>
		</view>
		<text style="padding:0 0 0 20px;">选择时间段:</text>
		<view class="form-group time_select_box">

			<view :class="{selected_time:timeselected.includes(0),time_selectbtn:true}" @click="select_time(0)">
				08:00~12:00</view>
			<view :class="{selected_time:timeselected.includes(1),time_selectbtn:true}" @click="select_time(1)">
				13:00~18:00</view>
			<view :class="{selected_time:timeselected.includes(2),time_selectbtn:true}" @click="select_time(2)">
				19:00~22:00</view>

		</view>


		<button class="submitbutton" @click="submitForm">提交</button>
	</view>
</template>

<script>
	import {
		get_url
	} from '@/utils/config_Django.js'
	export default {
		data() {
			return {
				activityNote: "",
				timeselected: [],
				selectes_date: "点击选择时间",
				weekday: "点击选择",
				_url: {},
			}
		},
		onLoad: function(data) {
			this._url = get_url() || {};
		},
		methods: {
			submitForm() {
				uni.request({
					url: `${this._url}seat/activity_lock/`,
					method: 'POST',
					data: {
						"activityNote": this.activityNote,
						"timeselected": this.timeselected,
						"selectes_date": this.selectes_date,
					},
					success: (res) => {
						uni.showToast({
							title: res.data.message,
							icon: 'none',
							duration: 1700
						})
					},
					fail: (err) => {
						uni.showToast({
							title: `失败，请重试`,
							icon: 'error',
							duration: 1700
						})
						console.error('提交失败请重试', err);
					}
				});
			},
			toggleValueInArray(value) {
				var index = this.timeselected.indexOf(value);

				if (index !== -1) {
					this.timeselected.splice(index, 1);
				} else {
					this.timeselected.push(value);
				}
			},
			update_dateselect: function(event) {
				const selectedDate = event.detail.value;
				this.selectes_date = selectedDate;
				const dateObj = new Date(selectedDate);
				const days = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
				const selectedWeekday = days[dateObj.getDay()];
				this.weekday = selectedWeekday;
			},

			select_time(time_) {
				this.toggleValueInArray(time_);
			}
		},
	}
</script>

<style>
	.date_select {
		padding: 20px;
		width: 100%;
	}

	.activity-form {
		height: 38vh;
		display: flex;
		flex-direction: column;
		align-items: stretch;
		flex-wrap: nowrap;
		justify-content: space-around;
	}

	#activityNote {
		padding: 4px;
		width: 80%;
		height: 5vh;
		border-radius: 10px;
		margin-bottom: 10px;
		margin-top: 10px;
		box-shadow: inset 0px 0px 8px 4px rgb(167 167 167 / 32%);
	}

	.form-group {
		display: flex;
		flex-direction: row;
		align-items: center;
	}

	.time_select_box {
		width: 100%;
		justify-content: space-around;
	}

	.time_selectbtn {
		padding: 10px;
		border-radius: 10px;
		box-shadow: inset 0px 0px 8px 4px rgb(167 167 167 / 32%);
	}

	.selected_time {
		background-color: #ffc543;
		padding: 10px;
		border-radius: 10px;
	}

	.submitbutton {
		width: 40vh;
		background-color: #4caf50;
		color: white;
		border: none;
		cursor: pointer;
	}
</style>