<template>
    <view>
        <template>
            <view :class="{ change_def: true, hideen: is_hide }">
                <view class="outside_box">
                    <input
                        class="change_input"
                        v-model="inputValue"
                        placeholder="请输入要修改的值"
                    />
                    <view style="display: flex">
                        <button @click="modifyDefaultCount">确认</button>
                        <button @click="hide_or()">取消</button>
                    </view>
                </view>
            </view>
        </template>
        <view class="container">
            <text class="select_id_text">输入学生学号：</text>
            <input v-model="studentId" class="input" />
            <button @click="queryStudent" class="selectbutton">查询</button>

            <view v-if="studentData" class="result">
                <text>姓名: {{ studentData.name }}</text
                ><br />
                <text>学号: {{ studentData.studentId }}</text
                ><br />
                <text @click="show_input" class="info">
                    违约次数:{{ studentData.defaultCount }}(点击修改)
                </text>
            </view>
        </view>
    </view>
</template>

<script>
import {
    getConfig,
    setUserInfo,
    getUserInfo,
    setToken,
    getToken,
    getuserID,
    removeuserID,
    removeUserInfo,
    removeToken,
} from "@/utils/auth";
import { get_url } from "@/utils/config_Django.js";
export default {
    data() {
        return {
            user: {},
            token: {},
            getuserID: {},
            inputValue: "",
            is_hide: true,
            _url: {},
            studentId: "",
            studentData: null,
        };
    },
    onLoad: function (data) {
        this.user = getUserInfo() || {};
        this.token = getToken() || {};
        this.getuserID = getuserID() || {};
        this._url = get_url() || {};
    },
    methods: {
        modifyDefaultCount() {
            uni.request({
                url: `${this._url}seat/select_defaulters/`,
                method: "POST",
                data: {
                    "studentId": this.studentId,
                    "type": "change",
                    "change_num": this.inputValue,
                    "student_token": this.token,
                    "student_id": this.getuserID,
                },
                success: (res) => {
                    if (res.statusCode >= 200 && res.statusCode < 300) {
                        this.queryStudent();
                        this.is_hide = true;
                    } else {
                        // 处理错误情况
                        uni.showToast({
                            title: res.data.message,
                            icon: "none",
                        });
                    }
                },
                fail: (err) => {
                    console.error(err);
                    uni.showToast({
                        title: "请求失败",
                        icon: "none",
                    });
                },
            });
        },
        queryStudent() {
            // 发送请求到后端
            uni.request({
                url: `${this._url}seat/select_defaulters/`,
                method: "POST",
                changeOrigin: true,
                data: {
                    "type": "select",
                    "studentId": this.studentId,
                    // studentId: "22016021001"
                },
                success: (res) => {
                    if (res.statusCode >= 200 && res.statusCode < 300) {
                        this.studentData = res.data;
                    } else {
                        // 处理错误情况
                        uni.showToast({
                            title: res.data.message,
                            icon: "none",
                        });
                    }
                },
                fail: (err) => {
                    console.error(err);
                    uni.showToast({
                        title: "请求失败",
                        icon: "none",
                    });
                },
            });
        },
        hide_or() {
            this.is_hide = true;
        },
        show_input() {
            this.is_hide = false;
        },
    },
};
</script>

<style>
.outside_box {
    left: 100px;
    background-color: aliceblue;
    display: flex;
    width: 20vh;
    flex-direction: column;
    width: 187px;
    position: absolute;
    top: 200px;
    padding: 10px;
    border-radius: 10px;
}

.hideen {
    display: none;
}

.change_input {
    box-shadow: inset 0px 0px 8px 4px rgb(167 167 167 / 32%);
    background-color: white;
    width: 150px;
    height: 5vh;
    border-radius: 10px;
    margin-bottom: 10px;
    margin-top: 10px;
    margin-left: 10px;
}

.change_def {
    position: absolute;
    z-index: 100;
    width: 100vh;
    height: 100vh;
    background-color: #262626a0;
}

.container {
    padding: 20px;
}

.select_id_text {
    width: auto;
    height: auto;
    position: relative;
    bottom: -10px;
    left: 2px;
    font-size: 18px;
}

.input {
    padding: 4px;
    width: 100%;
    height: 5vh;
    border-radius: 10px;
    margin-bottom: 10px;
    margin-top: 10px;
    box-shadow: inset 0px 0px 8px 4px rgb(167 167 167 / 32%);
}

.selectbutton {
    background-color: #4caf50;
    color: white;
    border: none;
    cursor: pointer;
}

.result {
    margin-top: 20px;
}

.info {
    margin-bottom: 10px;
    cursor: pointer;
    color: #3366cc;
}
</style>
