<template>
    <view>
        <o-grid col="4" gutter square radius title="签到" size="sm">
            <!-- 扫码签到按钮 -->
            <o-grid-item
                text="扫码签到"
                icon="icon-scanning"
                @click="scanCheckIn"
            />
        </o-grid>

        <o-grid col="4" gutter square radius title="座位预约" size="sm">
            <!-- 座位预约按钮 -->
            <o-grid-item
                text="C2-105"
                icon="icon-confirm"
                @click="seatReservation105"
            />
            <o-grid-item
                text="C2-202"
                icon="icon-connections"
                @click="seatReservation202"
            />
            <!-- <o-grid-item text="C2-105" icon="icon-confirm" @click="" /> -->
        </o-grid>

        <o-grid col="4" gutter square radius title="信息查询" size="sm">
            <o-grid-item
                text="预约记录"
                icon="icon-order"
                @click="appointmentRecords"
            />
            <o-grid-item
                text="个人信息"
                icon="icon-kehupandian"
                @click="violationRecords"
            />
        </o-grid>

        <o-grid
            v-if="[1, 2].includes(user.gender)"
            col="4"
            gutter
            square
            radius
            title="座位管理"
            size="sm"
        >
            <view class="admin_button">
                <o-grid-item
                    text="释放选座"
                    icon="icon-click"
                    @click="release_seat"
                />
            </view>
            <view class="admin_button">
                <o-grid-item
                    text="锁定选座"
                    icon="icon-unlock"
                    @click="lock_seat"
                />
            </view>
            <view class="admin_button">
                <o-grid-item
                    text="锁定时间段"
                    icon="icon-clock"
                    @click="activity_lock"
                />
            </view>
        </o-grid>

        <o-grid
            v-if="[1, 2, 11, 12, 13].includes(user.gender)"
            col="4"
            gutter
            square
            radius
            title="座位管理"
            size="sm"
        >
            <view class="admin_button">
                <o-grid-item
                    text="违约查询"
                    icon="icon-beijing"
                    @click="check_defaul"
                />
            </view>
            <view class="admin_button">
                <o-grid-item
                    text="操作记录"
                    icon="icon-manage-order-fill"
                    @click="get_all_records"
                />
            </view>
        </o-grid>
    </view>
</template>

<script>
import { get_url, get_encryption_key } from "@/utils/config_Django.js";

import {
    getConfig,
    setUserInfo,
    getUserInfo,
    setToken,
    getToken,
    getuserID,
    removeuserID,
    removeUserInfo,
    removeToken,
} from "@/utils/auth";

export default {
    data() {
        return {
            saoma_img: null,
            debug: false,
            user: {},
            token: {},
            getuserID: {},
            _url: {},
            res: "",
            encryption_key: "",
        };
    },
    onLoad: function (data) {
        this._url = get_url() || {};
        this.user = getUserInfo() || {};
        this.token = getToken() || {};
        this.getuserID = getuserID() || {};
        this.encryption_key = get_encryption_key();

        // 首次调用该信息
        let that = this;
        uni.showLoading({
            title: "获取位置信息中...",
            mask: true,
        });
        // update_login_status/
        uni.request({
            url: `${this._url}seat/update_login_status/`,
            method: "POST",
            success: (res) => {
                var data_str = res.data;
                if (res.statusCode >= 200 && res.statusCode < 300) {
                    uni.showToast({
                        title: "欢迎～",
                        icon: "none",
                        duration: 1700,
                    });
                } else {
                    uni.showToast({
                        title: res.data.message,
                        icon: "none",
                        duration: 1700,
                    });
                }
            },
            fail: (err) => {
                uni.showToast({
                    title: `网络连接失败`,
                    icon: "error",
                    duration: 1700,
                });
            },
        });

        uni.getSetting({
            success(res) {
                // console.log(res)
                // 如果没有授权
                if (!res.authSetting["scope.userLocation"]) {
                    // 则拉起授权窗口
                    uni.authorize({
                        scope: "scope.userLocation",
                        success() {
                            //点击允许后--就一直会进入成功授权的回调 就可以使用获取的方法了
                            uni.getLocation({
                                type: "gcj02",
                                success: function (res) {
                                    that.x = res.longitude;
                                    that.y = res.latitude;
                                    // console.log(res)
                                    // console.log('当前位置的经度：' + res.longitude)
                                    // console.log('当前位置的纬度：' + res.latitude)
                                    that.res = res;

                                    uni.request({
                                        header: {
                                            "Content-Type": "application/text",
                                        },
                                        //注意:这里的key值需要腾讯地图的 web服务生成的key  只有web服务才有逆地理编码
                                        url:
                                            "https://apis.map.qq.com/ws/geocoder/v1/?location=" +
                                            res.latitude +
                                            "," +
                                            res.longitude +
                                            "&key=6KMBZ-YSTCU-5D4VA-BWOAW-BU5GE-62BAX&get_poi=1",
                                        success(re) {
                                            // console.log(re)
                                            if (re.statusCode === 200) {
                                                that.citydata =
                                                    re.data.result.address;
                                                console.log(
                                                    "获取中文街道地理位置成功",
                                                    that.citydata
                                                );
                                            } else {
                                                uni.showToast({
                                                    title: "获取信息失败，请重试！",
                                                    icon: "none",
                                                    duration: 1700,
                                                });
                                                console.log(
                                                    "获取信息失败，请重试！"
                                                );
                                            }
                                        },
                                    });
                                },
                                fail(error) {
                                    console.log("失败", error);
                                },
                            });
                        },
                        fail(error) {
                            //点击了拒绝授权后--就一直会进入失败回调函数--此时就可以在这里重新拉起授权窗口
                            console.log("拒绝授权", error);
                            uni.showModal({
                                title: "提示",
                                content: "若点击不授权，将无法使用位置功能",
                                cancelText: "不授权",
                                cancelColor: "#999",
                                confirmText: "授权",
                                confirmColor: "#f94218",
                                success(res) {
                                    console.log(res);
                                    if (res.confirm) {
                                        // 选择弹框内授权
                                        uni.openSetting({
                                            success(res) {
                                                console.log(res.authSetting);
                                            },
                                        });
                                    } else if (res.cancel) {
                                        uni.showToast({
                                            title: "获取信息失败，请重试！",
                                            icon: "none",
                                            duration: 1700,
                                        });
                                        console.log("用户点击不授权");
                                    }
                                },
                            });
                        },
                    });
                } else {
                    // 有权限则直接获取
                    uni.getLocation({
                        type: "gcj02",
                        success: function (res) {
                            that.x = res.longitude;
                            that.y = res.latitude;
                            // console.log(res)
                            // console.log('当前位置的经度：' + res.longitude)
                            // console.log('当前位置的纬度：' + res.latitude)
                            that.res = res;
                            uni.request({
                                header: {
                                    "Content-Type": "application/text",
                                },
                                //注意:这里的key值需要腾讯地图的 web服务生成的key  只有web服务才有逆地理编码
                                url:
                                    "https://apis.map.qq.com/ws/geocoder/v1/?location=" +
                                    res.latitude +
                                    "," +
                                    res.longitude +
                                    "&key=6KMBZ-YSTCU-5D4VA-BWOAW-BU5GE-62BAX&get_poi=1",
                                success(re) {
                                    console.log(re);
                                    if (re.statusCode === 200) {
                                        that.citydata = re.data.result.address;
                                        console.log(
                                            "获取中文街道地理位置成功",
                                            that.citydata
                                        );
                                    } else {
                                        uni.showToast({
                                            title: "获取信息失败，请重试！",
                                            icon: "none",
                                            duration: 1700,
                                        });
                                        console.log("获取信息失败，请重试！");
                                    }
                                },
                            });
                        },
                    });
                }
                uni.hideLoading();
            },
        });
    },
    methods: {
        // 扫码签到逻辑
        scanCheckIn() {
            // console.log(this.res);
            uni.scanCode({
                success: (res) => {
                    // 扫码成功，获取二维码数据
                    var scanResult = res.result;
                    // console.log('扫码结果:', scanResult);
                    scanResult = this.decryptData(
                        scanResult,
                        this.encryption_key
                    );
                    // 解析二维码数据
                    const decodedData = this.decodeQRCode(scanResult);
                    // console.log(decodedData);
                    if (decodedData && this.validateQRCode(decodedData)) {
                        var seat_number_str = `[${decodedData[0].seat_num[0]},${decodedData[0].seat_num[1]}]`;

                        uni.request({
                            url: `${this._url}seat/sign_in_seat_sys/`,
                            method: "POST",
                            data: {
                                "seat_number": seat_number_str,
                                "student_token": this.token,
                                "student_id": this.getuserID,
                                "point_latitude": this.res.latitude,
                                "point_longitude": this.res.longitude,
                                "class": decodedData[0].room
                                    ? decodedData[0].room
                                    : "105",
                            },
                            success: (res) => {
                                if (
                                    res.statusCode >= 200 &&
                                    res.statusCode < 300
                                ) {
                                    uni.showToast({
                                        title: res.data.message,
                                        icon: "success",
                                        duration: 1700,
                                    });
                                } else {
                                    uni.showToast({
                                        title: res.data.message,
                                        icon: "error",
                                        duration: 1700,
                                    });
                                }
                            },
                            fail: (err) => {
                                uni.showToast({
                                    title: `网络错误`,
                                    icon: "none",
                                    duration: 1700,
                                });
                                console.error("签到失败-网络错误：", err);
                            },
                        });
                        // 可以在这里执行签到相关的逻辑
                    } else {
                        uni.showToast({
                            title: "签到失败请重试",
                            icon: "error",
                            duration: 1700,
                        });
                        console.log("二维码验证失败");
                    }
                },
                fail: (res) => {
                    uni.showToast({
                        title: "扫码失败或取消扫码",
                        icon: "none",
                        duration: 1700,
                    });
                    console.log("扫码失败或取消扫码");
                },
            });
        },
        decryptData(encryptedData, key) {
            const decodedArrayBuffer = wx.base64ToArrayBuffer(encryptedData);
            const decodedData = String.fromCharCode.apply(
                null,
                new Uint8Array(decodedArrayBuffer)
            );

            let decrypted = "";
            for (let i = 0; i < decodedData.length; i++) {
                const charCode =
                    decodedData.charCodeAt(i) ^ key.charCodeAt(i % key.length);
                decrypted += String.fromCharCode(charCode);
            }

            return decrypted;
        },

        // 解析二维码数据
        decodeQRCode(qrCodeData) {
            try {
                return JSON.parse(qrCodeData);
            } catch (error) {
                uni.showToast({
                    title: `解析失败`,
                    icon: "error",
                    duration: 1700,
                });
                console.error("解析二维码数据失败:", error);
                return null;
            }
        },

        // 验证二维码格式
        validateQRCode(decodedData) {
            // console.log(decodedData[0].check_code)
            // 检查 decodedData 是否符合特定格式
            return (
                decodedData &&
                typeof decodedData == "object" &&
                "seat_num" in decodedData[0] &&
                "check_code" in decodedData[0] &&
                decodedData[0].check_code == "Cloudcode_u679c"
            );
        },

        //释放选座
        release_seat() {
            uni.showModal({
                title: "确认释放座位",
                content: "释放座位将使所有未签到的预约违约，请确定",
                success: (res) => {
                    if (res.confirm) {
                        // 用户点击了确认按钮
                        uni.request({
                            url: `${this._url}seat/release_seat/`,
                            method: "POST",
                            data: {
                                "student_token": this.token,
                                "student_id": this.getuserID,
                            },
                            success: (res) => {
                                var data_str = res.data;
                                if (
                                    res.statusCode >= 200 &&
                                    res.statusCode < 300
                                ) {
                                    uni.showToast({
                                        title: "释放完成",
                                        icon: "success",
                                        duration: 1700,
                                    });
                                } else {
                                    uni.showToast({
                                        title: "出问题啦",
                                        icon: "error",
                                        duration: 1700,
                                    });
                                }
                            },
                            fail: (err) => {
                                uni.showToast({
                                    title: `释放失败请重试`,
                                    icon: "error",
                                    duration: 1700,
                                });
                            },
                        });
                    } else if (res.cancel) {
                        // 用户点击了取消按钮
                        uni.showToast({
                            title: `取消`,
                            icon: "error",
                            duration: 1700,
                        });
                    }
                },
            });
        },
        // 座位预约逻辑
        seatReservation105() {
            uni.navigateTo({
                url: "/pages/seat_selection_sys/seat_select",
            });
        },
        seatReservation202() {
            uni.navigateTo({
                url: "/pages/seat_selection_sys/seat_select202",
            });
        },
        activity_lock() {
            uni.navigateTo({
                url: "/pages/seat_selection_sys/activity_lock",
            });
        },
        // 预约记录逻辑
        appointmentRecords() {
            uni.navigateTo({
                url: "/pages/seat_selection_sys/appointment-record",
            });
        },
        // 违约记录逻辑
        violationRecords() {
            uni.navigateTo({
                url: "/pages/seat_selection_sys/self_info",
            });
        },

        lock_seat() {
            uni.navigateTo({
                url: "/pages/seat_selection_sys/lock_seat",
            });
        },
        check_defaul() {
            uni.navigateTo({
                url: "/pages/seat_selection_sys/update_defaulters",
            });
        },
        get_all_records() {
            uni.navigateTo({
                url: "/pages/seat_selection_sys/high_log",
            });
        },
    },
};
</script>
<style>
.saoma_text {
    position: absolute;
    bottom: -9px;
    left: 4vh;
}

.icon_saoma {
    position: absolute;
    top: 4%;
    left: 20%;
}

.admin_button::after {
    content: "GM";
    font-size: 10px;
    position: relative;
    color: #ff0000;
    border: none;
    top: -60px;
    left: 75px;
}
</style>
