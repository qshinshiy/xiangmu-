<template>
	<view class="seat_reservation">
		<view :class="{'select_zhezhao':true, 'hidden':canbe_select}"><br /><br /><br /><br />{{hidden_text}}</view>
		<view class="time_selector">
			<span>查看不同时段选座信息：</span>
			<view :class="{ 'time_option': true, 'selected1': selectedTime === '8:00-12:00' }"
				@click="updateSelectedTime('8:00-12:00')">8:00-12:00</view>
			<view :class="{ 'time_option': true, 'selected1': selectedTime === '13:00-18:00' }"
				@click="updateSelectedTime('13:00-18:00')">13:00-18:00</view>
			<view :class="{ 'time_option': true, 'selected1': selectedTime === '19:00-22:00' }"
				@click="updateSelectedTime('19:00-22:00')">19:00-22:00</view>
		</view>


		<view class="seat_map">
			<view class="seat_incedx">
				<view v-for="row in ['A', 'B', 'C', 'D']" class="seat_incedx_index">
					<text>{{ row }}</text>
				</view>
			</view>
			<view v-for="(row, rowIndex) in seatMap" :key="rowIndex" class="row">
				<view class="coordinate-label">{{ rowIndex + 1 }}</view>
				<view v-for="(seat, seatIndex) in row" :key="seatIndex"
					:class="{ 'seat': true, 'locked':isLocked(rowIndex, seatIndex), 'occupied': isSeatOccupied(rowIndex, seatIndex), 'selected': isSelectedSeat(rowIndex, seatIndex) }"
					@click="reserveSeat(rowIndex, seatIndex)">
				</view>
			</view>
		</view>

		<view class="tp_show">
			<view class="tp_block">
				<view class="seat occupied"></view>
				<span>已被选走</span>
			</view>
			<view class="tp_block ">
				<view class="seat locked"></view>
				<span>已锁位置</span>
			</view>
			<view class="tp_block">
				<view class="seat"></view>
				<span>可选</span>
			</view>
		</view>
		<!-- <button class="reserve_button" @click="submitLock()">保存修改</button> -->
	</view>
</template>
<script>
	import request from '@/utils/request.js';
	import {
		get_url
	} from '@/utils/config_Django.js'
	import {
		getConfig,
		setUserInfo,
		getUserInfo,
		setToken,
		getToken,
		getuserID,
		removeuserID,
		removeUserInfo,
		removeToken
	} from '@/utils/auth';

	export default {
		data() {
			return {
				_uel: {},
				user: {},
				token: {},
				getuserID: {},
				selectedTime: '8:00-12:00',
				seatMap: [...Array(12)].map(() => Array(4).fill(false)),
				selectedSeats: [],
				occupiedSeats: [],
				canbe_select: false,
				hidden_text: "加载中...",
				my_slot_seat: [],
				locked_seat: []
			};
		},

		onLoad: function(data) {
			this._url = get_url() || {};
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			this.getuserID = getuserID() || {};
			this.fetchOccupiedSeats()
		},
		methods: {
			isLocked(row, seat) {
				return this.locked_seat.some(item => {
					const [lockedRow, lockedSeat] = JSON.parse(item.seat_number);
					return row === lockedRow && seat === lockedSeat;
				});
			},
			updateSeatMap() {
				this.seatMap = [...Array(12)].map(() => Array(4).fill(false));

				this.occupiedSeats.forEach(([occupiedRow, occupiedSeat]) => {
					this.$set(this.seatMap[occupiedRow], occupiedSeat, true);
				});

				this.selectedSeats.forEach(([selectedRow, selectedSeat]) => {
					this.$set(this.seatMap[selectedRow], selectedSeat, true);
				});
			},

			fetchOccupiedSeats() {

				uni.request({
					url: `${this._url}seat/get_lock_seat/`,
					method: 'POST',
					data: {
						"time_slot": this.selectedTime,
					},
					success: (res) => {

						this.locked_seat = res.data.locked_seats
						// [
						// 	{"seat_number": "[0,0]"}, 
						// 	{"seat_number": "[3,0]"},
						// ]
					},
					fail: (err) => {
						uni.showToast({
							title: `锁定位置信息获取失败`,
							icon: 'none',
							duration: 1700
						})
						this.hidden_text = "锁定位置信息获取失败"
						this.canbe_select = false
						console.error('锁定位置信息获取失败：', err);
					}
				});
				uni.request({
					url: `${this._url}seat/huoqu_yuyue_xinxi/`,
					method: 'POST',
					data: {
						"time_slot": this.selectedTime,
						"user_type": "admin"
					},
					success: (res) => {
						var data_str = res.data.data;
						var cleanedString = data_str.replace(/\s/g, '');
						var jsonString = '[' + cleanedString + ']';
						this.occupiedSeats = JSON.parse(jsonString);
						this.updateSeatMap();
						this.canbe_select = true;
					},
					fail: (err) => {
						uni.showToast({
							title: `信息更新失败`,
							icon: 'error',
							duration: 1700
						})
						this.hidden_text = "预约信息获取失败"
						this.canbe_select = false
						console.error('预约信息获取失败：', err);
					}
				});

			},
			updateSelectedTime(time) {
				this.selectedTime = time;
				this.selectedSeats = [];
				this.fetchOccupiedSeats()

			},
			isSeatOccupied(row, seat) {
				return this.occupiedSeats.some(([occupiedRow, occupiedSeat]) => occupiedRow === row && occupiedSeat ===
					seat);
			},
			isSelectedSeat(row, seat) {
				return this.selectedSeats.some(([selectedRow, selectedSeat]) => selectedRow === row && selectedSeat ===
					seat);
			},
			reserveSeat(row, seat) {
				const seatIndex = this.locked_seat.findIndex(item => {
					const [lockedRow, lockedSeat] = JSON.parse(item.seat_number);
					return lockedRow === row && lockedSeat === seat;
				});
				var showtitle = '';
				var showsubtitle = '';
				if (seatIndex !== -1) {
					// 如果座位已经在locked_seat中，则取消选择
					this.locked_seat.splice(seatIndex, 1);
					this.$set(this.seatMap[row], seat, false);
					showsubtitle = `取消锁定${['A', 'B', 'C', 'D'][seat]}${row+1}`;
					showtitle = '取消锁定';
				} else {
					// 如果座位不在locked_seat中，则添加到locked_seat
					this.locked_seat.push({
						seat_number: JSON.stringify([row, seat])
					});
					this.$set(this.seatMap[row], seat, true);
					showtitle = `确认锁定${['A', 'B', 'C', 'D'][seat]}${row+1}位置?`;
					showsubtitle = '锁定位置将使三个时间段预约用户的预约失效';
				}
				
				uni.showModal({
					title: showtitle,
					content: showsubtitle,
					success: (res) => {
						if (res.confirm) {
							// 用户点击了确认按钮
							uni.showLoading({
								title: '锁定中...',
								mask: true,
							});
							// console.log(this.locked_seat)
							uni.request({
								url: `${this._url}seat/lock_seat/`,
								method: 'POST',
								data: {
									"lockedSeat": `[${row},${seat}]`,
									"student_token": this.token,
									"student_id": this.getuserID,
								},
								success: (res) => {
									uni.hideLoading()
									if (res.statusCode >= 200 && res.statusCode < 300) {
										if (res.data.success) {
											this.fetchOccupiedSeats()
										} else {
											console.log(res.data.success)
											console.log(res.data.error)
										}
									} else {
										uni.showToast({
											title: "信息同步失败",
											icon: 'none',
											duration: 1000
										})
									}
								},
								fail: (err) => {
									uni.hideLoading()
									uni.showToast({
										title: `网络错误`,
										icon: 'error',
										duration: 1700
									})
									console.error('网络错误：', err);
								}
							});
						} else if (res.cancel) {
							// 用户点击了取消按钮
							uni.showToast({
								title: `未提交`,
								icon: 'none',
								duration: 1700
							})
							this.fetchOccupiedSeats()
						}
					}
				});




			}
		},
	};
</script>

<style>
	.seat_incedx_index {
		width: 30px;
		height: 20px;
		margin: 5px;
		background-color: #e0e0e0;
		border-radius: 5px;
		display: flex;
		align-items: center;
		justify-content: center;

	}

	.seat_incedx {
		display: flex;
		width: 84%;
		flex-direction: row;
		flex-wrap: nowrap;
		align-items: center;
		justify-content: space-between;
		margin-left: 30px;
	}

	.map_block {
		display: flex;
		flex-direction: row;
		align-items: flex-end;
	}

	.tp_show {
		transform: scale(0.7);
		display: flex;
		justify-content: space-between;
		width: 80%;
		margin-bottom: -10px;
	}

	.tp_block {
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	.select_zhezhao {
		position: absolute;
		background-color: #00000050;
		width: 100vh;
		height: 100vh;
		color: #b20a0a;
		justify-content: center;
		align-items: center;
		text-align: center;
	}

	.hidden {
		display: none;
	}

	.selected1 {
		background-color: #86d81b;
		color: #fff;
	}

	.coordinate-label {
		width: 20px;
		height: 30px;
		margin: 5px;
		background-color: #e0e0e0;
		border-radius: 5px;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.zoulang {
		width: 20px;
	}

	.seat_reservation {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		height: 100vh;
	}

	.time_selector {
		margin-bottom: 20px;
	}

	.seat_map {
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	.row {
		display: flex;
		justify-content: center;
	}

	.seat {
		width: 30px;
		height: 30px;
		margin: 5px;
		background-color: #e0e0e0;
		border-radius: 5px;
		cursor: pointer;
	}

	.seat.occupied {
		background-color: #ff6347;
		/* cursor: not-allowed; */
	}

	/* 
	.seat.selected_done {
		background-color: #4eb2f3;
	} */

	.seat.selected {
		background-color: #888a8e;
	}

	.seat.locked {
		background-color: #888a8e;
	}

	.reserve_button {
		background-color: #4CAF50;
		color: white;
		border: none;
		border-radius: 8px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
		margin-top: 20px;
		cursor: pointer;
	}

	.reserve_button:active {
		background-color: #36833c;
	}
</style>