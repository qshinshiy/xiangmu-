<template>
	<div id="personal-info">
		<view>
			<label>姓名：</label>
			<span>{{ name }}</span>
		</view>
		<view>
			<label>学号：</label>
			<span>{{ studentId }}</span>
		</view>
		<view>
			<label>违约次数：</label>
			<span>{{ violationCount }}</span>
			<span>(违约记录将在每晚10点刷新)</span>
		</view>
		<view>
			<label>本周理论累计签到时长：</label>
			<span>{{ weeklySignInDuration }}</span>
		</view>
		<view>
			<label>连续满签到次数：</label>
			<span>{{ consecutiveFullSignInCount }}</span>
		</view>
	</div>
</template>

<script>
	import request from '@/utils/request.js';
	import {
		get_url
	} from '@/utils/config_Django.js'
	import {
		getConfig,
		setUserInfo,
		getUserInfo,
		setToken,
		getToken,
		getuserID,
		removeuserID,
		removeUserInfo,
		removeToken
	} from '@/utils/auth';
	export default {
		data() {
			return {
				_url: {},
				user: {},
				token: {},
				getuserID: {},
				name: "",
				studentId: "",
				violationCount: 0,
				weeklySignInDuration: "0小时",
				consecutiveFullSignInCount: 0,
			};
		},
		onLoad: function(data) {
			this._url = get_url() || {};
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			this.getuserID = getuserID() || {};
		},
		methods: {
			query_info() {
				uni.request({
					url: `${this._url}seat/select_pesinfo/`,
					method: 'POST',
					data: {
						"student_token": this.token,
						"student_id": this.getuserID,
					},
					success: (res) => {
						var data_str = res.data
						if (res.statusCode >= 200 && res.statusCode < 300) {
							this.name = res.data.user_name
							this.studentId = res.data.user_id
							this.violationCount = res.data.defaulter_count
							this.weeklySignInDuration = res.data.weekly_signin_duration + "小时"
							this.consecutiveFullSignInCount = res.data.consecutive_full_signin_count
						} else {
							uni.showToast({
								title: "出问题啦",
								icon: 'error',
								duration: 1700
							})
						}
					},
					fail: (err) => {
						uni.showToast({
							title: `获取失败请刷新`,
							icon: 'error',
							duration: 1700
						})
					}
				});
			}
		},
		mounted() {
			this.query_info();
		}
	};
</script>

<style scoped>
	/* 样式可以根据你的需求进行调整 */
	#personal-info {
		font-family: 'Arial', sans-serif;
		padding: 20px;
		border: 1px solid #ccc;
		border-radius: 5px;
		margin: 20px;
	}

	view {
		margin-bottom: 10px;
	}

	label {
		font-weight: bold;
		margin-right: 10px;
	}
</style>