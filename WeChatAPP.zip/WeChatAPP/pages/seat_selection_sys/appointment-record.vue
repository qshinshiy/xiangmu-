<template>
	<view class="container">
		<view class="main-box">




			<view class="record-list" v-for="(record, index) in records.slice().reverse()" :key="index">

				<view class="record">
					<view class="record-sno">学号：{{ record.reser_sno }}</view>
					<view class="record-date">预约日期：{{ record.reser_date }}</view>
					<view class="record-time">
						时间：

						<span v-if="record.reser_time == 0">08:00~12:00</span>
						<span v-else-if="record.reser_time == 1">13:00~18:00</span>
						<span v-else-if="record.reser_time == 2">19:00~22:00</span>
						<span v-else>未知时间范围</span>
					</view>

					<view class="record-seat">座位编号：{{ record.reser_seat }}</view>
					<view class="record-state">
						状态：
						<span v-if="record.reser_state == 0" style="color: #8a2be2; ">未签到</span>
						<span v-else-if="record.reser_state == 1" style="color: #008000; ">已签到</span>
						<span v-else-if="record.reser_state == 2" style="color: #ff0000; ">违约</span>

						<span v-else-if="record.reser_state == 3" style="color: #fc4f45; ">已取消</span>
						<span v-else-if="record.reser_state == 4" style="color: #fc4f45; ">因特殊情况已被取消，请重新选座</span>

						<span v-else>未知状态(状态码:{{record.reser_state}})</span>
					</view>
					<view class="record-create_date">预约发起日期：{{ record.create_date }}</view>
					<view class="record-sign">签到：{{ record.sign_time }}</view>
					<button v-if="record.reser_state == 0" @click="cancelRes(record.reser_id,record.reser_seat.includes('202'))">取消预约</button>
				</view>

			</view>
		</view>
	</view>


</template>

<script>
	import request from '@/utils/request.js';

	import {
		get_url
	} from '@/utils/config_Django.js'

	import {
		getConfig,
		setUserInfo,
		getUserInfo,
		setToken,
		getToken,
		getuserID,
		removeuserID,
		removeUserInfo,
		removeToken
	} from '@/utils/auth';
	export default {
		data() {
			return {
				_url: {},
				user: {},
				token: {},
				getuserID: {},
				records: [],
			};
		},
		onLoad() {
			this._url = get_url() || {};
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			this.getuserID = getuserID() || {};
			this.fetchRecords();
		},
		methods: {

			cancelRes(id,is_202) {
				uni.request({
					url: `${this._url}seat/cancelRes/`,
					method: 'POST',
					header: {
						'Content-Type': 'application/json',
					},
					data: {
						"student_token": this.token,
						"student_id": this.getuserID,
						"reser_id": id,
						"class":is_202?"202":"105"
					},
					success: (res) => {
						this.fetchRecords()
						uni.showToast({
							title: res.data.message,
							icon: 'none',
							duration: 1700
						})
					},
					fail: (err) => {
						uni.showToast({
							title: `信息更新失败`,
							icon: 'error',
							duration: 1700
						})
						console.error('获取失败请重试', err);
					}
				});
			},
			fetchRecords() {
				uni.request({
					url: `${this._url}seat/get_reservation_records/`,
					method: 'POST',
					header: {
						'Content-Type': 'application/json',
					},
					data: {
						"student_token": this.token,
						"student_id": this.getuserID,

					},
					success: (res) => {
						if (res.statusCode >= 200 && res.statusCode < 300) {
							this.records = res.data
							// console.log(res.data)
						} else {
							uni.showToast({
								title: res.data.message,
								icon: 'error',
								duration: 1700
							})
						}
					},
					fail: (err) => {
						uni.showToast({
							title: `信息更新失败`,
							icon: 'error',
							duration: 1700
						})
						console.error('获取失败请重试', err);
					}
				});
			}
		}
	};
</script>

<style>
	/* 样式重置，确保样式的一致性 */
	* {
		margin: 0;
		padding: 0;
		box-sizing: border-box;
	}

	/* 记录列表容器样式 */
	.record-list {
		list-style: none;
	}

	/* 单个记录样式 */
	.record {
		border: 1px solid #ccc;
		padding: 10px;
		margin-bottom: 10px;
	}

	/* 学号样式 */
	.record-sno {
		font-weight: bold;
		margin-bottom: 5px;
	}

	/* 预约日期样式 */
	.record-date {
		color: #007bff;
		margin-bottom: 5px;
	}

	/* 预约时间样式 */
	.record-time {
		margin-bottom: 5px;
	}

	/* 座位编号样式 */
	.record-seat {
		margin-bottom: 5px;
	}

	/* 状态样式 */
	.record-state {
		color: #2e2262;
		margin-bottom: 5px;
	}

	/* 发起日期样式 */
	.record-create_date {
		font-style: italic;
		/* 斜体字体 */
		margin-bottom: 5px;
	}

	/* 签到样式 */
	.record-sign {
		margin-bottom: 5px;
	}
</style>