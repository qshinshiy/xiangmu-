<!-- 
@author : Yingming
@date : 2023
@description : 测试界面
-->
<!-- <template>
	<view>本页面仅用于测试数据</view>
</template>

<script>
	import {
		getConfig,
		setUserInfo,
		getUserInfo,
		setToken,
		getToken,
		removeUserInfo,
		removeToken
	} from '@/utils/auth';
	export default {
		data() {
			return {
				
			};
		},
		onShow(options) {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
			this.showuser();
		},
		methods: {
			showuser(){
				var that = this;
				let datas = {
					userid: 19310220121,
					course: null,
					password: null,
					realname: null,
					school: null,
					uuid: null
				}
				that.request("oj/reset", datas, 'POST').then(res => {
					console.log(res);
				});
			},
		}
	};
</script>

<style scoped>
</style> -->


 <template>
 	<view>
 		<o-grid col="10" gutter radius title="图标预览">
 			<o-grid-item icon="icon-play-fill" text="icon-play-fill" />
 			<o-grid-item icon="icon-arrow-down" text="icon-arrow-down" />
 			<o-grid-item icon="icon-prompt-fill" text="icon-prompt-fill" />
 			<o-grid-item icon="icon-account" text="icon-account" />
 			<o-grid-item icon="icon-stop-fill" text="icon-stop-fill" />
 			<o-grid-item icon="icon-comments" text="icon-comments" />
 			<o-grid-item icon="icon-column" text="icon-column" />
 			<o-grid-item icon="icon-order" text="icon-order" />
 			<o-grid-item icon="icon-add-account" text="icon-add-account" />
 			<o-grid-item icon="icon-search" text="icon-search" />
 			<o-grid-item icon="icon-column1" text="icon-column1" />
 			<o-grid-item icon="icon-tradingdata" text="icon-tradingdata" />
 			<o-grid-item icon="icon-add" text="icon-add" />
 			<o-grid-item icon="icon-txt" text="icon-txt" />
 			<o-grid-item icon="icon-add-cart" text="icon-add-cart" />
 			<o-grid-item icon="icon-banzhengfuwu" text="icon-banzhengfuwu" />
 			<o-grid-item icon="icon-arrow-right" text="icon-arrow-right" />
 			<o-grid-item icon="icon-daibancaishui" text="icon-daibancaishui" />
 			<o-grid-item icon="icon-arrow-left" text="icon-arrow-left" />
 			<o-grid-item icon="icon-jiaobiao" text="icon-jiaobiao" />
 			<o-grid-item icon="icon-apparel" text="icon-apparel" />
 			<o-grid-item icon="icon-kehupandian" text="icon-kehupandian" />
 			<o-grid-item icon="icon-arrow-up" text="icon-arrow-up" />
 			<o-grid-item icon="icon-dongtai" text="icon-dongtai" />
 			<o-grid-item icon="icon-ascending" text="icon-ascending" />
 			<o-grid-item icon="icon-daikuan" text="icon-daikuan" />
 			<o-grid-item icon="icon-ashbin" text="icon-ashbin" />
 			<o-grid-item icon="icon-shengyijing" text="icon-shengyijing" />
 			<o-grid-item icon="icon-bad" text="icon-bad" />
 			<o-grid-item icon="icon-shenqingjilu" text="icon-shenqingjilu" />
 			<o-grid-item icon="icon-attachent" text="icon-attachent" />
 			<o-grid-item icon="icon-shangchuanbeiandanzheng" text="icon-shangchuanbeiandanzheng" />
 			<o-grid-item icon="icon-browse" text="icon-browse" />
 			<o-grid-item icon="icon-shangchuan" text="icon-shangchuan" />
 			<o-grid-item icon="icon-assessed-badge" text="icon-assessed-badge" />
 			<o-grid-item icon="icon-suoxiao" text="icon-suoxiao" />
 			<o-grid-item icon="icon-bags" text="icon-bags" />
 			<o-grid-item icon="icon-quanyipeizhi" text="icon-quanyipeizhi" />
 			<o-grid-item icon="icon-calendar" text="icon-calendar" />
 			<o-grid-item icon="icon-tuishui" text="icon-tuishui" />
 			<o-grid-item icon="icon-calculator" text="icon-calculator" />
 			<o-grid-item icon="icon-tongguanshuju" text="icon-tongguanshuju" />
 			<o-grid-item icon="icon-cecurity-protection" text="icon-cecurity-protection" />
 			<o-grid-item icon="icon-wuliudingdan" text="icon-wuliudingdan" />
 			<o-grid-item icon="icon-category" text="icon-category" />
 			<o-grid-item icon="icon-zhuanyequanwei" text="icon-zhuanyequanwei" />
 			<o-grid-item icon="icon-close" text="icon-close" />
 			<o-grid-item icon="icon-tuishuirongzi" text="icon-tuishuirongzi" />
 			<o-grid-item icon="icon-certified-supplier" text="icon-certified-supplier" />
 			<o-grid-item icon="icon-AddProducts" text="icon-AddProducts" />
 			<o-grid-item icon="icon-cart-Empty" text="icon-cart-Empty" />
 			<o-grid-item icon="icon-addcell" text="icon-addcell" />
 			<o-grid-item icon="icon-color" text="icon-color" />
 			<o-grid-item icon="icon-background-color" text="icon-background-color" />
 			<o-grid-item icon="icon-conditions" text="icon-conditions" />
 			<o-grid-item icon="icon-beijing" text="icon-beijing" />
 			<o-grid-item icon="icon-confirm" text="icon-confirm" />
 			<o-grid-item icon="icon-bold" text="icon-bold" />
 			<o-grid-item icon="icon-company" text="icon-company" />
 			<o-grid-item icon="icon-zijin" text="icon-zijin" />
 			<o-grid-item icon="icon-ali-clould" text="icon-ali-clould" />
 			<o-grid-item icon="icon-eraser" text="icon-eraser" />
 			<o-grid-item icon="icon-credit-level" text="icon-credit-level" />
 			<o-grid-item icon="icon-centeralignment" text="icon-centeralignment" />
 			<o-grid-item icon="icon-coupons" text="icon-coupons" />
 			<o-grid-item icon="icon-click" text="icon-click" />
 			<o-grid-item icon="icon-connections" text="icon-connections" />
 			<o-grid-item icon="icon-flag" text="icon-flag" />
 			<o-grid-item icon="icon-cry" text="icon-cry" />
 			<o-grid-item icon="icon-falg-fill" text="icon-falg-fill" />
 			<o-grid-item icon="icon-clock" text="icon-clock" />
 			<o-grid-item icon="icon-Foreigncurrency" text="icon-Foreigncurrency" />
 			<o-grid-item icon="icon-CurrencyConverter" text="icon-CurrencyConverter" />
 			<o-grid-item icon="icon-guanliyuan" text="icon-guanliyuan" />
 			<o-grid-item icon="icon-cut" text="icon-cut" />
 			<o-grid-item icon="icon-leftalignment" text="icon-leftalignment" />
 			<o-grid-item icon="icon-Customermanagement" text="icon-Customermanagement" />
 			<o-grid-item icon="icon-Italic" text="icon-Italic" />
 			<o-grid-item icon="icon-descending" text="icon-descending" />
 			<o-grid-item icon="icon-pcm" text="icon-pcm" />
 			<o-grid-item icon="icon-double-arro-right" text="icon-double-arro-right" />
 			<o-grid-item icon="icon-reducecell" text="icon-reducecell" />
 			<o-grid-item icon="icon-customization" text="icon-customization" />
 			<o-grid-item icon="icon-rightalignment" text="icon-rightalignment" />
 			<o-grid-item icon="icon-double-arrow-left" text="icon-double-arrow-left" />
 			<o-grid-item icon="icon-subscript" text="icon-subscript" />
 			<o-grid-item icon="icon-discount" text="icon-discount" />
 			<o-grid-item icon="icon-square" text="icon-square" />
 			<o-grid-item icon="icon-download" text="icon-download" />
 			<o-grid-item icon="icon-superscript" text="icon-superscript" />
 			<o-grid-item icon="icon-default-template" text="icon-default-template" />
 			<o-grid-item icon="icon-under-line" text="icon-under-line" />
 			<o-grid-item icon="icon-eletrical" text="icon-eletrical" />
 			<o-grid-item icon="icon-xiakuangxian" text="icon-xiakuangxian" />
 			<o-grid-item icon="icon-electronics" text="icon-electronics" />
 			<o-grid-item icon="icon-shouqi" text="icon-shouqi" />
 			<o-grid-item icon="icon-etrical-equipm" text="icon-etrical-equipm" />
 			<o-grid-item icon="icon-zhankai" text="icon-zhankai" />
 			<o-grid-item icon="icon-ellipsis" text="icon-ellipsis" />
 			<o-grid-item icon="icon-tongxunlu" text="icon-tongxunlu" />
 			<o-grid-item icon="icon-email" text="icon-email" />
 			<o-grid-item icon="icon-yiguanzhugongyingshang" text="icon-yiguanzhugongyingshang" />
 			<o-grid-item icon="icon-falling" text="icon-falling" />
 			<o-grid-item icon="icon-becomeagoldsupplier" text="icon-becomeagoldsupplier" />
 			<o-grid-item icon="icon-earth" text="icon-earth" />
 			<o-grid-item icon="icon-robot" text="icon-robot" />
 			<o-grid-item icon="icon-filter" text="icon-filter" />
 			<o-grid-item icon="icon-inspection1" text="icon-inspection1" />
 			<o-grid-item icon="icon-folder" text="icon-folder" />
 			<o-grid-item icon="icon-block" text="icon-block" />
 			<o-grid-item icon="icon-feeds" text="icon-feeds" />
 			<o-grid-item icon="icon-shouhuoicon" text="icon-shouhuoicon" />
 			<o-grid-item icon="icon-hardware" text="icon-hardware" />
 			<o-grid-item icon="icon-help" text="icon-help" />
 			<o-grid-item icon="icon-good" text="icon-good" />
 			<o-grid-item icon="icon-gift1" text="icon-gift1" />
 			<o-grid-item icon="icon-form" text="icon-form" />
 			<o-grid-item icon="icon-image-text" text="icon-image-text" />
 			<o-grid-item icon="icon-hot" text="icon-hot" />
 			<o-grid-item icon="icon-inspection" text="icon-inspection" />
 			<o-grid-item icon="icon-leftbutton" text="icon-leftbutton" />
 			<o-grid-item icon="icon-leftarrow" text="icon-leftarrow" />
 			<o-grid-item icon="icon-inquiry-template" text="icon-inquiry-template" />
 			<o-grid-item icon="icon-link" text="icon-link" />
 			<o-grid-item icon="icon-loading" text="icon-loading" />
 			<o-grid-item icon="icon-lights" text="icon-lights" />
 			<o-grid-item icon="icon-mobile-phone" text="icon-mobile-phone" />
 			<o-grid-item icon="icon-manage-order" text="icon-manage-order" />
 			<o-grid-item icon="icon-move" text="icon-move" />
 			<o-grid-item icon="icon-namecard" text="icon-namecard" />
 			<o-grid-item icon="icon-map" text="icon-map" />
 			<o-grid-item icon="icon-Newuserzone" text="icon-Newuserzone" />
 			<o-grid-item icon="icon-multi-language" text="icon-multi-language" />
 			<o-grid-item icon="icon-notice" text="icon-notice" />
 			<o-grid-item icon="icon-office-supplies" text="icon-office-supplies" />
 			<o-grid-item icon="icon-password" text="icon-password" />
 			<o-grid-item icon="icon-operation" text="icon-operation" />
 			<o-grid-item icon="icon-packaging" text="icon-packaging" />
 			<o-grid-item icon="icon-online-tracking" text="icon-online-tracking" />
 			<o-grid-item icon="icon-packing-labeling" text="icon-packing-labeling" />
 			<o-grid-item icon="icon-print" text="icon-print" />
 			<o-grid-item icon="icon-product" text="icon-product" />
 			<o-grid-item icon="icon-process" text="icon-process" />
 			<o-grid-item icon="icon-prompt" text="icon-prompt" />
 			<o-grid-item icon="icon-reeor" text="icon-reeor" />
 			<o-grid-item icon="icon-reduce" text="icon-reduce" />
 			<o-grid-item icon="icon-rejected-order" text="icon-rejected-order" />
 			<o-grid-item icon="icon-resonserate" text="icon-resonserate" />
 			<o-grid-item icon="icon-remind" text="icon-remind" />
 			<o-grid-item icon="icon-responsetime" text="icon-responsetime" />
 			<o-grid-item icon="icon-return" text="icon-return" />
 			<o-grid-item icon="icon-paylater" text="icon-paylater" />
 			<o-grid-item icon="icon-rising1" text="icon-rising1" />
 			<o-grid-item icon="icon-Rightarrow" text="icon-Rightarrow" />
 			<o-grid-item icon="icon-save" text="icon-save" />
 			<o-grid-item icon="icon-scanning" text="icon-scanning" />
 			<o-grid-item icon="icon-security" text="icon-security" />
 			<o-grid-item icon="icon-searchcart" text="icon-searchcart" />
 			<o-grid-item icon="icon-service" text="icon-service" />
 			<o-grid-item icon="icon-share" text="icon-share" />
 			<o-grid-item icon="icon-signboard" text="icon-signboard" />
 			<o-grid-item icon="icon-Rightbutton" text="icon-Rightbutton" />
 			<o-grid-item icon="icon-sorting" text="icon-sorting" />
 			<o-grid-item icon="icon-sound-Mute" text="icon-sound-Mute" />
 			<o-grid-item icon="icon-sound-filling" text="icon-sound-filling" />
 			<o-grid-item icon="icon-suggest" text="icon-suggest" />
 			<o-grid-item icon="icon-stop" text="icon-stop" />
 			<o-grid-item icon="icon-success" text="icon-success" />
 			<o-grid-item icon="icon-supplier-features" text="icon-supplier-features" />
 			<o-grid-item icon="icon-switch" text="icon-switch" />
 			<o-grid-item icon="icon-template" text="icon-template" />
 			<o-grid-item icon="icon-text" text="icon-text" />
 			<o-grid-item icon="icon-suspended" text="icon-suspended" />
 			<o-grid-item icon="icon-task-management" text="icon-task-management" />
 			<o-grid-item icon="icon-tool" text="icon-tool" />
 			<o-grid-item icon="icon-Top" text="icon-Top" />
 			<o-grid-item icon="icon-smile" text="icon-smile" />
 			<o-grid-item icon="icon-tradealert" text="icon-tradealert" />
 			<o-grid-item icon="icon-topsales" text="icon-topsales" />
 			<o-grid-item icon="icon-tradingvolume" text="icon-tradingvolume" />
 			<o-grid-item icon="icon-upload" text="icon-upload" />
 			<o-grid-item icon="icon-viewgallery" text="icon-viewgallery" />
 			<o-grid-item icon="icon-trust" text="icon-trust" />
 			<o-grid-item icon="icon-warning" text="icon-warning" />
 			<o-grid-item icon="icon-video" text="icon-video" />
 			<o-grid-item icon="icon-viewlist" text="icon-viewlist" />
 			<o-grid-item icon="icon-set" text="icon-set" />
 			<o-grid-item icon="icon-store" text="icon-store" />
 			<o-grid-item icon="icon-tool-hardware" text="icon-tool-hardware" />
 			<o-grid-item icon="icon-sport" text="icon-sport" />
 			<o-grid-item icon="icon-creditcard" text="icon-creditcard" />
 			<o-grid-item icon="icon-contacts" text="icon-contacts" />
 			<o-grid-item icon="icon-aviation" text="icon-aviation" />
 			<o-grid-item icon="icon-Daytimemode" text="icon-Daytimemode" />
 			<o-grid-item icon="icon-discounts" text="icon-discounts" />
 			<o-grid-item icon="icon-invoice" text="icon-invoice" />
 			<o-grid-item icon="icon-insurance" text="icon-insurance" />
 			<o-grid-item icon="icon-nightmode" text="icon-nightmode" />
 			<o-grid-item icon="icon-usercenter" text="icon-usercenter" />
 			<o-grid-item icon="icon-unlock" text="icon-unlock" />
 			<o-grid-item icon="icon-vip" text="icon-vip" />
 			<o-grid-item icon="icon-wallet" text="icon-wallet" />
 			<o-grid-item icon="icon-landtransportation" text="icon-landtransportation" />
 			<o-grid-item icon="icon-exchangerate" text="icon-exchangerate" />
 			<o-grid-item icon="icon-contacts-fill" text="icon-contacts-fill" />
 			<o-grid-item icon="icon-add-account1" text="icon-add-account1" />
 			<o-grid-item icon="icon-add-cart-fill" text="icon-add-cart-fill" />
 			<o-grid-item icon="icon-add-fill" text="icon-add-fill" />
 			<o-grid-item icon="icon-all-fill1" text="icon-all-fill1" />
 			<o-grid-item icon="icon-ashbin-fill" text="icon-ashbin-fill" />
 			<o-grid-item icon="icon-calendar-fill" text="icon-calendar-fill" />
 			<o-grid-item icon="icon-bad-fill" text="icon-bad-fill" />
 			<o-grid-item icon="icon-bussiness-man-fill" text="icon-bussiness-man-fill" />
 			<o-grid-item icon="icon-cart-Empty-fill" text="icon-cart-Empty-fill" />
 			<o-grid-item icon="icon-certified-supplier-fill" text="icon-certified-supplier-fill" />
 			<o-grid-item icon="icon-calculator-fill" text="icon-calculator-fill" />
 			<o-grid-item icon="icon-clock-fill" text="icon-clock-fill" />
 			<o-grid-item icon="icon-ali-clould-fill" text="icon-ali-clould-fill" />
 			<o-grid-item icon="icon-color-fill" text="icon-color-fill" />
 			<o-grid-item icon="icon-coupons-fill" text="icon-coupons-fill" />
 			<o-grid-item icon="icon-cecurity-protection-fill" text="icon-cecurity-protection-fill" />
 			<o-grid-item icon="icon-credit-level-fill" text="icon-credit-level-fill" />
 			<o-grid-item icon="icon-default-template-fill" text="icon-default-template-fill" />
 			<o-grid-item icon="icon-CurrencyConverter-fill" text="icon-CurrencyConverter-fill" />
 			<o-grid-item icon="icon-Customermanagement-fill" text="icon-Customermanagement-fill" />
 			<o-grid-item icon="icon-discounts-fill" text="icon-discounts-fill" />
 			<o-grid-item icon="icon-Daytimemode-fill" text="icon-Daytimemode-fill" />
 			<o-grid-item icon="icon-cry-fill" text="icon-cry-fill" />
 			<o-grid-item icon="icon-email-fill" text="icon-email-fill" />
 			<o-grid-item icon="icon-filter-fill" text="icon-filter-fill" />
 			<o-grid-item icon="icon-folder-fill" text="icon-folder-fill" />
 			<o-grid-item icon="icon-feeds-fill" text="icon-feeds-fill" />
 			<o-grid-item icon="icon-form-fill" text="icon-form-fill" />
 			<o-grid-item icon="icon-camera-fill" text="icon-camera-fill" />
 			<o-grid-item icon="icon-good-fill" text="icon-good-fill" />
 			<o-grid-item icon="icon-image-text-fill" text="icon-image-text-fill" />
 			<o-grid-item icon="icon-inspection-fill" text="icon-inspection-fill" />
 			<o-grid-item icon="icon-hot-fill" text="icon-hot-fill" />
 			<o-grid-item icon="icon-company-fill" text="icon-company-fill" />
 			<o-grid-item icon="icon-discount-fill" text="icon-discount-fill" />
 			<o-grid-item icon="icon-insurance-fill" text="icon-insurance-fill" />
 			<o-grid-item icon="icon-inquiry-template-fill" text="icon-inquiry-template-fill" />
 			<o-grid-item icon="icon-help1" text="icon-help1" />
 			<o-grid-item icon="icon-manage-order-fill" text="icon-manage-order-fill" />
 			<o-grid-item icon="icon-multi-language-fill" text="icon-multi-language-fill" />
 			<o-grid-item icon="icon-Newuserzone-fill" text="icon-Newuserzone-fill" />
 			<o-grid-item icon="icon-nightmode-fill" text="icon-nightmode-fill" />
 			<o-grid-item icon="icon-office-supplies-fill" text="icon-office-supplies-fill" />
 			<o-grid-item icon="icon-notice-fill" text="icon-notice-fill" />
 			<o-grid-item icon="icon-order-fill" text="icon-order-fill" />
 			<o-grid-item icon="icon-password1" text="icon-password1" />
 			<o-grid-item icon="icon-map1" text="icon-map1" />
 			<o-grid-item icon="icon-paylater-fill" text="icon-paylater-fill" />
 			<o-grid-item icon="icon-online-tracking-fill" text="icon-online-tracking-fill" />
 			<o-grid-item icon="icon-pdf-fill" text="icon-pdf-fill" />
 			<o-grid-item icon="icon-phone" text="icon-phone" />
 			<o-grid-item icon="icon-pin-fill" text="icon-pin-fill" />
 			<o-grid-item icon="icon-product-fill" text="icon-product-fill" />
 			<o-grid-item icon="icon-rankinglist-fill" text="icon-rankinglist-fill" />
 			<o-grid-item icon="icon-reduce-fill" text="icon-reduce-fill" />
 			<o-grid-item icon="icon-reeor-fill" text="icon-reeor-fill" />
 			<o-grid-item icon="icon-rankinglist" text="icon-rankinglist" />
 			<o-grid-item icon="icon-product1" text="icon-product1" />
 			<o-grid-item icon="icon-remind-fill" text="icon-remind-fill" />
 			<o-grid-item icon="icon-Rightbutton-fill" text="icon-Rightbutton-fill" />
 			<o-grid-item icon="icon-searchcart-fill" text="icon-searchcart-fill" />
 			<o-grid-item icon="icon-security-fill" text="icon-security-fill" />
 			<o-grid-item icon="icon-signboard-fill" text="icon-signboard-fill" />
 			<o-grid-item icon="icon-service-fill" text="icon-service-fill" />
 			<o-grid-item icon="icon-supplier-features-fill" text="icon-supplier-features-fill" />
 			<o-grid-item icon="icon-store-fill" text="icon-store-fill" />
 			<o-grid-item icon="icon-smile-fill" text="icon-smile-fill" />
 			<o-grid-item icon="icon-success-fill" text="icon-success-fill" />
 			<o-grid-item icon="icon-sound-filling-fill" text="icon-sound-filling-fill" />
 			<o-grid-item icon="icon-sound-Mute1" text="icon-sound-Mute1" />
 			<o-grid-item icon="icon-suspended-fill" text="icon-suspended-fill" />
 			<o-grid-item icon="icon-tool-fill" text="icon-tool-fill" />
 			<o-grid-item icon="icon-unlock-fill" text="icon-unlock-fill" />
 			<o-grid-item icon="icon-trust-fill" text="icon-trust-fill" />
 			<o-grid-item icon="icon-vip-fill" text="icon-vip-fill" />
 			<o-grid-item icon="icon-set1" text="icon-set1" />
 			<o-grid-item icon="icon-voice-fill" text="icon-voice-fill" />
 			<o-grid-item icon="icon-warning-fill" text="icon-warning-fill" />
 			<o-grid-item icon="icon-zip-fill" text="icon-zip-fill" />
 			<o-grid-item icon="icon-video1" text="icon-video1" />
 			<o-grid-item icon="icon-template-fill" text="icon-template-fill" />
 			<o-grid-item icon="icon-all" text="icon-all" />
 			<o-grid-item icon="icon-wallet1" text="icon-wallet1" />
 			<o-grid-item icon="icon-bussiness-man" text="icon-bussiness-man" />
 			<o-grid-item icon="icon-packing-labeling-fill" text="icon-packing-labeling-fill" />
 			<o-grid-item icon="icon-component" text="icon-component" />
 			<o-grid-item icon="icon-brand-fill" text="icon-brand-fill" />
 			<o-grid-item icon="icon-code" text="icon-code" />
 			<o-grid-item icon="icon-collection" text="icon-collection" />
 			<o-grid-item icon="icon-copy" text="icon-copy" />
 			<o-grid-item icon="icon-consumption-fill" text="icon-consumption-fill" />
 			<o-grid-item icon="icon-dollar" text="icon-dollar" />
 			<o-grid-item icon="icon-collection-fill" text="icon-collection-fill" />
 			<o-grid-item icon="icon-history" text="icon-history" />
 			<o-grid-item icon="icon-brand" text="icon-brand" />
 			<o-grid-item icon="icon-editor" text="icon-editor" />
 			<o-grid-item icon="icon-rejected-order-fill" text="icon-rejected-order-fill" />
 			<o-grid-item icon="icon-data" text="icon-data" />
 			<o-grid-item icon="icon-scenes-fill" text="icon-scenes-fill" />
 			<o-grid-item icon="icon-gift" text="icon-gift" />
 			<o-grid-item icon="icon-scenes" text="icon-scenes" />
 			<o-grid-item icon="icon-integral" text="icon-integral" />
 			<o-grid-item icon="icon-topraning-fill" text="icon-topraning-fill" />
 			<o-grid-item icon="icon-nav-list" text="icon-nav-list" />
 			<o-grid-item icon="icon-consumption" text="icon-consumption" />
 			<o-grid-item icon="icon-pic" text="icon-pic" />
 			<o-grid-item icon="icon-topraning" text="icon-topraning" />
 			<o-grid-item icon="icon-Notvisible" text="icon-Notvisible" />
 			<o-grid-item icon="icon-quick" text="icon-quick" />
 			<o-grid-item icon="icon-play" text="icon-play" />
 			<o-grid-item icon="icon-docjpge-fill" text="icon-docjpge-fill" />
 			<o-grid-item icon="icon-rising" text="icon-rising" />
 			<o-grid-item icon="icon-jpge-fill" text="icon-jpge-fill" />
 			<o-grid-item icon="icon-QRcode" text="icon-QRcode" />
 			<o-grid-item icon="icon-gifjpge-fill" text="icon-gifjpge-fill" />
 			<o-grid-item icon="icon-rmb" text="icon-rmb" />
 			<o-grid-item icon="icon-pngjpge-fill" text="icon-pngjpge-fill" />
 			<o-grid-item icon="icon-similar-product" text="icon-similar-product" />
 			<o-grid-item icon="icon-home" text="icon-home" />
 			<o-grid-item icon="icon-Exportservices" text="icon-Exportservices" />
 			<o-grid-item icon="icon-sendinquiry-fill" text="icon-sendinquiry-fill" />
 			<o-grid-item icon="icon-sendinquiry" text="icon-sendinquiry" />
 			<o-grid-item icon="icon-comments-fill" text="icon-comments-fill" />
 			<o-grid-item icon="icon-all-fill" text="icon-all-fill" />
 			<o-grid-item icon="icon-account-fill" text="icon-account-fill" />
 			<o-grid-item icon="icon-favorites-fill" text="icon-favorites-fill" />
 			<o-grid-item icon="icon-home-fill" text="icon-home-fill" />
 			<o-grid-item icon="icon-integral-fill" text="icon-integral-fill" />
 			<o-grid-item icon="icon-add-select" text="icon-add-select" />
 			<o-grid-item icon="icon-namecard-fill" text="icon-namecard-fill" />
 			<o-grid-item icon="icon-sami-select" text="icon-sami-select" />
 			<o-grid-item icon="icon-pic-fill" text="icon-pic-fill" />
 			<o-grid-item icon="icon-camera" text="icon-camera" />
 		</o-grid>
 	</view>
 </template>
 
 <script>
 	export default {
 		data() {
 			return {
 				
 			};
 		}
 	}
 </script>
 
 <style lang="scss">
 
 </style>
