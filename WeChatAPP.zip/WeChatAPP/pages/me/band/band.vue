<!-- 
@author : Yingming
@date : 2023
@description : 绑定账户
-->
<template>
    <view style="height: 100vh; background: #fff">
        <view class="img-a">
            <view class="t-b">
                网工云萌
                <br />
                首次使用需绑定信息
                <br />
                仅限网络工程系仅限绑定
            </view>
        </view>
        <view class="login-view" style="">
            <view class="t-login">
                <form class="cl">
                    <view class="t-a">
                        <text class="txt">账号</text>
                        <input
                            type="number"
                            name="userid"
                            placeholder="请输入您的账号"
                            maxlength="11"
                            v-model="userid"
                        />
                    </view>
                    <view class="t-a">
                        <text class="txt">账号校验码</text>
                        <input
                            type="number"
                            name="phone"
                            placeholder="请输入您的账号校验码"
                            maxlength="11"
                            v-model="phone"
                        />
                    </view>
                    <button @tap="login()">绑 定</button>
                </form>
                <view class="t-f"
                    ><text>——————网工云萌工作室 ——————</text></view
                >
            </view>
        </view>
    </view>
</template>
<script>
import {
    getConfig,
    setUserInfo,
    getUserInfo,
    setToken,
    getToken,
    removeUserInfo,
    removeToken,
    setuserID,
} from "@/utils/auth";
export default {
    data() {
        return {
            userid: "", //手机号码
            phone: "", //密码
        };
    },
    methods: {
        //当前登录按钮操作
        login() {
            var that = this;
            if (!that.userid) {
                uni.showToast({
                    title: "请输入您的学号",
                    icon: "none",
                });
                return;
            }
            if (!that.phone) {
                uni.showToast({
                    title: "请输入您的验证号",
                    icon: "none",
                });
                return;
            }
            if (that.userid != that.phone && that.userid != null) {
                uni.showToast({
                    title: "请输入正确的验证号",
                    icon: "none",
                });
                return;
            }
            uni.showToast({
                title: "正在进行绑定",
                icon: "none",
            });
            uni.login({
                success: function (loginRes) {
                    let form = {};
                    form.code = loginRes.code; //用户code  注:用户的code每次登录都是随机的，所以不需要进行存储
                    let data = {
                        "userId": that.userid,
                        "phoneNum": that.phone,
                        "object": loginRes.code,
                    };
                    let wxdatas = {};
                    that.request("loginwx", data, "POST").then((wxdata) => {
                        wxdatas = JSON.stringify(wxdata.data);
                        if (wxdata.code == 200) {
                            setToken(wxdata.data.token);
                            setuserID(wxdata.data.userid);
                            setUserInfo(wxdata.data); //模拟存储用户信息
                            if (
                                wxdata.data.userid == wxdata.data.phonenumber &&
                                wxdata.data.userid != null
                            ) {
                                uni.redirectTo({
                                    url: "/pages/me/band/rephone",
                                });
                            } else {
                                uni.switchTab({
                                    url: "/pages/me/me?data=" + wxdatas,
                                });
                            }
                        }
                        if (wxdata.code == 500) {
                            uni.showToast({
                                icon: "none",
                                title: "您不是白名单用户！",
                                duration: 2000,
                            });
                        }
                        if (wxdata.code == 701) {
                            uni.showToast({
                                icon: "none",
                                title: "该账号已有绑定账户，请联系辅导员核实",
                                duration: 4000,
                            });
                        }
                        if (
                            wxdata.code !== 500 &&
                            wxdata.code !== 200 &&
                            wxdata.code !== 701
                        ) {
                            uni.showToast({
                                icon: "none",
                                title: "出错啦，再试一次，或联系管理员",
                                duration: 2000,
                            });
                        }
                    });
                },
                fail(err) {
                    console.log(err);
                },
            });
        },
    },
};
</script>
<style>
.txt {
    font-size: 32rpx;
    font-weight: bold;
    color: #333333;
}

.img-a {
    width: 100%;
    height: 450rpx;
    background-image: url(https://base.cloudcode.team/newbg/CloudCode1-2.png);
    background-size: 100%;
}

.reg {
    font-size: 28rpx;
    color: #fff;
    height: 90rpx;
    line-height: 90rpx;
    border-radius: 50rpx;
    font-weight: bold;
    background: #f5f6fa;
    color: #000000;
    text-align: center;
    margin-top: 30rpx;
}

.login-view {
    width: 100%;
    position: relative;
    margin-top: -120rpx;
    background-color: #ffffff;
    border-radius: 8% 8% 0% 0;
}

.t-login {
    width: 600rpx;
    margin: 0 auto;
    font-size: 28rpx;
    padding-top: 80rpx;
}

.t-login button {
    font-size: 28rpx;
    background: #2796f2;
    color: #fff;
    height: 90rpx;
    line-height: 90rpx;
    border-radius: 50rpx;
    font-weight: bold;
}

.t-login input {
    height: 90rpx;
    line-height: 90rpx;
    margin-bottom: 50rpx;
    border-bottom: 1px solid #e9e9e9;
    font-size: 28rpx;
}

.t-login .t-a {
    position: relative;
}

.t-b {
    text-align: left;
    font-size: 45rpx;
    color: #ffffff;
    padding: 130rpx 0 0 70rpx;
    font-weight: bold;
    line-height: 64rpx;
}

.t-login .t-c {
    position: absolute;
    right: 22rpx;
    top: 22rpx;
    background: #5677fc;
    color: #fff;
    font-size: 24rpx;
    border-radius: 50rpx;
    height: 50rpx;
    line-height: 50rpx;
    padding: 0 25rpx;
}

.t-login .t-d {
    text-align: center;
    color: #999;
    margin: 80rpx 0;
}

.t-login .t-e {
    text-align: center;
    width: 250rpx;
    margin: 80rpx auto 0;
}

.t-login .t-g {
    float: left;
    width: 50%;
}

.t-login .t-e image {
    width: 50rpx;
    height: 50rpx;
}

.t-login .t-f {
    text-align: center;
    margin: 150rpx 0 0 0;
    color: #666;
}

.t-login .t-f text {
    margin-left: 20rpx;
    color: #aaaaaa;
    font-size: 27rpx;
}

.t-login .uni-input-placeholder {
    color: #aeaeae;
}

.cl {
    zoom: 1;
}

.cl:after {
    clear: both;
    display: block;
    visibility: hidden;
    height: 0;
    content: "\20";
}
</style>
