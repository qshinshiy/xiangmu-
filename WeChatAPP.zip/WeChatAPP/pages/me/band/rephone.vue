<!-- 
@author : Yingming
@date : 2023
@description : 重置手机号界面
-->
<template>
	<view class="t-login">
		<image class="img-a" src="https://base.cloudcode.team/wechat/image/2.png"></image>
		<view class="t-b">{{ title }}</view>
		<view class="t-b2" v-if="user.userid != null && user.userid != ''">根据国家相关法规，网工云萌系统需要 " 绑定手机号 " 才能继续激活使用</view>
		<form class="cl">
			<view class="t-a" v-if="user.userid != null && user.userid != ''">
				<image src="https://base.cloudcode.team/wechat/image/sj.png"></image>
				<view class="line"></view>
				<input type="number" name="phone" placeholder="请输入手机号" maxlength="11" v-model="phone" />
			</view>
			<view class="t-a1" v-if="user.userid != null && user.userid != ''">
				<image src="https://base.cloudcode.team/wechat/image/yz.png"></image>
				<view class="line"></view>
				<input type="number" name="code" maxlength="4" placeholder="请输入验证码" v-model="code" />
				<button class="t-c1" @click="sendCodeBtn">{{send?'发送验证码':second+'s重新发送'}}</button>
			</view>
			<button @click="phoneband">激活</button>
		</form>
	</view>
</template>
<script>
	import {
		getConfig,
		setUserInfo,
		getUserInfo,
		setToken,
		getToken,
		removeUserInfo,
		removeToken,
		removeUserPhone
	} from '@/utils/auth';
	export default {
		data() {
			return {
				title: '首次使用请激活！', //上方标题
				s: 120, //默认120秒
				second: 0,
				send: true, //按钮可以点击
				phone: '', //手机号码
				code: '', //验证码
				user: {},
				token:{},
			};
		},
		onLoad() {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},
		onShow() {
			this.user = getUserInfo() || {};
			this.token = getToken() || {};
		},
		methods: {
			//获取短信验证码
			sendCodeBtn: function() {
				let that = this;
				// 防止多次重复点击
				if (!that.send) {
					return false;
				}
				if (!that.phone) {
					uni.showToast({
						title: '请先输入手机号',
						icon: 'error'
					});
					return;
				}
				if (!/^1[3-9]{1}[0-9]{9}$/.test(that.phone)) {
					uni.showToast({
						title: '手机号格式错误',
						icon: 'error'
					});
					return;
				}
				// 发送验证码
				that.send = false;
				this.request("phoneCode", this.$data.phone, 'POST').then(res => {
					that.showText = false;
				});
				uni.showToast({
					title: '发送成功',
					icon: 'none',
					success: () => {
						this.time(); // 倒计时
					}
				})
			},
			phoneband() {
				var that = this;
				if (!that.phone) {
					uni.showToast({
						title: '请输入手机号',
						icon: 'error',
						duration: 2000,
					});
					return;
				}
				if (!/^1[3-9]{1}[0-9]{9}$/.test(that.phone)) {
					uni.showToast({
						title: '请输入正确手机号',
						icon: 'error',
						duration: 2000,
					});
					return;
				}
				if (!that.code) {
					uni.showToast({
						title: '请输入验证码',
						icon: 'error',
						duration: 2000,
					});
					return;
				}
				let datas = {
					phone: this.$data.phone,
					code: this.$data.code,
					userId: this.user.userid,
					token: this.token,
				}
				console.log(datas);
				this.request("phoneBand", datas, 'POST').then(res => {
					if (res.code == 200) {
						uni.showToast({
							icon: "success",
							title: "绑定成功",
							duration: 2000
						})
						setTimeout(function() {
							removeUserInfo();
							removeToken();
							uni.showToast({
								title: '请重新登录！',
								icon: 'loading',
								duration: 2000
							})
						}, 2000);
						setTimeout(function() {
							uni.switchTab({
								url: '/pages/me/me',
							});
						}, 4000);
					}
					if (res.code == 500) {
						uni.showToast({
							icon: "error",
							title: "您的请求过于频繁，请间隔24小时后再尝试",
							duration: 2000
						})
					}
					if (res.code == 604) {
						uni.showToast({
							icon: "error",
							title: "验证码错误",
							duration: 2000
						})
					}
					if (res.code != 500 && res.code != 200 && res.code != 604) {
						uni.showToast({
							icon: "none",
							title: "出错啦，请联系管理员",
							duration: 2000
						})
					}
				})
			},
			// 倒计时
			time() {
				let that = this;
				that.second = that.s;
				let interval = setInterval(function() {
					if (that.second == 1) {
						that.send = true;
						that.second = that.s;
						clearInterval(interval);
					} else {
						that.second--;
					}
				}, 1000)
			}
		}
	};
</script>
<style>
	.img-a {
		position: absolute;
		width: 100%;
		top: -150rpx;
		right: 0;
	}

	.img-b {
		position: absolute;
		width: 62%;
		bottom: 0;
		left: -45rpx;
	}

	.t-login {
		width: 650rpx;
		margin: 0 auto;
		font-size: 28rpx;
		color: #000;
	}

	.t-login button {
		font-size: 28rpx;
		background: #5677fc;
		color: #fff;
		height: 90rpx;
		line-height: 90rpx;
		border-radius: 50rpx;
		box-shadow: 0 5px 7px 0 rgba(86, 119, 252, 0.2);
	}

	.t-login input {
		padding: 0 20rpx 0 120rpx;
		height: 90rpx;
		line-height: 90rpx;
		margin-bottom: 50rpx;
		background: #f8f7fc;
		border: 1px solid #e9e9e9;
		font-size: 28rpx;
		border-radius: 50rpx;
	}

	.t-login .t-a {
		position: relative;
	}

	.t-login .t-a1 {
		position: relative;
		width: 400rpx;
	}

	.t-login .t-a image {
		width: 40rpx;
		height: 40rpx;
		position: absolute;
		left: 40rpx;
		top: 28rpx;
		margin-right: 20rpx;
	}

	.t-login .t-a1 image {
		width: 40rpx;
		height: 40rpx;
		position: absolute;
		left: 40rpx;
		top: 28rpx;
		margin-right: 20rpx;
	}

	.t-login .t-a .line {
		width: 2rpx;
		height: 40rpx;
		background-color: #dedede;
		position: absolute;
		top: 28rpx;
		left: 98rpx;
	}

	.t-login .t-a1 .line {
		width: 2rpx;
		height: 40rpx;
		background-color: #dedede;
		position: absolute;
		top: 28rpx;
		left: 98rpx;
	}

	.t-login .t-b {
		text-align: left;
		font-size: 46rpx;
		color: #000;
		padding: 300rpx 0 30rpx 0;
		font-weight: bold;
	}

	.t-login .t-b2 {
		text-align: left;
		font-size: 32rpx;
		color: #ff0000;
		padding: 0rpx 0 120rpx 0;
	}

	.t-login .t-c {
		position: absolute;
		right: 22rpx;
		top: 22rpx;
		background: #5677fc;
		color: #fff;
		font-size: 24rpx;
		border-radius: 50rpx;
		height: 50rpx;
		line-height: 50rpx;
		padding: 0 25rpx;
	}

	.t-login .t-c1 {
		position: absolute;
		right: -60%;
		top: 0px;
		background-image: linear-gradient(45deg, #727CFB, #46D0ED);
		color: #ffffff;
		font-size: 24rpx;
		border-radius: 50rpx;
		height: 96%;
		line-height: 80rpx;
		padding: 0 25rpx;
		width: 220rpx;
	}

	.t-login .t-d {
		text-align: center;
		color: #999;
		margin: 80rpx 0;
	}

	.t-login .t-e {
		text-align: center;
		width: 250rpx;
		margin: 80rpx auto 0;
	}

	.t-login .t-g {
		float: left;
		width: 50%;
	}

	.t-login .t-e image {
		width: 50rpx;
		height: 50rpx;
	}

	.t-login .t-f {
		text-align: center;
		margin: 200rpx 0 0 0;
		color: #666;
	}

	.t-login .t-f text {
		margin-left: 20rpx;
		color: #aaaaaa;
		font-size: 27rpx;
	}

	.t-login .uni-input-placeholder {
		color: #000;
	}

	.cl {
		zoom: 1;
	}

	.cl:after {
		clear: both;
		display: block;
		visibility: hidden;
		height: 0;
		content: '\20';
	}
</style>
