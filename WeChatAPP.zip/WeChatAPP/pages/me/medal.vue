<!-- 
@author : Yunmeng、Yingming
@date : 2023
@description : 云萌数据
-->
<template>
	<view class="warp">
		<swiper class="swiper">
			<swiper-item v-for="(items,indexs) in levelList" :key="indexs">
				<div class="topBg">
					<view class="progress b-card" :class="{'b-level-1': items.level === 1,
					'b-level-2': items.level === 2,'b-level-3': items.level === 3,'b-level-4': items.level === 4}">
						<view class="heard">
							当前等级
						</view>
						<view class="title">
							赶紧通过活动、打卡获取积分吧！
						</view>
						<view class="progress-artice">
							<view class="outer">
								<view class="inside" :style="{'width': items.ratio+'%'}">
								</view>
							</view>
							<view class="content">
								<view class="content-item" :style="{'flex':item.flex}"
									v-for="(item,index) in items.list" :key="index">
									<view class="rangle">
										<view class="rangle-text" v-show="index<items.list.length-1"></view>
										<image class="rangle-gift"
											src="https://base.cloudcode.team/wechat/image/icon-medal-gift.png" mode=""
											v-show="index == items.list.length-1"></image>
									</view>
									<view class="level">
										{{item.name}}
									</view>
								</view>
							</view>
						</view>
						<view class="text">
							<text>志愿者的志愿时长:{{volunteertime}}小时</text>
							<text>参与志愿活动次数:{{volunteertimes}}次</text>
							<text>参与活动次数:{{activtietimes}}次</text>
						</view>
						<view class="text">
							<text>参与活动获取经验，解锁徽章！</text>
							<text class="text-des">28人已解锁</text>
						</view>
					</view>
				</div>
			</swiper-item>
		</swiper>
		<view class="medal">
			<view class="medal-title">
				<text>特别奖章</text>
				<text class="text">0个</text>
			</view>
			<view class="medal-box">
				<view class="medal-item" v-for="(item,index) in medalList" :key="index">
					<image class="img" :src="item.imgUrl">
					</image>
					<view class="title">
						{{item.title}}
					</view>
					<view class="text">
						{{item.text}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>


<script>
	import {
		getUserInfo,
		getToken,
	} from '@/utils/auth';
import { data } from '../../uni_modules/uview-ui/libs/mixin/mixin';
	export default {
		data() {
			return {
				levelList: [{
					level: 1,
					ratio: 10,
					list: [{
						flex: 2,
						achieve: 25,
						name: '大一'
					}, {
						flex: 2,
						achieve: 50,
						name: '大二'
					}, {
						flex: 2,
						achieve: 75,
						name: '大三'
					}, {
						flex: 2,
						achieve: 100,
						name: '大四'
					}]
				}, {
					level: 2,
					ratio: 50,
					list: [{
						flex: 1,
						achieve: 14.2,
						name: '大一'
					}, {
						flex: 2,
						achieve: 42.8,
						name: '大二'
					}, {
						flex: 2,
						achieve: 71.5,
						name: '大三'
					}, {
						flex: 2,
						achieve: 100,
						name: '大四'
					}]
				}, {
					level: 3,
					ratio: 80,
					list: [{
						flex: 1,
						achieve: 14.2,
						name: '大一'
					}, {
						flex: 2,
						achieve: 42.8,
						name: '大二'
					}, {
						flex: 2,
						achieve: 71.5,
						name: '大三'
					}, {
						flex: 2,
						achieve: 100,
						name: '大四'
					}]
				}, {
					level: 4,
					ratio: 10,
					list: [{
						flex: 1,
						achieve: 14.2,
						name: '大一'
					}, {
						flex: 2,
						achieve: 42.8,
						name: '大二'
					}, {
						flex: 2,
						achieve: 71.5,
						name: '大三'
					}, {
						flex: 2,
						achieve: 100,
						name: '大四'
					}]
				}],
				volunteertime: "0",
				volunteertimes: "0",
				activtietimes: "0",
				user:'',
				token:'',
				medalList: [
				// 	{
				// 	imgUrl: "https://base.cloudcode.team/wechat/image/icon-medal-1.png",
				// 	title: "荣誉内测",
				// 	text: "成为内测组"
				// }, {
				// 	imgUrl: "https://base.cloudcode.team/wechat/image/icon-medal-2.png",
				// 	title: "网工真粉",
				// 	text: "参与活动10次"
				// }, 
				// {
				// 	imgUrl: "https://base.cloudcode.team/wechat/image/icon-medal-3.png",
				// 	title: "乐听OJ",
				// 	text: "完成200道OJ题目"
				// }, {
				// 	imgUrl: "https://base.cloudcode.team/wechat/image/icon-medal-4.png",
				// 	title: "时间管家",
				// 	text: "连续50天强国打卡"
				// }, {
				// 	imgUrl: "https://base.cloudcode.team/wechat/image/icon-medal-5.png",
				// 	title: "养成习惯",
				// 	text: "连续21天打卡OJ题目"
				// }, {
				// 	imgUrl: "https://base.cloudcode.team/wechat/image/icon-medal-6.png",
				// 	title: "乐享达人",
				// 	text: "分享网工推文20次"
				// },
				]
			}
		},
		// methods:{
		// 	WxbaduserList() {
		// 		that.request("/wxapi/wxbaduser/list", 'GET').then(res => {
		// 			console.log(res)
		// 		}
		// 	}
		// }
		mounted() {
			if (item.isJoin == 2) {
				this.volunteertimes = this.volunteertimes + 1;
			}
			
			// that.request("/wxbaduser/list",datas, 'GET').then(res => {
			// 	console.log(res)
			// }
		},
		onLoad(){
			this.user = getUserInfo() || {};
			this.neitest();
		},
		methods:
		{
			neitest() {
				
					var that = this;
					that.request("wxbadge/list", 'GET').then(res => {
						console.log(res)
						if (res.code == 200) {
							this.medalList=res.data
							this.medalList.forEach(item=>{
								item.title=item.badgename
								if(item.defaultstatus==0)
								{
									item.text=item.decription
									item.imgUrl = "https://base.cloudcode.team/wechat/image/"+item.path
								}
								if(item.defaultstatus==1)
								{
									item.text=item.decription+'点亮'
									item.imgUrl = "https://base.cloudcode.team/wechat/image/"+item.pathLight
								}
							})
							uni.showToast({
								title: '点亮成功',
								icon: 'success',
								duration: 1000,						
							});
							// 以下是测试代码,仅用作demo，开发时可以省略
							// let data=[
							// 	{
							// 		bageid:1,
							// 		title:'test徽章',
							// 		text:"参与测试"
							// 	},
							// 	{
							// 		bageid:2,
							// 		text:"参与测试"
							// 	}
							// ]
							// console.log(data)
							// data.forEach(item=>{
							// 	if(item.bageid === 1)
							// 	{
							// 		item.https="https://base.cloudcode.team/wechat/image/icon-medal-1.png"
							// 	}
							// })
							// this.medalList=data
						}
					})
					
				}
			}
	}
</script>

<style lang="scss" scoped>
	.topBg {
		width: 100%;
		background: url(https://base.cloudcode.team/wechat/image/topBg.png);
		height: 400rpx;
		padding-top: 80rpx;
		background-repeat: no-repeat;
		background-size: 100%;
	}

	.b-card {
		background-color: #fefefe;
		background-image: linear-gradient(-45deg, #e8e9ec, #f2f2f2);
		padding: 30rpx 40rpx;
		margin: 0 30rpx;
		height: 500rpx;
		border-radius: 20rpx;
		box-shadow: 2rpx 2rpx 2rpx #efeef3;
		color: #9a9ca1;

		.heard {
			color: #6f7275;
		}

		.text {
			background-color: #d8dcdd;
		}

		.outer {
			background-color: #d8dcdd;

			.inside {
				background-color: #6f7275;
			}
		}

		.rangle {
			.rangle-text {
				background-color: #6f7275;
			}
		}
	}

	.b-level-1 {
		background-image: linear-gradient(45deg, #dde1ea, #a3abb8);
		color: #34424b;

		.heard {
			color: #34424b;
		}

		.text {
			background-color: #e4e9ed;
		}

		.outer {
			background-color: #e4e9ed;

			.inside {
				background-color: #34424b;
			}
		}

		.rangle {
			.rangle-text {
				background-color: #34424b;
			}
		}
	}

	.b-level-2 {
		background-image: linear-gradient(45deg, #f0daa4, #d1a165);
		color: #323b4a;

		.heard {
			color: #313a49;
		}

		.text {
			background-color: #e4e7ec;
		}

		.outer {
			background-color: #e4e7ec;

			.inside {
				background-color: #313a49;
			}
		}

		.rangle {
			.rangle-text {
				background-color: #323b4a;
			}
		}
	}

	.b-level-3 {
		background-image: linear-gradient(45deg, #ddc1b5, #c59073);
		color: #333333;

		.heard {
			color: #333333;
		}

		.text {
			background-color: #e8e8e8;
		}

		.outer {
			background-color: #e8e8e8;

			.inside {
				background-color: #333333;
			}
		}

		.rangle {
			.rangle-text {
				background-color: #333333;
			}
		}

	}

	.b-level-4 {
		background-image: linear-gradient(45deg, #303030, #1a1a1a);
		color: #f0daa4;

		.heard {
			color: #f0daa4;
		}

		.text {
			background-color: #f2e3c4;
			color: #77582a;
		}

		.outer {
			background-color: #f2e3c4;

			.inside {
				background-color: #f2e3c4;
			}
		}

		.rangle {
			.rangle-text {
				background-color: #77582a;
			}
		}
	}

	.warp {
		.swiper {
			height: 600rpx;

			.progress {
				.heard {
					font-size: 36rpx;
					font-weight: 600;
					text-align: center;
					line-height: 120rpx;
				}

				.title {
					font-size: 28rpx;
				}

				.progress-artice {
					margin-top: 30rpx;
					font-size: 28rpx;

					.outer {
						height: 10rpx;
						border-radius: 20rpx;
						margin: 0;
						overflow: hidden;

						.inside {
							height: 100%;
						}
					}

					.content {
						margin: 0;
						display: flex;
						text-align: right;

						.content-item {
							display: flex;
							flex-direction: column;

							.rangle {
								height: 10rpx;
								line-height: 10rpx;
								margin-top: -10rpx;
								display: flex;
								justify-content: flex-end;
								align-items: center;

								.rangle-text {
									width: 10rpx;
									height: 10rpx;
									display: inline-block;
									border-radius: 50%;
									display: none;
								}

								.rangle-gift {
									width: 60rpx;
									height: 60rpx;
									background-color: #cacdd0;
									display: inline-block;
									border-radius: 50%;
								}

								.achieveClass {
									background-color: #765528;
								}
							}

							.level {
								margin-top: 50rpx;
								margin-right: -20rpx;
							}

							&:nth-child(4) {
								.level {
									margin-right: 0rpx;
								}
							}
						}

					}
				}

				.text {
					margin-top: 60rpx;
					padding: 20rpx 20rpx;
					border-radius: 10rpx;
					font-size: 28rpx;
					font-weight: 600;
					display: flex;
					justify-content: space-between;
					align-items: center;

					.text-des {
						font-size: 20rpx;
						font-weight: 300;
					}
				}
			}
		}

		.medal {
			margin: 10rpx 30rpx;

			.medal-title {
				font-size: 32rpx;
				font-weight: 700;
				color: #30333b;
				padding: 0 10rpx;

				.text {
					font-size: 28rpx;
					font-weight: 300;
					color: #7c7f81;
					margin-left: 10rpx;
				}
			}

			.medal-box {
				display: flex;
				flex-wrap: wrap;

				.medal-item {
					width: 33.3333333333333%;
					display: flex;
					justify-content: center;
					align-items: center;
					flex-direction: column;
					margin-top: 40rpx;

					.img {
						width: 140rpx;
						height: 140rpx;
						border-radius: 50%;
					}

					.title {
						font-size: 24rpx;
						line-height: 60rpx;
						font-weight: 600;
						color: #30333b;
					}

					.text {
						font-size: 24rpx;
						color: #7c7f81;
					}
				}

			}
		}
	}
</style>
