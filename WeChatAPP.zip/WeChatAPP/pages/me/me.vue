<!-- 
@author : Yingming
@date : 2023
@description : 个人信息页面
-->
<template>
    <view class="components-theme">
        <!-- 弹窗确认 -->
        <view class="cu-modal" :class="modalName == 'Modal' ? 'show' : ''">
            <view class="cu-dialog" style="padding: 300rpx 0 70rpx">
                <view class="modal_bg"></view>
                <view class="modal_main">
                    <view class="nav-list margin-top">
                        <view
                            :class="'nav-li bg-zt' + (index + 1)"
                            v-for="(item, index) in inter"
                            :key="index"
                            @click="switchImage(index, item.name)"
                        >
                            <view class="nav-name">{{ item.name }}</view>
                        </view>
                    </view>
                </view>
            </view>
        </view>
        <!-- 顶部背景 -->
        <view
            class="UCenter-bg"
            :style="
                'background-image: url(' +
                pic[topBackGroupImageIndex].link +
                ');margin-top:' +
                CustomBar +
                'px;'
            "
        >
            <view class="space" v-show="spaceShow">
                <view class="stars">
                    <view class="star"></view>
                    <view class="star pink"></view>
                    <view class="star blue"></view>
                    <view class="star yellow"></view>
                </view>
            </view>
            <block>
                <view
                    class="text-center"
                    v-if="user.token == null"
                    @click="login"
                >
                    <view
                        class="cu-avatar2 round xl margin-right-sm shadow-blur-lg bg-img open-data"
                        style="overflow: hidden"
                    >
                        <image
                            src="https://base.cloudcode.team/wechat/icon/logo.png"
                            style="width: 100%; height: 100%"
                        ></image>
                    </view>
                    <view class="padding text-blue text-xl text-bold">
                        {{ "请点击登录" }}
                    </view>
                </view>
                <view
                    class="text-center"
                    v-if="user.token != null && user.grade == 19"
                >
                    <view
                        class="cu-avatar2 round xl margin-right-sm shadow-blur-lg bg-img open-data"
                        style="overflow: hidden"
                    >
                        <image
                            src="https://base.cloudcode.team/wechat/icon/biye-3.jpg"
                            style="width: 100%; height: 100%"
                        ></image>
                    </view>
                    <view class="padding text-yellow text-xl text-bold">
                        {{ "毕业快乐，" + user.nickname }}
                    </view>
                </view>
                <view
                    class="text-center"
                    v-if="user.token != null && user.grade != 19"
                >
                    <view
                        class="cu-avatar2 round xl margin-right-sm shadow-blur-lg bg-img open-data"
                        style="overflow: hidden"
                    >
                        <image
                            src="https://base.cloudcode.team/wechat/test/navt.jpg"
                            style="width: 100%; height: 100%"
                        ></image>
                    </view>
                    <view class="padding text-yellow text-xl text-bold">
                        {{ "你好，" + user.nickname }}
                    </view>
                </view>
            </block>
            <image
                src="https://base.cloudcode.team/wechat/image/mypng.gif"
                mode="scaleToFill"
                class="gif-wave"
            ></image>
        </view>
        <block>
            <view
                v-if="user.grade == 19"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xl text-yellow"
                        >总以为毕业遥遥无期……</view
                    >
                </view>
            </view>

            <!-- <view v-if="user.gender == 1" class='padding flex text-center text-grey bg-white shadow-warp-my'>
				<view class='flex flex-sub flex-direction solid-right'>
					<view class="text-xxl text-yellow cuIcon-roundcheck">权威认证：云萌工作室创始人</view>
				</view>
			</view> -->

            <view
                v-if="user.gender == 2"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：组委会成员</view
                    >
                </view>
            </view>
            <view
                v-if="user.gender == 3"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：网络工程系19级党小组组长</view
                    >
                </view>
            </view>
            <view
                v-if="user.gender == 4"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：网络工程系党支部书记</view
                    >
                </view>
            </view>
            <view
                v-if="user.gender == 5"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：网络工程系黄校长</view
                    >
                </view>
            </view>
            <view
                v-if="user.gender == 6"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：网络工程系素质教师</view
                    >
                </view>
            </view>
            <view
                v-if="user.gender == 7"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：网络工程系教师</view
                    >
                </view>
            </view>
            <view
                v-if="user.gender == 8"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：网络工程系系主任</view
                    >
                </view>
            </view>
            <view
                v-if="user.gender == 9"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：网络工程系系副主任</view
                    >
                </view>
            </view>
            <view
                v-if="user.gender == 10"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：云萌工作室成员</view
                    >
                </view>
            </view>

            <view
                v-if="user.gender == 11"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：网络工程实验室负责人</view
                    >
                </view>
            </view>
            <view
                v-if="user.gender == 12"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：云萌工作室负责人</view
                    >
                </view>
            </view>
            <view
                v-if="user.gender == 13"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：云萌工作室团队负责人</view
                    >
                </view>
            </view>
            <view
                v-if="user.gender == 14"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：网工实验室/云萌工作室学员</view
                    >
                </view>
            </view>
            <view
                v-if="user.gender == 15"
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-yellow cuIcon-roundcheck"
                        >权威认证：网工实验室成员</view
                    >
                </view>
            </view>
            <view
                class="padding flex text-center text-grey bg-white shadow-warp-my"
            >
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-orange"
                        >{{
                            user.className !== undefined
                                ? user.className
                                : "---"
                        }}
                    </view>
                    <view
                        class="margin-top-sm"
                        v-if="user.className != null && user.className != ''"
                    >
                        <text class="cuIcon-read"></text> 部门
                    </view>
                </view>
                <view class="flex flex-sub flex-direction solid-right">
                    <view class="text-xxl text-blue">{{
                        user.userid !== undefined ? user.userid : "---"
                    }}</view>
                    <view
                        class="margin-top-sm"
                        v-if="user.userid != null && user.userid != ''"
                    >
                        <text class="cuIcon-my"></text> 账号
                    </view>
                </view>
            </view>
            <view
                class="cu-list menu card-menu margin-top-lg shadow-shop bg-white text-black my-radius sm-border"
            >
                <view class="cu-item" @tap="showModal" data-target="Modal">
                    <view class="content">
                        <image
                            src="https://base.cloudcode.team/wechat/icon/zhuti.png"
                            class="png"
                            mode="aspectFit"
                        >
                        </image>
                        <text class="text-lg margin-sm">主题切换</text>
                    </view>
                    <view class="action">
                        <view class="cu-capsule radius">
                            <view class="cu-tag bg-gradual-blue">
                                <view style="clear: both"></view>
                            </view>
                            <view class="cu-tag line-blue">
                                {{ picName }}
                            </view>
                        </view>
                    </view>
                </view>
            </view>
            <view
                class="cu-list menu card-menu margin-bottom-lg shadow-shop bg-white text-black my-radius sm-border"
            >
                <view class="cu-item">
                    <button class="content cu-btn">
                        <image
                            src="https://base.cloudcode.team/wechat/icon/chucuo.png"
                            class="png"
                            mode="aspectFit"
                        >
                        </image>
                        <text class="text-lg margin-sm">6.03.18 lts</text>
                    </button>
                </view>
                <!-- 				<view class="cu-item ">
					<button class='content cu-btn' @click="goMedal">
						<image src='https://base.cloudcode.team/wechat/icon/jisuanqi.png' class='png' mode='aspectFit'></image>
						<text class='text-lg margin-sm'>云萌数据</text>
					</button>
				</view> -->
                <!-- <view class="cu-item" v-if="user.userid != null && user.userid != ''">
					<button class='content cu-btn' @tap="showTeam" data-target="ModalQQ">
						<image class='png' mode='aspectFit' src='https://base.cloudcode.team/wechat/icon/dengta.png'>
						</image>
						<text class='text-lg margin-sm'>联系我们</text>
					</button>
				</view> -->
                <view class="cu-item">
                    <button class="content cu-btn" @click="goYinsi">
                        <image
                            src="https://base.cloudcode.team/wechat/icon/youjian.png"
                            class="png"
                            mode="aspectFit"
                        >
                        </image>
                        <text class="text-lg margin-sm">隐私政策</text>
                    </button>
                </view>
                <!-- 				<view class="cu-item">
					<button class='content cu-btn' @click="goAboutMe">
						<image src='https://base.cloudcode.team/wechat/icon/xiaoxi.png' class='png' mode='aspectFit'></image>
						<text class='text-lg margin-sm'>关于云萌</text>
					</button>
				</view> -->
                <view class="cu-item" v-if="user.userid != null">
                    <button
                        class="content cu-btn"
                        v-if="user.userid !== null"
                        @click="goback"
                    >
                        <image
                            src="https://base.cloudcode.team/wechat/icon/xiaoxi.png"
                            class="png"
                            mode="aspectFit"
                        >
                        </image>
                        <text class="text-lg margin-sm">退出登录</text>
                    </button>
                </view>
            </view>
            <!-- QQ弹窗 -->
            <view
                class="cu-modal"
                :class="modalName == 'ModalQQ' ? 'show' : ''"
            >
                <view class="cu-dialog">
                    <view class="cu-bar bg-white justify-end">
                        <view class="content">加入QQ群/邮件联系</view>
                        <view class="action" @tap="hideModal">
                            <text class="cuIcon-close text-red"></text>
                        </view>
                    </view>
                    <view style="padding: 10rpx 50rpx 50rpx 50rpx">
                        <view
                            class="text-bold text-xl text-balck margin-top-xs margin-bottom"
                        >
                            网工云萌交流群</view
                        >
                        <p @click="getQQ">
                            <text class="margin-right-xs">[点击复制]</text>
                            <text class="giteeClass">608234317</text>
                        </p>
                        <view
                            class="text-bold text-xl text-balck margin-top-xs margin-bottom"
                        >
                            网工云萌官方邮件</view
                        >
                        <p @click="getEmail">
                            <text class="margin-right-xs">[点击复制]</text>
                            <text class="giteeClass"
                                >cloudcode@cloudcode.team</text
                            >
                        </p>
                    </view>
                </view>
            </view>
        </block>
    </view>
</template>

<script>
import {
    getConfig,
    setUserInfo,
    getUserInfo,
    setToken,
    getToken,
    setuserID,
    removeuserID,
    removeUserInfo,
    removeToken,
} from "@/utils/auth";
export default {
    data() {
        return {
            user: {},
            spaceShow: true,
            modalName: null,
            picName: "探秘海洋",
            pic: [
                {
                    link: "https://base.cloudcode.team/wechat/image/lvyi.jpg",
                    name: "春天",
                },
                {
                    link: "https://base.cloudcode.team/wechat/image/haiyang.jpg",
                    name: "海洋",
                },
                {
                    link: "https://base.cloudcode.team/wechat/image/yueliang.jpg",
                    name: "月亮",
                },
                {
                    link: "https://base.cloudcode.team/wechat/image/xiaoyuan.jpg",
                    name: "校园",
                },
                {
                    link: "https://base.cloudcode.team/wechat/image/saibo.jpg",
                    name: "赛博",
                },
                {
                    link: "https://base.cloudcode.team/wechat/image/hangtian.jpg",
                    name: "航天",
                },
            ],
            topBackGroupImageIndex: 1,
            inter: [
                {
                    title: "mimicry",
                    name: "绿意盎然",
                    color: "",
                },
                {
                    title: "theme",
                    name: "探秘海洋",
                    color: "",
                },
                {
                    title: "theme",
                    name: "月亮弯弯",
                    color: "",
                },
                {
                    title: "theme",
                    name: "校园记忆",
                    color: "",
                },
                {
                    title: "theme",
                    name: "赛博朋克",
                    color: "",
                },
                {
                    title: "theme",
                    name: "航天梦想",
                    color: "",
                },
            ],
        };
    },
    // 分享小程序
    onShareAppMessage(res) {
        return {
            title: "欢迎使用网工应用",
            imageUrl: "https://base.cloudcode.team/wechat/image/Logo-SCS.png",
        };
    },
    watch: {
        topBackGroupImageIndex(val) {
            // console.log(val)
            if (val == 2 || val == 4 || val == 5) {
                this.spaceShow = true;
            } else {
                this.spaceShow = false;
            }
        },
    },
    onLoad: function (data) {
        this.user = getUserInfo() || {};
        this.token = getToken() || {};
        if (
            this.user.userid == this.user.phonenumber &&
            this.user.userid != null
        ) {
            uni.navigateTo({
                url: "/pages/me/band/rephone",
            });
        }
    },
    onShow: function (data) {
        this.user = getUserInfo() || {};
        this.token = getToken() || {};
        if (
            this.user.userid == this.user.phonenumber &&
            this.user.userid != null
        ) {
            uni.navigateTo({
                url: "/pages/me/band/rephone",
            });
        }
    },
    methods: {
        getQQ() {
            uni.setClipboardData({
                data: "608234317",
                success: function () {
                    console.log("success");
                },
            });
        },
        getEmail() {
            uni.setClipboardData({
                data: "cloudcode@cloudcode.team",
                success: function () {
                    console.log("success");
                },
            });
        },
        switchImage(index, name) {
            this.topBackGroupImageIndex = index;
            this.modalName = null;
            this.picName = name;
        },
        showModal(e) {
            this.modalName = e.currentTarget.dataset.target;
        },
        showTeam(e) {
            this.modalName = e.currentTarget.dataset.target;
        },
        hideModal(e) {
            this.modalName = null;
        },
        //纪念徽章
        goMedal() {
            if (this.user.token != null) {
                uni.navigateTo({
                    url: "../me/medal",
                });
            } else {
                uni.showToast({
                    icon: "none",
                    title: "请登录后使用",
                    duration: 2000,
                });
            }
        },
        // 关于作者
        goAboutMe() {
            uni.navigateTo({
                url: "../about/about",
            });
        },
        goYinsi() {
            uni.navigateTo({
                url: "../me/yinsi",
            });
        },
        goback() {
            removeUserInfo();
            removeToken();
            removeuserID();
            uni.showToast({
                title: "正在退出...",
                icon: "loading",
                duration: 2000,
            });
            setTimeout(function () {
                uni.switchTab({
                    url: "/pages/index/index",
                });
            }, 1000);
        },
        login() {
            var that = this;
            uni.getUserProfile({
                desc: "获取您的微信信息以授权小程序",
                lang: "zh_CN",
                success: (UserProfileRes) => {
                    uni.showLoading({
                        title: "登录中....",
                        mask: true,
                    });
                    uni.login({
                        success: function (loginRes) {
                            let form = {};
                            form.code = loginRes.code; //用户code  注:用户的code每次登录都是随机的，所以不需要进行存储
                            that.request("wxlogin", form, "POST").then(
                                (wxloginres) => {
                                    if (wxloginres.code == 200) {
                                        setTimeout(function () {
                                            uni.hideLoading();
                                        }, 1000);
                                        that.user = wxloginres.data;
                                        setToken(wxloginres.data.token);
                                        setuserID(wxloginres.data.userid);
                                        setUserInfo(wxloginres.data); //模拟存储用户信息
                                    }
                                    if (wxloginres.code == 601) {
                                        uni.navigateTo({
                                            url: "../me/band/band",
                                        });
                                    }
                                    if (
                                        wxloginres.code !== 601 &&
                                        wxloginres.code !== 200
                                    ) {
                                        uni.showToast({
                                            icon: "none",
                                            title: "出错啦，再试一次，或联系管理员",
                                            duration: 2000,
                                        });
                                    }
                                }
                            );
                        },
                        fail(err) {
                            console.log(err);
                        },
                    });
                },
                fail: (err) => {
                    console.log(err);
                },
            });
        }, // uni.login结束
    },
};
</script>

<style lang="scss" scoped>
.UCenter-bg {
    background: #fff;
    background-size: 100% 100%;
    height: 550rpx;
    display: flex;
    justify-content: center;
    padding-top: 40rpx;
    overflow: hidden;
    position: relative;
    flex-direction: column;
    align-items: center;
    color: #fff;
    font-weight: 300;
    text-shadow: 0 0 3px rgba(0, 0, 0, 0.3);
}

.UCenter-bg text {
    opacity: 0.8;
}

.UCenter-bg image {
    width: 200rpx;
    height: 200rpx;
}

.UCenter-bg .gif-wave {
    position: absolute;
    width: 100%;
    bottom: 0;
    left: 0;
    z-index: 99;
    mix-blend-mode: screen;
    height: 100rpx;
}

// 头像
.cu-avatar2 {
    font-variant: small-caps;
    margin: 0;
    padding: 0;
    display: inline-flex;
    text-align: center;
    justify-content: center;
    align-items: center;
    background: #ccc;
    color: #fff;
    white-space: nowrap;
    position: relative;
    width: 150rpx;
    height: 150rpx;
    background-size: cover;
    background-position: center;
    vertical-align: middle;
    font-size: 1.5em;
    z-index: 99;
}

.name {
    text-shadow: 2px 2px 1px #2f9bfe;
}

.dialog2 {
    background: none;
}

.saicode {
    background-size: 100% 100%;
    -moz-background-size: 100% 100%;
}

.img-big image {
    top: -40px;
    width: 280rpx;
    height: 280rpx;
}

.shadow-me {
    box-shadow: 0rpx 0rpx 100rpx 0rpx rgba(0, 0, 0, 0.1);
}

.tn-footerfixed {
    position: fixed;
    width: 100%;
    bottom: 0;
    z-index: 1024;
    box-shadow: 0 1rpx 6rpx rgba(0, 0, 0, 0.35);
}

.my_logo {
    background: none;
    padding: 50rpx 0 30rpx 0;
}

.my-radius {
    border-radius: 12rpx;
    overflow: hidden;
}

.my-icon image {
    width: 100rpx;
    height: 100rpx;
    display: inline-block;
    margin: 0 auto;
}

.my-iconcolor {
    background: rgba(255, 255, 255, 0.96);
}

.shadow-shop {
    box-shadow: 0rpx 0rpx 90rpx 0rpx rgba(0, 0, 0, 0.1);
}

.qrcode-img {
    position: fixed;
    width: 80rpx;
    height: 80rpx;
    bottom: 350rpx;
    right: 30rpx;
    z-index: 1024;
    opacity: 0.8;
    box-shadow: 0rpx 8rpx 30rpx 0rpx rgba(0, 0, 0, 0.3);
    border: none;
}

/* 数字背景 */
.shadow-warp-my {
    position: relative;
    box-shadow: 0 10rpx 10rpx rgba(0, 0, 0, 0.1);
}

.shadow-warp-my:before,
.shadow-warp-my:after {
    position: absolute;
    content: "";
    top: 20rpx;
    bottom: 30rpx;
    left: 20rpx;
    width: 50%;
    box-shadow: 0 30rpx 20rpx rgba(0, 0, 0, 0.16);
    transform: rotate(-6deg);
    z-index: -1;
}

.shadow-warp-my:after {
    right: 20rpx;
    left: auto;
    transform: rotate(6deg);
}

.bg-product {
    background-image: linear-gradient(rgba(0, 0, 0, 0.06), rgba(0, 0, 0, 0));
    color: #fff;
}

.margin-bottom-my {
    margin-bottom: 150rpx;
}

.giteeClass {
    margin-top: 30rpx;
    font-size: 34rpx;
    color: #2440b3;
    text-decoration: underline;
}

.cu-dialog {
    background: #ffffff;
    overflow: visible;
}

.modal_bg {
    width: 100%;
    height: 400rpx;
    position: absolute;
    top: -100rpx;
    background-image: url(https://base.cloudcode.team/wechat/image/modal_bg.png);
    background-size: 100%;
    background-repeat: no-repeat;
}

.modal_main {
    background-color: #ffffff;
}

/* 主题色 */
.bg-zt1 {
    color: #fff;
    background: #81d949;
}

.bg-zt2 {
    color: #fff;
    background: #b2e6ff;
}

.bg-zt3 {
    color: #fff;
    background: #f3cd41;
}

.bg-zt4 {
    color: #fff;
    background: #ddecf7;
}

.bg-zt5 {
    color: #fff;
    background: #152e9d;
}

.bg-zt6 {
    color: #fff;
    background: #0f1358;
}

.nav-list {
    display: flex;
    flex-wrap: wrap;
    padding: 0px 40upx 0px;
    justify-content: space-between;
}

.nav-li {
    padding: 22upx;
    border-radius: 12upx;
    width: 45%;
    margin: 0 2.5% 40upx;
    background-image: url(https://base.cloudcode.team/wechat/icon/NyU04x.png);
    background-size: cover;
    background-position: center;
    position: relative;
    z-index: 1;
}

.nav-li::after {
    content: "";
    position: absolute;
    z-index: -1;
    background-color: inherit;
    width: 100%;
    height: 100%;
    left: 0;
    bottom: -10%;
    border-radius: 10upx;
    opacity: 0.2;
    transform: scale(0.9, 0.9);
}

.nav-li.cur {
    color: #fff;
    background: rgb(94, 185, 94);
    box-shadow: 4upx 4upx 6upx rgba(94, 185, 94, 0.4);
}

.nav-name {
    font-size: 28upx;
    text-transform: Capitalize;
    position: relative;
}

.nav-name::before {
    content: "";
    position: absolute;
    display: block;
    width: 40upx;
    height: 6upx;
    background: #fff;
    bottom: 0;
    right: 0;
    opacity: 0.5;
}

.nav-name::after {
    content: "";
    position: absolute;
    display: block;
    width: 100upx;
    height: 1px;
    background: #fff;
    bottom: 0;
    right: 40upx;
    opacity: 0.3;
}

.nav-name::first-letter {
    font-weight: bold;
    font-size: 36upx;
    margin-right: 1px;
}

.nav-li text {
    position: absolute;
    right: 30upx;
    top: 30upx;
    font-size: 52upx;
    width: 60upx;
    height: 60upx;
    text-align: center;
    line-height: 60upx;
}

// 好玩动态
.dong {
    z-index: 9999;
    position: fixed;
    top: -40px;
    right: -80px;
    transform: scale(0.24);
    -webkit-transform: scale(0.24);
    -moz-transform: scale(0.24);
}

.monster {
    transform: rotate(-50deg);
    -ms-transform: rotate(-50deg);
    /* IE 9 */
    -moz-transform: rotate(-50deg);
    /* Firefox */
    -webkit-transform: rotate(-50deg);
    /* Safari 和 Chrome */
    -o-transform: rotate(-50deg);
    /* Opera */
    display: flex;
    justify-content: center;
    position: relative;
    width: 170px;
    height: 400px;
    border-top-left-radius: 200px;
    border-top-right-radius: 200px;
    background-color: #3c47d7;
    box-shadow: 20px 20px 60px #4650e5;
}

.monster__face {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    position: absolute;
    top: 14%;
    width: 75%;
    height: 160px;
}

.monster__noses {
    top: 50%;
    display: flex;
    justify-content: space-between;
    width: 28%;
    height: auto;
    margin-bottom: 10px;
}

.monster__nose {
    width: 8px;
    height: 12px;
    border-radius: 20px;
    background: rgba(0, 0, 0, 0.5);
    box-shadow: 4px 8px 5px rgba(0, 0, 0, 0.1);
}

.monster__mouth {
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    width: 100%;
    height: 0%;
    overflow: hidden;
    border: 25px solid #ffc333;
    border-radius: 100px;
    background-color: #810332;
    animation: mouth 1.75s infinite;
    box-shadow: 4px 8px 5px rgba(0, 0, 0, 0.2);
    box-sizing: border-box;
}

.monster__mouth::before {
    content: "";
    position: absolute;
    width: 150px;
    height: 80px;
    border-radius: 100px;
    background-color: #400018;
}

.monster__mouth::after {
    content: "";
    position: absolute;
    bottom: -80px;
    width: 160px;
    height: 80px;
    border-top-left-radius: 50%;
    border-top-right-radius: 50%;
    background-color: #dc1b50;
    animation: tongue 1.75s infinite;
}

.monster__top {
    position: absolute;
    top: -30px;
    width: 170px;
    height: 30px;
    border-bottom-left-radius: 10px;
    border-bottom-right-radius: 10px;
    background-color: #ffffff;
    z-index: 100;
    animation: t 1.75s infinite;
}

.monster__bottom {
    position: absolute;
    bottom: 0;
    width: 100px;
    height: 30px;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    background-color: #ffffff;
    z-index: 100;
    animation: b 1.75s infinite;
}

.avatar-eye {
    position: absolute;
    top: -10%;
    width: 65px;
    height: 65px;
    background: linear-gradient(105deg, white, #cb87f4);
    border-radius: 100%;
    box-shadow: 4px 8px 5px rgba(0, 0, 0, 0.2);
    margin: 3px;
    -webkit-transform: translateX(-50%);
    transform: translateX(-50%);
}

.avatar-eye--green {
    background: linear-gradient(to bottom, #fdfdfd, #c3efea);
}

.avatar-eye--violet {
    background: linear-gradient(to bottom, #fdfdfd, #e6d6f6);
}

.eye--left {
    left: 10%;
}

.eye--right {
    left: 85%;
}

.eye--center {
    left: 45%;
    top: 10%;
}

.avatar-eye-pupil {
    position: absolute;
    width: 55%;
    height: 55%;
    left: 50%;
    top: 25%;
    -webkit-transform: translate(-50%);
    transform: translate(-50%);
    z-index: 100;
    border-radius: 100%;
}

.pupil--green {
    background: linear-gradient(135deg, rgba(188, 248, 177, 0.7), #2fa38c 75%);
}

.pupil--pink {
    background: linear-gradient(135deg, #f1a183, #8535cd);
}

.avatar-eye-pupil-blackThing {
    position: absolute;
    width: 55%;
    height: 55%;
    left: 50%;
    top: 25%;
    background: #2c2f32;
    -webkit-transform: translate(-50%);
    transform: translate(-50%);
    border-radius: 100%;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
}

.avatar-eye-pupil-lightReflection {
    position: absolute;
    width: 7px;
    height: 7px;
    left: 25%;
    top: 10%;
    background: #ebebeb;
    -webkit-transform: translate(-50%);
    transform: translate(-50%);
    border-radius: 100%;
    box-shadow: 10px 10px 10px rgba(255, 255, 255, 0.2);
}

/**/
@keyframes t {
    0%,
    10%,
    80%,
    100% {
        top: -30px;
    }

    20% {
        top: 0px;
    }

    30% {
        top: -20px;
    }

    40% {
        top: -0px;
    }

    50% {
        top: -25px;
    }

    70% {
        top: 0px;
    }
}

@keyframes b {
    0%,
    10%,
    80%,
    100% {
        bottom: -30px;
    }

    20% {
        bottom: 0px;
    }

    30% {
        bottom: -20px;
    }

    40% {
        bottom: -0px;
    }

    50% {
        bottom: -25px;
    }

    70% {
        bottom: 0px;
    }
}

@keyframes mouth {
    0%,
    10%,
    100% {
        width: 100%;
        height: 0%;
    }

    15% {
        width: 90%;
        height: 30%;
    }

    20% {
        width: 50%;
        height: 70%;
    }

    25% {
        width: 70%;
        height: 70%;
    }

    30% {
        width: 80%;
        height: 60%;
    }

    35% {
        width: 60%;
        height: 70%;
    }

    40% {
        width: 55%;
        height: 75%;
    }

    45% {
        width: 50%;
        height: 90%;
    }

    50% {
        width: 40%;
        height: 70%;
    }

    55% {
        width: 70%;
        height: 95%;
    }

    60% {
        width: 40%;
        height: 50%;
    }

    65% {
        width: 100%;
        height: 60%;
    }

    70% {
        width: 100%;
        height: 70%;
    }

    75% {
        width: 90%;
        height: 70%;
    }

    80% {
        width: 50%;
        height: 70%;
    }

    85% {
        width: 90%;
        height: 50%;
    }

    85% {
        width: 40%;
        height: 70%;
    }

    90% {
        width: 90%;
        height: 30%;
    }

    95% {
        width: 100%;
        height: 10%;
    }
}

@keyframes tongue {
    0%,
    20%,
    100% {
        bottom: -80px;
    }

    30%,
    90% {
        bottom: -40px;
    }

    40% {
        bottom: -45px;
    }

    50% {
        bottom: -50px;
    }

    70% {
        bottom: -80px;
    }

    90% {
        bottom: -40px;
    }
}

// 顶部流星
.space {
    position: absolute;
    top: 0;
    left: 0;
}

.planet {
    width: 150rpx;
    height: 150rpx;
    border-radius: 50%;
    background: #333;
    position: absolute;
    left: 50%;
    top: 50%;
    margin: -75rpx 0 0 -75rpx;
    overflow: hidden;
    z-index: 2;
}

.planet_shadow {
    position: absolute;
    border-radius: 50%;
    height: 100%;
    width: 100%;
    top: -40%;
    right: -10%;
    border: 35rpx solid rgba(0, 0, 0, 0.15);
}

.star {
    display: block;
    width: 5rpx;
    height: 5rpx;
    border-radius: 50%;
    background: #fff;
    top: 100rpx;
    left: 400rpx;
    position: relative;
    transform-origin: 100% 0;
    animation: star-ani 6s infinite ease-out;
    box-shadow: 0 0 5rpx 5rpx rgba(255, 255, 255, 0.3);
    opacity: 0;
    z-index: 2;
}

.star:after {
    content: "";
    display: block;
    top: 0rpx;
    left: 4rpx;
    border: 0rpx solid #fff;
    border-width: 0rpx 90rpx 2rpx 90rpx;
    border-color: transparent transparent transparent rgba(255, 255, 255, 0.3);
    transform: rotate(-45deg) translate3d(1rpx, 3rpx, 0);
    box-shadow: 0 0 1rpx 0 rgba(255, 255, 255, 0.1);
    transform-origin: 0% 100%;
    animation: shooting-ani 3s infinite ease-out;
}

.pink {
    top: 30rpx;
    left: 395rpx;
    background: #ff5a99;
    animation-delay: 5s;
    -webkit-animation-delay: 5s;
    -moz-animation-delay: 5s;
}

.pink:after {
    border-color: transparent transparent transparent #ff5a99;
    animation-delay: 5s;
    -webkit-animation-delay: 5s;
    -moz-animation-delay: 5s;
}

.blue {
    top: 35rpx;
    left: 432rpx;
    background: cyan;
    animation-delay: 7s;
    -webkit-animation-delay: 7s;
    -moz-animation-delay: 7s;
}

.blue:after {
    /* border-color: transpareanimation-delay: 12s; */
    -webkit-animation-delay: 7s;
    -moz-animation-delay: 7s;
    animation-delay: 7s;
}

.yellow {
    top: 50rpx;
    left: 600rpx;
    background: #ffcd5c;
    animation-delay: 5.8s;
}

.yellow:after {
    border-color: transparent transparent transparent #ffcd5c;
    animation-delay: 5.8s;
}

@keyframes star-ani {
    0% {
        opacity: 0;
        transform: scale(0) rotate(0) translate3d(0, 0, 0);
        -webkit-transform: scale(0) rotate(0) translate3d(0, 0, 0);
        -moz-transform: scale(0) rotate(0) translate3d(0, 0, 0);
    }

    50% {
        opacity: 1;
        transform: scale(1) rotate(0) translate3d(-200rpx, 200rpx, 0);
        -webkit-transform: scale(1) rotate(0) translate3d(-200rpx, 200rpx, 0);
        -moz-transform: scale(1) rotate(0) translate3d(-200rpx, 200rpx, 0);
    }

    100% {
        opacity: 0;
        transform: scale(1) rotate(0) translate3d(-300rpx, 300rpx, 0);
        -webkit-transform: scale(1) rotate(0) translate3d(-300rpx, 300rpx, 0);
        -moz-transform: scale(1) rotate(0) translate3d(-300rpx, 300rpx, 0);
    }
}
</style>
